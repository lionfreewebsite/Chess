import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navigation/Navbar';
import { PlayView } from './views/PlayView';
import { AnalysisView } from './views/AnalysisView';
import { OpeningView } from './views/OpeningView';
import { PuzzlesView } from './views/PuzzlesView';
import { BotMatchView } from './views/BotMatchView';
import { EditorView } from './views/EditorView';
import { GamesView } from './views/GamesView';
import { SettingsView } from './views/SettingsView';
import { GameTree } from './engine/gameTree';
import { globalEngine } from './engine/engineService';
import {
  AppMode,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  AnimationSpeed,
  DragRefreshRate,
  UIThemeColor,
} from './types/chess';

export function App() {
  const [currentMode, setCurrentMode] = useState<AppMode>('play');
  const [sharedTree, setSharedTree] = useState<GameTree>(() => new GameTree());
  const [editorFen, setEditorFen] = useState<string | undefined>(undefined);

  // Preferences & Themes
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_dark_mode');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [uiTheme, setUiTheme] = useState<UIThemeColor>(() => {
    try {
      return (localStorage.getItem('aperture_ui_theme') as UIThemeColor) || 'orange';
    } catch {
      return 'orange';
    }
  });

  const [boardTheme, setBoardTheme] = useState<BoardTheme>(() => {
    try {
      return (localStorage.getItem('aperture_board_theme') as BoardTheme) || 'walnut';
    } catch {
      return 'walnut';
    }
  });

  const [pieceTheme, setPieceTheme] = useState<PieceTheme>(() => {
    try {
      return (localStorage.getItem('aperture_piece_theme') as PieceTheme) || 'ivory';
    } catch {
      return 'ivory';
    }
  });

  const [pieceStyle, setPieceStyle] = useState<PieceStyle>('svg');

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('aperture_sound') !== 'false';
    } catch {
      return true;
    }
  });

  const [animationEnabled, setAnimationEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_animation_enabled');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [animationSpeed, setAnimationSpeed] = useState<AnimationSpeed>(() => {
    try {
      return (localStorage.getItem('aperture_animation_speed') as AnimationSpeed) || 'normal';
    } catch {
      return 'normal';
    }
  });

  const [dragAndDropEnabled, setDragAndDropEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_drag_drop');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [dragRefreshRate, setDragRefreshRate] = useState<DragRefreshRate>(() => {
    try {
      return (localStorage.getItem('aperture_drag_refresh_rate') as DragRefreshRate) || '60fps';
    } catch {
      return '60fps';
    }
  });

  const [autoQueenEnabled, setAutoQueenEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_auto_queen');
      return saved !== null ? saved === 'true' : false;
    } catch {
      return false;
    }
  });

  const [showCoordinates, setShowCoordinates] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_show_coords');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [showLegalMoves, setShowLegalMoves] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_show_legal_moves');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [showCheckHighlight, setShowCheckHighlight] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_show_check');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [showLastMoveHighlight, setShowLastMoveHighlight] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('aperture_show_last_move');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  // Sync dark class to root document element and persist
  useEffect(() => {
    try {
      localStorage.setItem('aperture_dark_mode', String(isDarkMode));
    } catch {}
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Persist preferences and synchronize theme attributes
  useEffect(() => {
    try {
      localStorage.setItem('aperture_ui_theme', uiTheme);
    } catch {}
    document.documentElement.setAttribute('data-theme', uiTheme);
  }, [uiTheme]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_board_theme', boardTheme);
    } catch {}
  }, [boardTheme]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_piece_theme', pieceTheme);
    } catch {}
  }, [pieceTheme]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_sound', String(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_animation_enabled', String(animationEnabled));
    } catch {}
  }, [animationEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_animation_speed', animationSpeed);
    } catch {}
  }, [animationSpeed]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_drag_drop', String(dragAndDropEnabled));
    } catch {}
  }, [dragAndDropEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_auto_queen', String(autoQueenEnabled));
    } catch {}
  }, [autoQueenEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_show_coords', String(showCoordinates));
    } catch {}
  }, [showCoordinates]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_show_legal_moves', String(showLegalMoves));
    } catch {}
  }, [showLegalMoves]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_show_check', String(showCheckHighlight));
    } catch {}
  }, [showCheckHighlight]);

  useEffect(() => {
    try {
      localStorage.setItem('aperture_show_last_move', String(showLastMoveHighlight));
    } catch {}
  }, [showLastMoveHighlight]);

  // When switching modes, stop active engine routines to prevent overlaps
  const handleSelectMode = (mode: AppMode) => {
    globalEngine.stop();
    setCurrentMode(mode);
  };

  // Transition from any game/puzzle/editor to Analysis view
  const handleAnalyzeGame = (tree: GameTree) => {
    globalEngine.stop();
    setSharedTree(tree);
    setCurrentMode('analysis');
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDarkMode ? 'dark bg-stone-950 text-stone-100' : 'bg-stone-100 text-stone-900'}`}>
      {/* Top Navbar & Dynamic Modes Bar */}
      <Navbar
        currentMode={currentMode}
        onSelectMode={handleSelectMode}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
        uiTheme={uiTheme}
      />

      {/* Main Workspace Stage */}
      <main className="flex-1 flex flex-col">
        <div className={currentMode === 'play' ? 'flex-1 flex flex-col' : 'hidden'}>
          <PlayView
            isActive={currentMode === 'play'}
            onAnalyzeGame={handleAnalyzeGame}
            boardTheme={boardTheme}
            pieceTheme={pieceTheme}
            pieceStyle={pieceStyle}
            soundEnabled={soundEnabled}
            animationEnabled={animationEnabled}
            animationSpeed={animationSpeed}
            dragRefreshRate={dragRefreshRate}
            dragAndDropEnabled={dragAndDropEnabled}
            autoQueenEnabled={autoQueenEnabled}
            showCoordinates={showCoordinates}
            showLegalMoves={showLegalMoves}
            showCheckHighlight={showCheckHighlight}
            showLastMoveHighlight={showLastMoveHighlight}
            uiTheme={uiTheme}
          />
        </div>

        <div className={currentMode === 'analysis' ? 'flex-1 flex flex-col' : 'hidden'}>
          <AnalysisView
            isActive={currentMode === 'analysis'}
            initialTree={sharedTree}
            boardTheme={boardTheme}
            pieceTheme={pieceTheme}
            pieceStyle={pieceStyle}
            soundEnabled={soundEnabled}
            animationEnabled={animationEnabled}
            animationSpeed={animationSpeed}
            dragRefreshRate={dragRefreshRate}
            dragAndDropEnabled={dragAndDropEnabled}
            autoQueenEnabled={autoQueenEnabled}
            showCoordinates={showCoordinates}
            showLegalMoves={showLegalMoves}
            showCheckHighlight={showCheckHighlight}
            showLastMoveHighlight={showLastMoveHighlight}
            uiTheme={uiTheme}
            onOpenEditor={(fen) => {
              setEditorFen(fen);
              setCurrentMode('editor');
            }}
          />
        </div>

        <div className={currentMode === 'opening' ? 'flex-1 flex flex-col' : 'hidden'}>
          <OpeningView
            onAnalyzeOpening={handleAnalyzeGame}
            boardTheme={boardTheme}
            pieceTheme={pieceTheme}
            pieceStyle={pieceStyle}
            soundEnabled={soundEnabled}
            animationEnabled={animationEnabled}
            animationSpeed={animationSpeed}
            uiTheme={uiTheme}
          />
        </div>

        <div className={currentMode === 'puzzles' ? 'flex-1 flex flex-col' : 'hidden'}>
          <PuzzlesView
            onAnalyzePosition={handleAnalyzeGame}
            boardTheme={boardTheme}
            pieceTheme={pieceTheme}
            pieceStyle={pieceStyle}
            soundEnabled={soundEnabled}
            animationEnabled={animationEnabled}
            animationSpeed={animationSpeed}
            uiTheme={uiTheme}
          />
        </div>

        <div className={currentMode === 'botmatch' ? 'flex-1 flex flex-col' : 'hidden'}>
          <BotMatchView
            isActive={currentMode === 'botmatch'}
            onAnalyzeGame={handleAnalyzeGame}
            boardTheme={boardTheme}
            pieceTheme={pieceTheme}
            pieceStyle={pieceStyle}
            soundEnabled={soundEnabled}
            animationEnabled={animationEnabled}
            animationSpeed={animationSpeed}
            uiTheme={uiTheme}
          />
        </div>

        <div className={currentMode === 'editor' ? 'flex-1 flex flex-col' : 'hidden'}>
          <EditorView
            initialFen={editorFen}
            onAnalyzePosition={handleAnalyzeGame}
            boardTheme={boardTheme}
            pieceTheme={pieceTheme}
            pieceStyle={pieceStyle}
            animationEnabled={animationEnabled}
            animationSpeed={animationSpeed}
            dragRefreshRate={dragRefreshRate}
            dragAndDropEnabled={dragAndDropEnabled}
            autoQueenEnabled={autoQueenEnabled}
            showCoordinates={showCoordinates}
            showLegalMoves={showLegalMoves}
            showCheckHighlight={showCheckHighlight}
            showLastMoveHighlight={showLastMoveHighlight}
            uiTheme={uiTheme}
          />
        </div>

        <div className={currentMode === 'games' ? 'flex-1 flex flex-col' : 'hidden'}>
          <GamesView
            onLoadGameToAnalysis={handleAnalyzeGame}
            uiTheme={uiTheme}
          />
        </div>

        <div className={currentMode === 'settings' ? 'flex-1 flex flex-col' : 'hidden'}>
          <SettingsView
            uiTheme={uiTheme}
            setUiTheme={setUiTheme}
            boardTheme={boardTheme}
            setBoardTheme={setBoardTheme}
            pieceTheme={pieceTheme}
            setPieceTheme={setPieceTheme}
            pieceStyle={pieceStyle}
            setPieceStyle={setPieceStyle}
            soundEnabled={soundEnabled}
            setSoundEnabled={setSoundEnabled}
            animationEnabled={animationEnabled}
            setAnimationEnabled={setAnimationEnabled}
            animationSpeed={animationSpeed}
            setAnimationSpeed={setAnimationSpeed}
            dragRefreshRate={dragRefreshRate}
            setDragRefreshRate={setDragRefreshRate}
            dragAndDropEnabled={dragAndDropEnabled}
            setDragAndDropEnabled={setDragAndDropEnabled}
            autoQueenEnabled={autoQueenEnabled}
            setAutoQueenEnabled={setAutoQueenEnabled}
            showCoordinates={showCoordinates}
            setShowCoordinates={setShowCoordinates}
            showLegalMoves={showLegalMoves}
            setShowLegalMoves={setShowLegalMoves}
            showCheckHighlight={showCheckHighlight}
            setShowCheckHighlight={setShowCheckHighlight}
            showLastMoveHighlight={showLastMoveHighlight}
            setShowLastMoveHighlight={setShowLastMoveHighlight}
          />
        </div>
      </main>
    </div>
  );
}

export default App;
