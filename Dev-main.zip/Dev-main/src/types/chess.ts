export type PieceColor = 'w' | 'b';
export type PieceType = 'P' | 'N' | 'B' | 'R' | 'Q' | 'K' | 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type Square = number; // 0..63 (a1=0, h1=7, a8=56, h8=63)

export interface Move {
  from: Square;
  to: Square;
  piece: string;
  capture?: boolean;
  captured?: string | null;
  promotion?: string;
  castle?: 'k' | 'q' | null;
  enPassant?: boolean;
  doubleStep?: boolean;
}

export interface MoveResult {
  san: string;
  from: string;
  to: string;
  promotion: string | null;
  capture: boolean;
  castle: 'k' | 'q' | null;
  enPassant: boolean;
  fenBefore: string;
  fenAfter: string;
  piece: string;
}

export interface GameStatus {
  over: boolean;
  result: '1-0' | '0-1' | '1/2-1/2' | '*';
  reason: 'checkmate' | 'stalemate' | 'insufficient material' | 'threefold repetition' | 'fivefold repetition' | 'fifty-move rule' | '75-move rule' | 'resignation' | 'timeout' | 'draw by agreement' | 'move limit' | null;
  canClaimDraw?: boolean;
  claimReason?: string | null;
}

export interface EngineScore {
  cp?: number;
  mate?: number;
}

export interface PVLine {
  score: EngineScore;
  pv: string[]; // uci format moves
  pvSan?: string[];
  depth?: number;
}

export interface EngineInfo {
  id: number;
  depth: number;
  nodes: number;
  nps: number;
  timeMs: number;
  lines: PVLine[];
}

export interface EngineBestMoveResult {
  id: number;
  move: string | null; // uci
  lines?: PVLine[];
}

export interface GameTreeNode {
  id: number;
  parent: GameTreeNode | null;
  children: GameTreeNode[];
  san: string | null;
  ply: number;
  uci: { from: string; to: string; promotion: string | null } | null;
  fenBefore: string;
  fenAfter: string;
  comment: string;
  nags: string[];
  classification?: MoveClassification;
  evalScore?: EngineScore;
  evalCp?: number;
  bestMoveSan?: string;
}

export type MoveClassification =
  | 'brilliant'
  | 'best'
  | 'excellent'
  | 'good'
  | 'book'
  | 'inaccuracy'
  | 'mistake'
  | 'blunder'
  | 'missedwin'
  | 'miss';

export interface BotPresetConfig {
  label: string;
  depth: number;
  timeMs: number;
  multipv: number;
  blunderChance: number;
  description: string;
  elo: number;
}

export interface Puzzle {
  id: string;
  rating: number;
  theme: string;
  fen: string;
  solution: string[]; // UCI strings alternating solver / opponent
  toMove: PieceColor;
  description?: string;
  category?: 'mate' | 'fork' | 'pin' | 'skewer' | 'sacrifice' | 'endgame' | 'discovered' | 'trapped' | 'procedural';
}

export interface OpeningExplanation {
  move: string;
  ply: number;
  title: string;
  why: string;
  plans: string;
  arrows?: { from: Square; to: Square; tier?: 'best' | 'second' | 'third' | 'user' }[];
  keySquare?: Square;
}

export interface OpeningChapter {
  id: string;
  title: string;
  description: string;
  moves: string;
  tokens: string[];
  color: PieceColor;
  explanations?: OpeningExplanation[];
}

export interface OpeningQuizItem {
  id: string;
  fen: string;
  question: string;
  correctMoveSan: string;
  explanation: string;
  options?: string[];
}

export interface OpeningVariation {
  name: string;
  eco: string;
  moves: string;
  tokens: string[];
  description?: string;
  keyPlans?: string[];
  category?: string;
  chapters?: OpeningChapter[];
  quiz?: OpeningQuizItem[];
}

export interface SavedGame {
  id: string;
  name?: string;
  title?: string;
  pgn: string;
  fen?: string;
  timestamp?: number;
  date?: string;
  mode?: 'human-bot' | 'human-human' | 'bot-bot' | 'historical' | 'custom';
  category?: 'favorites' | 'bot' | 'human' | 'historical' | 'other';
  result: string;
  favorite?: boolean;
  white?: string;
  black?: string;
  eco?: string;
  event?: string;
}

export type UIThemeColor = 'amber' | 'orange' | 'emerald' | 'sapphire' | 'violet' | 'rose' | 'cyan' | 'ruby';

export type PlayVariantMode = 'standard' | 'chess960' | 'custom';

export interface SavedPosition {
  id: string;
  name: string;
  fen: string;
  pgn: string;
  timestamp: number;
  tags?: string[];
  notes?: string;
}

export type AppMode = 'play' | 'analysis' | 'botmatch' | 'puzzles' | 'opening' | 'editor' | 'games' | 'settings';

export type BoardTheme = 'walnut' | 'tournament' | 'azure' | 'coral' | 'graphite' | 'midnight';
export type PieceTheme = 'ivory' | 'wood' | 'metallic' | 'neon' | 'sapphire' | 'forest' | 'contrast';
export type PieceStyle = 'svg' | 'letters';
export type AnimationSpeed = 'fast' | 'normal' | 'slow';
export type DragRefreshRate = '60fps' | '30fps' | 'unlimited';
