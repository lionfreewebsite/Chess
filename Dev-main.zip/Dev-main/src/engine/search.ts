/**
 * High-performance Negamax Chess Search Engine with Alpha-Beta Pruning,
 * Quiescence Search, Zobrist Transposition Table, Piece-Square Tables,
 * and Anti-Draw Repetition Intelligence.
 */

import { Chess, sqName, colorOf } from './chessRules';
import { Move, EngineScore, PVLine, Square, PieceColor } from '../types/chess';

export const MATE = 100000;
export const INF = 1000000;
export const MATE_THRESHOLD = MATE - 1000;
export const TIME_UP = Symbol('TIME_UP');

export const PIECE_VAL: Record<string, number> = {
  P: 100,
  N: 320,
  B: 330,
  R: 500,
  Q: 900,
  K: 0,
};

function rand32(): number {
  return (Math.random() * 0x100000000) >>> 0;
}

const ZOBRIST_PIECES = 'PNBRQKpnbrqk';
const ZOBRIST_PIECE: Record<string, [number, number][]> = {};
for (const p of ZOBRIST_PIECES) {
  const arr: [number, number][] = [];
  for (let sq = 0; sq < 64; sq++) arr.push([rand32(), rand32()]);
  ZOBRIST_PIECE[p] = arr;
}
const ZOBRIST_SIDE: [number, number] = [rand32(), rand32()];
const ZOBRIST_CASTLE: Record<string, [number, number]> = {
  K: [rand32(), rand32()],
  Q: [rand32(), rand32()],
  k: [rand32(), rand32()],
  q: [rand32(), rand32()],
};
const ZOBRIST_EP_FILE: [number, number][] = [];
for (let f = 0; f < 8; f++) ZOBRIST_EP_FILE.push([rand32(), rand32()]);

export function computeZobrist(chess: Chess): [number, number] {
  let hi = 0;
  let lo = 0;
  const board = chess.board;
  for (let sq = 0; sq < 64; sq++) {
    const p = board[sq];
    if (p && ZOBRIST_PIECE[p]) {
      const z = ZOBRIST_PIECE[p][sq];
      hi ^= z[0];
      lo ^= z[1];
    }
  }
  if (chess.turn === 'b') {
    hi ^= ZOBRIST_SIDE[0];
    lo ^= ZOBRIST_SIDE[1];
  }
  if (chess.castling.K) {
    hi ^= ZOBRIST_CASTLE.K[0];
    lo ^= ZOBRIST_CASTLE.K[1];
  }
  if (chess.castling.Q) {
    hi ^= ZOBRIST_CASTLE.Q[0];
    lo ^= ZOBRIST_CASTLE.Q[1];
  }
  if (chess.castling.k) {
    hi ^= ZOBRIST_CASTLE.k[0];
    lo ^= ZOBRIST_CASTLE.k[1];
  }
  if (chess.castling.q) {
    hi ^= ZOBRIST_CASTLE.q[0];
    lo ^= ZOBRIST_CASTLE.q[1];
  }
  if (chess.ep >= 0) {
    const z = ZOBRIST_EP_FILE[chess.ep & 7];
    hi ^= z[0];
    lo ^= z[1];
  }
  return [hi >>> 0, lo >>> 0];
}

const TT_BITS = 18;
const TT_SIZE = 1 << TT_BITS;
const TT_MASK = TT_SIZE - 1;
const TT_FLAG_EXACT = 0;
const TT_FLAG_LOWER = 1;
const TT_FLAG_UPPER = 2;

export class TranspositionTable {
  hashHi: Int32Array;
  hashLo: Int32Array;
  depth: Int8Array;
  score: Int32Array;
  flag: Int8Array;
  moveFrom: Int8Array;
  moveTo: Int8Array;
  movePromo: Int8Array;

  constructor() {
    this.hashHi = new Int32Array(TT_SIZE);
    this.hashLo = new Int32Array(TT_SIZE);
    this.depth = new Int8Array(TT_SIZE).fill(-1);
    this.score = new Int32Array(TT_SIZE);
    this.flag = new Int8Array(TT_SIZE);
    this.moveFrom = new Int8Array(TT_SIZE).fill(-1);
    this.moveTo = new Int8Array(TT_SIZE).fill(-1);
    this.movePromo = new Int8Array(TT_SIZE);
  }

  clear(): void {
    this.depth.fill(-1);
    this.moveFrom.fill(-1);
  }

  probe(hi: number, lo: number): number | null {
    const idx = lo & TT_MASK;
    if (this.depth[idx] === -1) return null;
    if (this.hashHi[idx] !== hi || this.hashLo[idx] !== lo) return null;
    return idx;
  }

  store(
    hi: number,
    lo: number,
    depth: number,
    score: number,
    flag: number,
    from: number,
    to: number,
    promoCode: number
  ): void {
    if (Math.abs(score) >= MATE_THRESHOLD) return;
    const idx = lo & TT_MASK;
    if (
      this.depth[idx] !== -1 &&
      this.hashHi[idx] === hi &&
      this.hashLo[idx] === lo &&
      this.depth[idx] > depth
    ) {
      return;
    }
    this.hashHi[idx] = hi;
    this.hashLo[idx] = lo;
    this.depth[idx] = depth;
    this.score[idx] = score;
    this.flag[idx] = flag;
    this.moveFrom[idx] = from;
    this.moveTo[idx] = to;
    this.movePromo[idx] = promoCode;
  }
}

const PROMO_CODE: Record<string, number> = { Q: 1, R: 2, B: 3, N: 4 };

// Piece-Square Tables (White perspective)
const PST_RAW: Record<string, number[]> = {
  P: [
    0, 0, 0, 0, 0, 0, 0, 0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
    5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0,
    5, -5, -10, 0, 0, -10, -5, 5,
    5, 10, 10, -20, -20, 10, 10, 5,
    0, 0, 0, 0, 0, 0, 0, 0,
  ],
  N: [
    -50, -40, -30, -30, -30, -30, -40, -50,
    -40, -20, 0, 0, 0, 0, -20, -40,
    -30, 0, 10, 15, 15, 10, 0, -30,
    -30, 5, 15, 20, 20, 15, 5, -30,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -30, 5, 10, 15, 15, 10, 5, -30,
    -40, -20, 0, 5, 5, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50,
  ],
  B: [
    -20, -10, -10, -10, -10, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 10, 10, 5, 0, -10,
    -10, 5, 5, 10, 10, 5, 5, -10,
    -10, 0, 10, 10, 10, 10, 0, -10,
    -10, 10, 10, 10, 10, 10, 10, -10,
    -10, 5, 0, 0, 0, 0, 5, -10,
    -20, -10, -10, -10, -10, -10, -10, -20,
  ],
  R: [
    0, 0, 0, 0, 0, 0, 0, 0,
    5, 10, 10, 10, 10, 10, 10, 5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    0, 0, 0, 5, 5, 0, 0, 0,
  ],
  Q: [
    -20, -10, -10, -5, -5, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 5, 5, 5, 0, -10,
    -5, 0, 5, 5, 5, 5, 0, -5,
    0, 0, 5, 5, 5, 5, 0, -5,
    -10, 5, 5, 5, 5, 5, 0, -10,
    -10, 0, 5, 0, 0, 0, 0, -10,
    -20, -10, -10, -5, -5, -10, -10, -20,
  ],
  K: [
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10,
    20, 20, 0, 0, 0, 0, 20, 20,
    20, 30, 10, 0, 0, 10, 30, 20,
  ],
  Kend: [
    -50, -40, -30, -20, -20, -30, -40, -50,
    -30, -20, -10, 0, 0, -10, -20, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -30, 0, 0, 0, 0, -30, -30,
    -50, -30, -30, -30, -30, -30, -30, -50,
  ],
};

function convertPST(table: number[]): number[] {
  const out = new Array(64);
  for (let r = 0; r < 8; r++) {
    const srcRow = 7 - r;
    for (let f = 0; f < 8; f++) {
      out[r * 8 + f] = table[srcRow * 8 + f];
    }
  }
  return out;
}

const PST_W: Record<string, number[]> = {};
for (const k of Object.keys(PST_RAW)) {
  PST_W[k] = convertPST(PST_RAW[k]);
}

export function isEndgame(chess: Chess): boolean {
  let queens = 0;
  let minorsRooks = 0;
  for (const p of chess.board) {
    if (!p) continue;
    const t = p.toUpperCase();
    if (t === 'Q') queens++;
    else if (t === 'R' || t === 'B' || t === 'N') minorsRooks++;
  }
  return queens === 0 || (queens <= 2 && minorsRooks <= 2);
}

export function evaluate(chess: Chess): number {
  let score = 0;
  const endgame = isEndgame(chess);
  const board = chess.board;

  for (let sq = 0; sq < 64; sq++) {
    const p = board[sq];
    if (!p) continue;
    const type = p.toUpperCase();
    const white = colorOf(p) === 'w';
    const idx = white ? sq : 63 - sq;

    let val = PIECE_VAL[type] || 0;
    let pstVal = 0;
    if (type === 'K') {
      pstVal = endgame ? PST_W.Kend[idx] : PST_W.K[idx];
    } else if (PST_W[type]) {
      pstVal = PST_W[type][idx];
    }
    val += pstVal;
    score += white ? val : -val;
  }
  return score;
}

export function mvvLva(move: Move): number {
  if (!move.capture) return 0;
  const victim = PIECE_VAL[(move.captured || 'p').toUpperCase()] || 0;
  const attacker = PIECE_VAL[move.piece.toUpperCase()] || 0;
  return victim * 10 - attacker;
}

export function moveUci(m: Move): string {
  let s = sqName(m.from) + sqName(m.to);
  if (m.promotion) s += m.promotion.toLowerCase();
  return s;
}

export class Searcher {
  nodes: number;
  deadline: number;
  killers: Record<number, Move>;
  tt: TranspositionTable;
  isCancelled?: () => boolean;

  constructor() {
    this.nodes = 0;
    this.deadline = Infinity;
    this.killers = {};
    this.tt = new TranspositionTable();
  }

  _checkTime(): void {
    this.nodes++;
    if ((this.nodes & 511) === 0) {
      if (this.isCancelled && this.isCancelled()) {
        throw TIME_UP;
      }
      if (Date.now() > this.deadline) {
        throw TIME_UP;
      }
    }
  }

  quiescence(chess: Chess, alpha: number, beta: number, side: number, ply: number): number {
    this._checkTime();
    const standPat = side * evaluate(chess);
    if (standPat >= beta) return beta;
    if (standPat > alpha) alpha = standPat;

    const moves = chess.legalMoves().filter((m) => m.capture || m.promotion);
    moves.sort((a, b) => mvvLva(b) - mvvLva(a));

    for (const m of moves) {
      const undo = chess._applyRaw(m);
      let score: number;
      try {
        score = -this.quiescence(chess, -beta, -alpha, -side, ply + 1);
      } finally {
        chess._undoRaw(undo);
      }
      if (score >= beta) return beta;
      if (score > alpha) alpha = score;
    }
    return alpha;
  }

  negamax(
    chess: Chess,
    depth: number,
    alpha: number,
    beta: number,
    side: number,
    ply: number,
    pv: Move[]
  ): number {
    this._checkTime();

    if (depth <= 0) {
      pv.length = 0;
      return this.quiescence(chess, alpha, beta, side, ply);
    }

    const inCheck = chess.inCheck(chess.turn);
    // Check extension: increase depth by 1 if in check to ensure tactical accuracy
    if (inCheck && depth < 16) {
      depth++;
    }

    const alphaOrig = alpha;
    const [hi, lo] = computeZobrist(chess);
    const ttIdx = this.tt.probe(hi, lo);
    let ttMove: { from: number; to: number } | null = null;

    if (ttIdx !== null) {
      if (this.tt.moveFrom[ttIdx] >= 0) {
        ttMove = { from: this.tt.moveFrom[ttIdx], to: this.tt.moveTo[ttIdx] };
      }
      if (this.tt.depth[ttIdx] >= depth) {
        const s = this.tt.score[ttIdx];
        const flag = this.tt.flag[ttIdx];
        if (flag === TT_FLAG_EXACT) {
          pv.length = 0;
          return s;
        }
        if (flag === TT_FLAG_LOWER && s >= beta) {
          pv.length = 0;
          return s;
        }
        if (flag === TT_FLAG_UPPER && s <= alpha) {
          pv.length = 0;
          return s;
        }
      }
    }

    // Null Move Pruning (when not in check and not an endgame)
    if (depth >= 3 && !inCheck && beta - alpha === 1) {
      const isEnd = isEndgame(chess);
      if (!isEnd) {
        const R = depth >= 6 ? 3 : 2;
        // Make null move
        chess.turn = chess.turn === 'w' ? 'b' : 'w';
        const epSave = chess.ep;
        chess.ep = -1;
        let nullScore: number;
        const nullPv: Move[] = [];
        try {
          nullScore = -this.negamax(chess, depth - 1 - R, -beta, -beta + 1, -side, ply + 1, nullPv);
        } finally {
          chess.turn = chess.turn === 'w' ? 'b' : 'w';
          chess.ep = epSave;
        }
        if (nullScore >= beta) {
          return beta;
        }
      }
    }

    const moves = chess.legalMoves();
    if (moves.length === 0) {
      pv.length = 0;
      if (inCheck) return -MATE + ply;
      return 0; // Stalemate
    }

    const killer = this.killers[ply];
    moves.sort((a, b) => {
      const aTT = ttMove && a.from === ttMove.from && a.to === ttMove.to ? 1000000 : 0;
      const bTT = ttMove && b.from === ttMove.from && b.to === ttMove.to ? 1000000 : 0;
      const av = aTT + mvvLva(a) + (killer && a.from === killer.from && a.to === killer.to ? 5000 : 0);
      const bv = bTT + mvvLva(b) + (killer && b.from === killer.from && b.to === killer.to ? 5000 : 0);
      return bv - av;
    });

    let best = -INF;
    let bestMove: Move | null = null;
    const childPV: Move[] = [];
    let moveCount = 0;

    for (const m of moves) {
      moveCount++;
      const undo = chess._applyRaw(m);
      let score: number;

      // Late Move Reduction (LMR): Reduce depth for later quiet moves
      const isQuiet = !m.capture && !m.promotion && !inCheck;
      let reduction = 0;
      if (depth >= 3 && moveCount > 3 && isQuiet) {
        reduction = moveCount > 6 ? 2 : 1;
        if (depth - 1 - reduction < 1) reduction = depth - 2;
      }

      try {
        if (reduction > 0) {
          // Reduced search
          score = -this.negamax(chess, depth - 1 - reduction, -alpha - 1, -alpha, -side, ply + 1, childPV);
          // Re-search at full depth if it improved alpha
          if (score > alpha) {
            score = -this.negamax(chess, depth - 1, -beta, -alpha, -side, ply + 1, childPV);
          }
        } else {
          score = -this.negamax(chess, depth - 1, -beta, -alpha, -side, ply + 1, childPV);
        }
      } finally {
        chess._undoRaw(undo);
      }

      if (score > best) {
        best = score;
        bestMove = m;
        pv.length = 0;
        pv.push(m);
        for (const x of childPV) pv.push(x);
      }
      if (best > alpha) alpha = best;
      if (alpha >= beta) {
        if (!m.capture) this.killers[ply] = m;
        break;
      }
    }

    if (bestMove) {
      const flag =
        best <= alphaOrig ? TT_FLAG_UPPER : best >= beta ? TT_FLAG_LOWER : TT_FLAG_EXACT;
      this.tt.store(
        hi,
        lo,
        depth,
        best,
        flag,
        bestMove.from,
        bestMove.to,
        bestMove.promotion ? PROMO_CODE[bestMove.promotion] : 0
      );
    }
    return best;
  }

  /**
   * Root search depth with Anti-Draw Repetition check and async yielding support.
   */
  async rootSearchDepthAsync(
    chess: Chess,
    depth: number,
    multipv: number,
    order: Move[] | null,
    timeMs: number
  ): Promise<{ order: Move[]; lines: PVLine[]; nodes: number }> {
    const side = chess.turn === 'w' ? 1 : -1;
    const moves = order ? order.slice() : chess.legalMoves();
    this.deadline = Date.now() + (timeMs || 60000);

    const baseEval = evaluate(chess) * side;
    const results: { move: Move; score: number; pv: Move[]; rawScore: number }[] = [];
    let alpha = -INF;
    const beta = INF;

    for (let i = 0; i < moves.length; i++) {
      if (this.isCancelled && this.isCancelled()) throw TIME_UP;
      if (Date.now() > this.deadline) throw TIME_UP;

      const m = moves[i];
      const undo = chess._applyRaw(m);
      const repCount = chess.repMap.get(chess._repKey()) || 0;
      const isRepetition = repCount >= 2;

      const childPV: Move[] = [];
      let score: number;
      try {
        score = -this.negamax(chess, depth - 1, -beta, -alpha, -side, 1, childPV);
      } finally {
        chess._undoRaw(undo);
      }

      const rawScore = score;

      if (isRepetition) {
        if (baseEval > 40 || score > 40) {
          score -= 400;
        } else if (baseEval < -120 || score < -120) {
          score = 0;
        }
      }

      results.push({ move: m, score, pv: [m, ...childPV], rawScore });
      if (score > alpha) alpha = score;

      // Yield every root move to give browser main thread breath room!
      if (depth >= 6) {
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }

    results.sort((a, b) => b.score - a.score);

    return {
      order: results.map((r) => r.move),
      lines: results.slice(0, multipv).map((r) => ({
        score: this._scoreForReport(r.rawScore, side),
        pv: r.pv.map((mm) => moveUci(mm)),
        depth,
      })),
      nodes: this.nodes,
    };
  }

  rootSearchDepth(
    chess: Chess,
    depth: number,
    multipv: number,
    order: Move[] | null,
    timeMs: number
  ): { order: Move[]; lines: PVLine[]; nodes: number } {
    const side = chess.turn === 'w' ? 1 : -1;
    const moves = order ? order.slice() : chess.legalMoves();
    this.deadline = Date.now() + (timeMs || 60000);

    const baseEval = evaluate(chess) * side;
    const results: { move: Move; score: number; pv: Move[]; rawScore: number }[] = [];
    let alpha = -INF;
    const beta = INF;

    for (const m of moves) {
      const undo = chess._applyRaw(m);
      const repCount = chess.repMap.get(chess._repKey()) || 0;
      const isRepetition = repCount >= 2;

      const childPV: Move[] = [];
      let score: number;
      try {
        score = -this.negamax(chess, depth - 1, -beta, -alpha, -side, 1, childPV);
      } finally {
        chess._undoRaw(undo);
      }

      const rawScore = score;

      if (isRepetition) {
        if (baseEval > 40 || score > 40) {
          score -= 400;
        } else if (baseEval < -120 || score < -120) {
          score = 0;
        }
      }

      results.push({ move: m, score, pv: [m, ...childPV], rawScore });
      if (score > alpha) alpha = score;
    }

    results.sort((a, b) => b.score - a.score);

    return {
      order: results.map((r) => r.move),
      lines: results.slice(0, multipv).map((r) => ({
        score: this._scoreForReport(r.rawScore, side),
        pv: r.pv.map((mm) => moveUci(mm)),
        depth,
      })),
      nodes: this.nodes,
    };
  }

  searchMultiPV(
    chess: Chess,
    options: {
      maxDepth?: number;
      multipv?: number;
      timeMs?: number;
      onInfo?: (info: { depth: number; nodes: number; nps: number; timeMs: number; lines: PVLine[] }) => void;
    } = {}
  ): {
    depth: number;
    nodes: number;
    nps: number;
    timeMs: number;
    lines: PVLine[];
    bestMove: string | null;
  } {
    const maxDepth = options.maxDepth || 8;
    const multipv = Math.max(1, options.multipv || 1);
    const timeMs = options.timeMs || 2000;
    this.nodes = 0;
    this.killers = {};

    let order: Move[] | null = null;
    let lastResult: { order: Move[]; lines: PVLine[]; nodes: number } | null = null;
    let completedDepth = 0;
    const t0 = Date.now();

    for (let d = 1; d <= maxDepth; d++) {
      const remaining = timeMs - (Date.now() - t0);
      if (remaining <= 0) break;

      let res: { order: Move[]; lines: PVLine[]; nodes: number };
      try {
        res = this.rootSearchDepth(chess, d, multipv, order, remaining);
      } catch (e) {
        if (e === TIME_UP) break;
        throw e;
      }

      order = res.order;
      lastResult = res;
      completedDepth = d;
      const elapsed = Math.max(1, Date.now() - t0);

      if (options.onInfo) {
        options.onInfo({
          depth: d,
          nodes: res.nodes,
          nps: Math.round(res.nodes / (elapsed / 1000)),
          timeMs: elapsed,
          lines: res.lines,
        });
      }

      if (res.lines[0] && res.lines[0].score.mate !== undefined && Math.abs(res.lines[0].score.mate) < 1000) {
        break;
      }
      if (Date.now() - t0 > timeMs) break;
    }

    const elapsed = Math.max(1, Date.now() - t0);
    const lines = lastResult ? lastResult.lines : [];
    return {
      depth: completedDepth,
      nodes: this.nodes,
      nps: Math.round(this.nodes / (elapsed / 1000)),
      timeMs: elapsed,
      lines,
      bestMove: lines[0] && lines[0].pv[0] ? lines[0].pv[0] : null,
    };
  }

  _scoreForReport(scoreFromSideToMove: number, side: number): EngineScore {
    const whiteScore = scoreFromSideToMove * side;
    if (Math.abs(whiteScore) > MATE - 1000) {
      const pliesToMate = MATE - Math.abs(whiteScore);
      const movesToMate = Math.ceil(pliesToMate / 2);
      return { mate: whiteScore > 0 ? movesToMate : -movesToMate };
    }
    return { cp: whiteScore };
  }
}
