import { GameTreeNode, MoveClassification, EngineScore } from '../types/chess';
import { Chess, sqName, nameToSq, START_FEN } from './chessRules';
import { findOpening } from './openingBook';

function todayTag(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())}`;
}

export class GameTree {
  rootFEN: string;
  chess: Chess;
  root: GameTreeNode;
  current: GameTreeNode;
  private nextId: number;
  tags: Record<string, string>;

  constructor(input?: string) {
    this.rootFEN = START_FEN;
    this.chess = new Chess(START_FEN);
    this.root = {
      id: 0,
      parent: null,
      children: [],
      san: null,
      ply: 0,
      uci: null,
      fenBefore: START_FEN,
      fenAfter: START_FEN,
      comment: '',
      nags: [],
    };
    this.current = this.root;
    this.nextId = 1;
    this.tags = {
      Event: 'Casual Game',
      Site: 'Aperture Chess',
      Date: todayTag(),
      Round: '-',
      White: 'White',
      Black: 'Black',
      Result: '*',
    };

    if (input && typeof input === 'string') {
      const trimmed = input.trim();
      if (trimmed) {
        // If it starts with [ or has PGN tags or move notation like 1. e4
        if (
          trimmed.startsWith('[') ||
          trimmed.includes('\n[') ||
          /\b1\.\s*[a-zA-Z]/.test(trimmed) ||
          trimmed.includes('1-0') ||
          trimmed.includes('0-1') ||
          trimmed.includes('1/2-1/2')
        ) {
          try {
            this.loadPGN(trimmed);
            return;
          } catch (err) {
            console.warn('Could not load PGN in GameTree constructor, falling back to START_FEN:', err);
          }
        } else {
          // Attempt to load as FEN
          try {
            const testChess = new Chess(trimmed);
            this.reset(testChess.fen());
            return;
          } catch (err) {
            console.warn('Invalid FEN passed to GameTree constructor, using START_FEN:', trimmed, err);
          }
        }
      }
    }
  }

  static fromPGN(pgn: string): GameTree {
    const tree = new GameTree();
    tree.loadPGN(pgn);
    return tree;
  }

  static fromFEN(fen: string): GameTree {
    return new GameTree(fen);
  }

  clone(): GameTree {
    const newTree = new GameTree(this.rootFEN);
    newTree.tags = { ...this.tags };
    newTree.nextId = this.nextId;

    const cloneNode = (node: GameTreeNode, parent: GameTreeNode | null): GameTreeNode => {
      const copy: GameTreeNode = {
        id: node.id,
        parent,
        children: [],
        san: node.san,
        ply: node.ply,
        uci: node.uci ? { ...node.uci } : null,
        fenBefore: node.fenBefore,
        fenAfter: node.fenAfter,
        comment: node.comment || '',
        nags: node.nags ? [...node.nags] : [],
        evalScore: node.evalScore ? { ...node.evalScore } : undefined,
        classification: node.classification,
        bestMoveSan: node.bestMoveSan,
      };
      copy.children = node.children.map((child) => cloneNode(child, copy));
      return copy;
    };

    newTree.root = cloneNode(this.root, null);

    const findNodeById = (node: GameTreeNode, id: number): GameTreeNode | null => {
      if (node.id === id) return node;
      for (const child of node.children) {
        const found = findNodeById(child, id);
        if (found) return found;
      }
      return null;
    };

    newTree.current = findNodeById(newTree.root, this.current.id) || newTree.root;
    newTree.chess = new Chess(newTree.current.fenAfter || newTree.rootFEN);
    return newTree;
  }

  reset(fen?: string): void {
    const cleanFen = fen && typeof fen === 'string' && fen.trim() ? fen.trim() : START_FEN;
    try {
      this.chess = new Chess(cleanFen);
      this.rootFEN = cleanFen;
    } catch {
      this.chess = new Chess(START_FEN);
      this.rootFEN = START_FEN;
    }
    this.root = {
      id: 0,
      parent: null,
      children: [],
      san: null,
      ply: 0,
      uci: null,
      fenBefore: this.rootFEN,
      fenAfter: this.rootFEN,
      comment: '',
      nags: [],
    };
    this.current = this.root;
    this.nextId = 1;
    this.tags = {
      Event: 'Casual Game',
      Site: 'Aperture Chess',
      Date: todayTag(),
      Round: '-',
      White: 'White',
      Black: 'Black',
      Result: '*',
    };
    if (this.rootFEN !== START_FEN) {
      this.tags.SetUp = '1';
      this.tags.FEN = this.rootFEN;
    }
  }

  private syncTo(node: GameTreeNode): void {
    this.chess.load(this.rootFEN);
    const path: GameTreeNode[] = [];
    let n: GameTreeNode | null = node;
    while (n && n.parent) {
      path.unshift(n);
      n = n.parent;
    }
    for (const step of path) {
      if (!step.uci) continue;
      const r = this.chess.move({
        from: step.uci.from,
        to: step.uci.to,
        promotion: step.uci.promotion || undefined,
      });
      if (!r) {
        console.warn('Could not replay step', step.san);
      }
    }
  }

  goTo(node: GameTreeNode): GameTreeNode {
    this.current = node;
    this.syncTo(node);
    return node;
  }

  back(): GameTreeNode {
    if (this.current.parent) {
      return this.goTo(this.current.parent);
    }
    return this.current;
  }

  forward(idx: number = 0): GameTreeNode {
    if (this.current.children[idx]) {
      return this.goTo(this.current.children[idx]);
    }
    return this.current;
  }

  toStart(): GameTreeNode {
    return this.goTo(this.root);
  }

  toEnd(): GameTreeNode {
    let n = this.current;
    while (n.children[0]) n = n.children[0];
    return this.goTo(n);
  }

  addMove(from: string, to: string, promotion?: string | null): GameTreeNode | null {
    this.syncTo(this.current);
    const promoUpper = promotion ? promotion.toUpperCase() : undefined;
    const legal = this.chess.legalMoves();

    let mv = legal.find(
      (m) =>
        sqName(m.from) === from &&
        sqName(m.to) === to &&
        (!promoUpper || (m.promotion && m.promotion.toUpperCase() === promoUpper))
    );

    if (!mv && !promoUpper) {
      mv = legal.find(
        (m) => sqName(m.from) === from && sqName(m.to) === to && (!m.promotion || m.promotion === 'Q')
      );
    }

    // Support Chess960 castling where player/bot designates king-to-rook or rook-square destination
    if (!mv && from && to) {
      const fromSq = nameToSq(from);
      const toSq = nameToSq(to);
      if (fromSq >= 0 && toSq >= 0) {
        const pFrom = this.chess.board[fromSq];
        const pTo = this.chess.board[toSq];
        if (pFrom && pFrom.toUpperCase() === 'K' && pTo && pTo.toUpperCase() === 'R' && (pFrom === pFrom.toUpperCase()) === (pTo === pTo.toUpperCase())) {
          const kFile = fromSq % 8;
          const rFile = toSq % 8;
          const castleSide = rFile > kFile ? 'k' : 'q';
          mv = legal.find((m) => m.from === fromSq && m.castle === castleSide);
        }
      }
    }

    if (!mv) return null;

    const existing = this.current.children.find(
      (ch) =>
        ch.uci &&
        ch.uci.from === from &&
        ch.uci.to === to &&
        (ch.uci.promotion || null) === (mv!.promotion || null)
    );

    const result = this.chess.move({
      from,
      to,
      promotion: mv.promotion,
    });
    if (!result) return null;

    if (existing) {
      this.current = existing;
      return existing;
    }

    const node: GameTreeNode = {
      id: this.nextId++,
      parent: this.current,
      children: [],
      san: result.san,
      ply: this.current.ply + 1,
      uci: { from, to, promotion: mv.promotion || null },
      fenBefore: result.fenBefore,
      fenAfter: result.fenAfter,
      comment: '',
      nags: [],
    };

    this.current.children.push(node);
    this.current = node;
    return node;
  }

  playSAN(token: string): GameTreeNode | null {
    this.syncTo(this.current);
    const legal = this.chess.legalMoves();
    const mv = this.chess._matchSAN(token, legal);
    if (!mv) return null;
    return this.addMove(sqName(mv.from), sqName(mv.to), mv.promotion || null);
  }

  setComment(text: string): void {
    this.current.comment = text;
  }

  deleteNode(node?: GameTreeNode): boolean {
    const target = node || this.current;
    if (!target.parent) return false;
    const parent = target.parent;
    const idx = parent.children.indexOf(target);
    if (idx < 0) return false;

    parent.children.splice(idx, 1);
    if (this.isDescendantOrSelf(this.current, target)) {
      this.goTo(parent);
    }
    return true;
  }

  private isDescendantOrSelf(n: GameTreeNode | null, ancestor: GameTreeNode): boolean {
    let cur = n;
    while (cur) {
      if (cur === ancestor) return true;
      cur = cur.parent;
    }
    return false;
  }

  promoteToMainline(node?: GameTreeNode): boolean {
    const target = node || this.current;
    if (!target.parent) return false;
    const parent = target.parent;
    const idx = parent.children.indexOf(target);
    if (idx <= 0) return false;

    parent.children.splice(idx, 1);
    parent.children.unshift(target);
    return true;
  }

  activeLine(): GameTreeNode[] {
    const up: GameTreeNode[] = [];
    let n: GameTreeNode | null = this.current;
    while (n) {
      up.unshift(n);
      n = n.parent;
    }
    let last = this.current;
    while (last.children[0]) {
      last = last.children[0];
      up.push(last);
    }
    return up;
  }

  mainline(): GameTreeNode[] {
    const out: GameTreeNode[] = [];
    let n: GameTreeNode = this.root;
    while (n.children[0]) {
      n = n.children[0];
      out.push(n);
    }
    return out;
  }

  pathToCurrent(): GameTreeNode[] {
    const up: GameTreeNode[] = [];
    let n: GameTreeNode | null = this.current;
    while (n) {
      up.unshift(n);
      n = n.parent;
    }
    return up;
  }

  currentOpening() {
    const sanList = this.pathToCurrent()
      .slice(1)
      .map((n) => n.san)
      .filter(Boolean) as string[];
    return findOpening(sanList);
  }

  toPGN(overrideTags?: Record<string, string>): string {
    const combinedTags = { ...this.tags, ...(overrideTags || {}) };
    const order = ['Event', 'Site', 'Date', 'Round', 'White', 'Black', 'Result'];
    const extra = [
      'WhiteElo',
      'BlackElo',
      'ECO',
      'Opening',
      'Variation',
      'TimeControl',
      'Termination',
      'SetUp',
      'FEN',
    ];
    const lines = order.map((k) => `[${k} "${combinedTags[k] || (k === 'Result' ? '*' : '?')}"]`);
    for (const k of extra) {
      if (combinedTags[k]) lines.push(`[${k} "${combinedTags[k]}"]`);
    }
    // Also include any other custom tags passed in
    if (overrideTags) {
      for (const [k, v] of Object.entries(overrideTags)) {
        if (!order.includes(k) && !extra.includes(k) && v) {
          lines.push(`[${k} "${v}"]`);
        }
      }
    }
    let out = lines.join('\n') + '\n\n';
    const body = this.serializeChildren(this.root, false);
    out += (body ? body + ' ' : '') + (combinedTags.Result || '*');
    return out;
  }

  private moveText(node: GameTreeNode, showNumber: boolean): string {
    const num = Math.ceil(node.ply / 2);
    let s = node.ply % 2 === 1 ? num + '. ' : showNumber ? num + '... ' : '';
    s += node.san;
    for (const n of node.nags || []) s += ' $' + n;
    if (node.comment) s += ' {' + String(node.comment).replace(/[{}]/g, '') + '}';
    return s;
  }

  private serializeChildren(node: GameTreeNode, forceNumberOnMain: boolean): string {
    if (!node.children.length) return '';
    const kids = node.children;
    const main = kids[0];
    let out = this.moveText(main, forceNumberOnMain);

    for (let i = 1; i < kids.length; i++) {
      const varNode = kids[i];
      let vtext = this.moveText(varNode, true);
      const vcont = this.serializeChildren(varNode, false);
      if (vcont) vtext += ' ' + vcont;
      out += ' (' + vtext + ')';
    }

    const mainCont = this.serializeChildren(main, kids.length > 1 || !!main.comment);
    if (mainCont) out += ' ' + mainCont;
    return out;
  }

  loadPGN(pgnText: string): { warnings: string[] } {
    const { tags, movetext } = stripTags(pgnText);
    const fen = tags.FEN || START_FEN;
    this.reset(fen);
    this.tags = Object.assign(this.tags, tags);

    if (!movetext || !movetext.trim()) return { warnings: [] };
    const tokens = tokenizePGN(movetext);
    const warnings: string[] = [];
    this.buildFromTokens(tokens, warnings);
    this.goTo(this.root);
    return { warnings };
  }

  private buildFromTokens(tokens: any[], warnings: string[]) {
    let idx = 0;
    const parseLine = () => {
      while (idx < tokens.length) {
        const t = tokens[idx];
        if (t.type === 'result') {
          this.tags.Result = t.value;
          idx++;
          continue;
        }
        if (t.type === 'rparen') {
          return;
        }
        if (t.type === 'lparen') {
          idx++;
          const saved = this.current;
          if (saved.parent) {
            this.goTo(saved.parent);
            parseLine();
          } else {
            let depth = 1;
            while (idx < tokens.length && depth > 0) {
              if (tokens[idx].type === 'lparen') depth++;
              else if (tokens[idx].type === 'rparen') depth--;
              idx++;
            }
            idx--;
          }
          if (tokens[idx] && tokens[idx].type === 'rparen') idx++;
          this.goTo(saved);
          continue;
        }
        if (t.type === 'nag') {
          this.current.nags.push(t.value);
          idx++;
          continue;
        }
        if (t.type === 'comment') {
          this.current.comment = (this.current.comment ? this.current.comment + ' ' : '') + t.value;
          idx++;
          continue;
        }
        if (t.type === 'san') {
          const res = this.playSAN(t.value);
          if (!res) {
            warnings.push(
              `Skipped unrecognized move "${t.value}" near move ${Math.ceil((this.current.ply + 1) / 2)}`
            );
          }
          idx++;
          continue;
        }
        idx++;
      }
    };
    parseLine();
  }
}

function stripTags(text: string) {
  const tags: Record<string, string> = {};
  const tagRe = /\[(\w+)\s+"((?:[^"\\]|\\.)*)"\]/g;
  let m: RegExpExecArray | null;
  let lastIndex = 0;
  while ((m = tagRe.exec(text))) {
    tags[m[1]] = m[2].replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    lastIndex = m.index + m[0].length;
  }
  return { tags, movetext: text.slice(lastIndex) };
}

function tokenizePGN(movetext: string) {
  const s = movetext.replace(/;[^\n\r]*/g, ' ');
  const tokens: any[] = [];
  let i = 0;
  const n = s.length;

  while (i < n) {
    const ch = s[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    if (ch === '{') {
      const end = s.indexOf('}', i);
      const content = end < 0 ? s.slice(i + 1) : s.slice(i + 1, end);
      tokens.push({ type: 'comment', value: content.trim() });
      i = end < 0 ? n : end + 1;
      continue;
    }
    if (ch === '(') {
      tokens.push({ type: 'lparen' });
      i++;
      continue;
    }
    if (ch === ')') {
      tokens.push({ type: 'rparen' });
      i++;
      continue;
    }
    if (ch === '$') {
      let j = i + 1;
      while (j < n && /\d/.test(s[j])) j++;
      tokens.push({ type: 'nag', value: s.slice(i + 1, j) });
      i = j;
      continue;
    }

    let j = i;
    while (j < n && !/[\s(){}]/.test(s[j])) j++;
    let raw = s.slice(i, j);
    i = j;

    if (/^(1-0|0-1|1\/2-1\/2|\*)$/.test(raw)) {
      tokens.push({ type: 'result', value: raw });
      continue;
    }
    if (/^\d+\.(\.\.)?$/.test(raw)) continue;
    const glued = raw.match(/^\d+\.(\.\.)?(.+)$/);
    if (glued) raw = glued[2];
    raw = raw.replace(/[!?]+$/, '');
    if (raw) tokens.push({ type: 'san', value: raw });
  }
  return tokens;
}
