/**
 * Game Review Engine: Full Move-by-Move Analysis, Win Probabilities,
 * Accuracy Percentages, and Tactical Classification.
 */

import { GameTree } from './gameTree';
import { Chess } from './chessRules';
import { Searcher } from './search';
import { GameTreeNode, MoveClassification, EngineScore } from '../types/chess';
import { findBookMoves } from './openingBook';

export interface MoveReviewResult {
  node: GameTreeNode;
  ply: number;
  moverColor: 'w' | 'b';
  san: string;
  beforeEval: number; // centipawns
  afterEval: number; // centipawns
  cpLoss: number;
  classification: MoveClassification;
  explanation: string;
  bestSan?: string;
  bestUci?: string;
}

export interface GameReviewReport {
  whiteAccuracy: number;
  blackAccuracy: number;
  whiteAvgLoss: number;
  blackAvgLoss: number;
  whiteCounts: Record<MoveClassification, number>;
  blackCounts: Record<MoveClassification, number>;
  moves: MoveReviewResult[];
}

export class GameReviewer {
  private searcher: Searcher = new Searcher();

  private winProb(cpForMover: number): number {
    return 50 + 50 * Math.tanh(cpForMover / 380);
  }

  private classifyLoss(cpLoss: number): MoveClassification {
    if (cpLoss <= 12) return 'best';
    if (cpLoss <= 28) return 'excellent';
    if (cpLoss <= 55) return 'good';
    if (cpLoss <= 110) return 'inaccuracy';
    if (cpLoss <= 230) return 'mistake';
    return 'blunder';
  }

  public async runReview(
    tree: GameTree,
    onProgress?: (current: number, total: number) => void
  ): Promise<GameReviewReport> {
    const mainline = tree.mainline();
    if (!mainline.length) {
      throw new Error('No moves to review.');
    }

    const positions: string[] = [tree.rootFEN, ...mainline.map((n) => n.fenAfter)];
    const evals: { score: EngineScore; cp: number; bestUci?: string }[] = [];

    // Analyze each position
    for (let i = 0; i < positions.length; i++) {
      if (onProgress) onProgress(i + 1, positions.length);

      const fen = positions[i];
      const chess = new Chess(fen);
      const res = this.searcher.searchMultiPV(chess, { maxDepth: 8, multipv: 1, timeMs: 250 });

      const top = res.lines[0];
      let cp = 0;
      if (top) {
        if (top.score.mate !== undefined) {
          cp = top.score.mate > 0 ? 3000 : -3000;
        } else {
          cp = top.score.cp || 0;
        }
      }

      evals.push({
        score: top ? top.score : { cp: 0 },
        cp,
        bestUci: res.bestMove || undefined,
      });

      if (i === 0) {
        tree.root.evalScore = top ? top.score : { cp: 0 };
        tree.root.evalCp = cp;
      } else if (mainline[i - 1]) {
        mainline[i - 1].evalScore = top ? top.score : { cp: 0 };
        mainline[i - 1].evalCp = cp;
      }

      // Small tick to ensure UI renders
      await new Promise((r) => setTimeout(r, 0));
    }

    const results: MoveReviewResult[] = [];
    const sideStats = {
      w: {
        count: 0,
        cplSum: 0,
        accSum: 0,
        counts: {
          brilliant: 0,
          best: 0,
          excellent: 0,
          good: 0,
          book: 0,
          inaccuracy: 0,
          mistake: 0,
          blunder: 0,
          missedwin: 0,
        } as Record<MoveClassification, number>,
      },
      b: {
        count: 0,
        cplSum: 0,
        accSum: 0,
        counts: {
          brilliant: 0,
          best: 0,
          excellent: 0,
          good: 0,
          book: 0,
          inaccuracy: 0,
          mistake: 0,
          blunder: 0,
          missedwin: 0,
        } as Record<MoveClassification, number>,
      },
    };

    for (let i = 0; i < mainline.length; i++) {
      const node = mainline[i];
      const moverColor: 'w' | 'b' = positions[i].split(/\s+/)[1] === 'b' ? 'b' : 'w';

      const evalBeforeRaw = evals[i].cp;
      const evalAfterRaw = evals[i + 1].cp;

      const beforeMover = moverColor === 'w' ? evalBeforeRaw : -evalBeforeRaw;
      const afterMover = moverColor === 'w' ? evalAfterRaw : -evalAfterRaw;
      const cpLoss = Math.max(0, Math.min(1000, beforeMover - afterMover));

      const bookPath = mainline.slice(0, i).map((n) => n.san || '');
      const isBook = i < 20 && findBookMoves(bookPath, positions[i]).includes(node.san || '');

      const hadForcedWin = beforeMover >= 400;
      const lostAdvantage = hadForcedWin && afterMover <= 100;
      const isMissedWin = lostAdvantage;

      // Brilliant Move Heuristic: An objective top move that makes a verified material sacrifice
      let isBrilliant = false;
      if (!isMissedWin && cpLoss <= 8 && Math.abs(beforeMover) < 700 && i + 2 < positions.length) {
        try {
          const cBefore = new Chess(positions[i]);
          const cAfter = new Chess(positions[i + 2]);
          const matBefore =
            cBefore.material(moverColor) - cBefore.material(moverColor === 'w' ? 'b' : 'w');
          const matAfter =
            cAfter.material(moverColor) - cAfter.material(moverColor === 'w' ? 'b' : 'w');
          if ((cBefore.legalMoves().length > 1) && matBefore - matAfter >= 2) {
            isBrilliant = true;
          }
        } catch (e) {
          // ignore
        }
      }

      const cls: MoveClassification = isBrilliant
        ? 'brilliant'
        : isMissedWin
        ? 'missedwin'
        : isBook
        ? 'book'
        : this.classifyLoss(cpLoss);

      node.classification = cls;

      let explanation = '';
      if (cls === 'brilliant') explanation = 'A sensational sacrifice that retains an overwhelming attack!';
      else if (cls === 'best') explanation = 'The optimal continuation found by deep tactical search.';
      else if (cls === 'excellent') explanation = 'A strong, accurate move preserving the advantage.';
      else if (cls === 'good') explanation = 'A solid, playable move maintaining standard play.';
      else if (cls === 'book') explanation = 'Established grandmaster opening theory.';
      else if (cls === 'inaccuracy') explanation = `Slightly imprecise (${(cpLoss / 100).toFixed(2)} cp swing).`;
      else if (cls === 'mistake') explanation = `A significant error allowing opponent counterplay.`;
      else if (cls === 'blunder') explanation = `A decisive tactical mistake turning the evaluation.`;
      else if (cls === 'missedwin') explanation = `Missed a clear forced winning tactical continuation.`;

      const stats = sideStats[moverColor];
      stats.count++;
      stats.cplSum += cpLoss;
      stats.counts[cls] = (stats.counts[cls] || 0) + 1;

      const wpBefore = this.winProb(beforeMover);
      const wpAfter = this.winProb(afterMover);
      const moveAcc = Math.max(0, Math.min(100, 100 - (wpBefore - wpAfter)));
      stats.accSum += moveAcc;

      results.push({
        node,
        ply: node.ply,
        moverColor,
        san: node.san || '',
        beforeEval: beforeMover,
        afterEval: afterMover,
        cpLoss,
        classification: cls,
        explanation,
        bestUci: evals[i].bestUci,
      });
    }

    const calcAccuracy = (s: typeof sideStats.w) => (s.count ? s.accSum / s.count : 100);
    const calcAvgLoss = (s: typeof sideStats.w) => (s.count ? s.cplSum / s.count : 0);

    return {
      whiteAccuracy: Number(calcAccuracy(sideStats.w).toFixed(1)),
      blackAccuracy: Number(calcAccuracy(sideStats.b).toFixed(1)),
      whiteAvgLoss: Number(calcAvgLoss(sideStats.w).toFixed(1)),
      blackAvgLoss: Number(calcAvgLoss(sideStats.b).toFixed(1)),
      whiteCounts: sideStats.w.counts,
      blackCounts: sideStats.b.counts,
      moves: results,
    };
  }
}
