/**
 * Dynamic Procedural Tactical Puzzle Generation Engine.
 * Generates verified, non-repetitive chess puzzles dynamically using
 * the Negamax search engine with multi-PV tactical validation.
 */

import { Puzzle, PieceColor, PieceType } from '../types/chess';
import { Chess, sqName, nameToSq, onBoard, colorOf, FILES, RANKS } from './chessRules';
import { Searcher } from './search';

export type PuzzleCategory =
  | 'mate'
  | 'fork'
  | 'pin'
  | 'skewer'
  | 'sacrifice'
  | 'discovered'
  | 'trapped'
  | 'endgame'
  | 'all';

interface TacticalBlueprint {
  category: 'mate' | 'fork' | 'pin' | 'skewer' | 'sacrifice' | 'discovered' | 'trapped' | 'endgame';
  theme: string;
  baseRating: number;
  fen: string;
  description: string;
  dynamicVariations?: string[];
}

/**
 * Extensive library of foundational tactical matrices covering every tactical motif.
 */
const TACTICAL_BLUEPRINTS: TacticalBlueprint[] = [
  // ==========================================
  // 1. CHECKMATES & MATING NETS (800 - 2300)
  // ==========================================
  {
    category: 'mate',
    theme: 'Back-Rank Mate with Rook Penetration',
    baseRating: 850,
    fen: '6k1/5ppp/8/8/8/8/8/R6K w - - 0 1',
    description: 'The enemy king is trapped behind its own pawn shield. Deliver checkmate on the 8th rank.',
  },
  {
    category: 'mate',
    theme: 'Queen Back-Rank Infiltration',
    baseRating: 900,
    fen: '6k1/5ppp/8/8/8/1Q6/8/6K1 w - - 0 1',
    description: 'Infiltrate with the queen to execute a decisive back-rank checkmate.',
  },
  {
    category: 'mate',
    theme: 'Rook Ladder Checkmate',
    baseRating: 950,
    fen: '7k/8/8/8/8/8/6R1/R6K w - - 0 1',
    description: 'Coordinate the two rooks to construct an inescapable mating net along the files.',
  },
  {
    category: 'mate',
    theme: 'Smothered Mate Pattern',
    baseRating: 1400,
    fen: '6k1/5ppp/8/4N3/8/8/5PPP/4Q1K1 w - - 0 1',
    description: 'Punish the defender’s trapped king behind their congested pawn structure.',
  },
  {
    category: 'mate',
    theme: 'Anastasia’s Mate (Knight & Rook)',
    baseRating: 1550,
    fen: '5rk1/1p3ppp/8/4N3/8/8/5PPP/1R4K1 w - - 0 1',
    description: 'Use the dominant knight and rook to penetrate Black’s fragile kingside structure.',
  },
  {
    category: 'mate',
    theme: 'Arabian Mate (Rook & Knight)',
    baseRating: 1450,
    fen: '7k/7p/5N2/8/8/8/8/R6K w - - 0 1',
    description: 'The knight on f6 locks down the king’s escape squares for the rook.',
  },
  {
    category: 'mate',
    theme: 'Boden’s Mate (Criss-Cross Bishops)',
    baseRating: 1600,
    fen: '2kr3r/pp1n1ppp/2p1p3/8/1b1PB3/8/PPP2PPP/R1B2RK1 w - - 0 1',
    description: 'Crush the castled queenside with dual active bishop diagonals.',
  },
  {
    category: 'mate',
    theme: 'Epaulette Mate Pattern',
    baseRating: 1250,
    fen: '3rkr2/8/8/8/8/8/8/3Q2K1 w - - 0 1',
    description: 'The defending rooks block the king’s escape on both flanks.',
  },
  {
    category: 'mate',
    theme: 'Hook Mate Coordination',
    baseRating: 1500,
    fen: '5rk1/5p1p/4pNp1/8/8/8/5PPP/1R4K1 w - - 0 1',
    description: 'Coordinated knight and rook form an airtight mating net.',
  },
  {
    category: 'mate',
    theme: 'Damiano’s Bishop & Queen Mate',
    baseRating: 1350,
    fen: '6k1/5p1p/6p1/8/8/7Q/5PPP/4R1K1 w - - 0 1',
    description: 'Infiltrate the dark squares around the exposed enemy monarch.',
  },
  {
    category: 'mate',
    theme: 'Blackburne’s Dual Bishop Mate',
    baseRating: 1650,
    fen: 'r4rk1/ppp2ppp/8/8/1B6/8/PPP2PPP/3RR1K1 w - - 0 1',
    description: 'Slice through the king’s defenses with active long-range bishops.',
  },
  {
    category: 'mate',
    theme: 'Morphy’s Open Rook & Bishop Mate',
    baseRating: 1500,
    fen: '5rk1/5ppp/8/8/8/8/1B3PPP/1R4K1 w - - 0 1',
    description: 'Exploit open central files to trap the undefended king.',
  },
  {
    category: 'mate',
    theme: 'Greco’s Mate (Bishop & Rook Battery)',
    baseRating: 1400,
    fen: '6k1/5ppp/8/8/8/8/1B3PPP/R6K w - - 0 1',
    description: 'Combine the dark-squared bishop and rook to trap the king in the corner.',
  },
  {
    category: 'mate',
    theme: 'Dovetail Mate (Cozio’s Pattern)',
    baseRating: 1300,
    fen: '3k4/1p1p4/8/8/8/8/8/4Q1K1 w - - 0 1',
    description: 'Queen delivers checkmate adjacent to the king while friendly pieces block escape.',
  },
  {
    category: 'mate',
    theme: 'Kill Box Mate (Rook & Queen Box)',
    baseRating: 1450,
    fen: '4k3/4r3/8/8/8/8/8/4R1KQ w - - 0 1',
    description: 'Coordinate heavy pieces to trap the monarch in a tight 3x3 kill box.',
  },

  // ==========================================
  // 2. FORKS & DOUBLE ATTACKS (900 - 1850)
  // ==========================================
  {
    category: 'fork',
    theme: 'Royal Knight Fork on c7',
    baseRating: 1000,
    fen: 'r3k3/8/8/3N4/8/8/8/4K3 w - - 0 1',
    description: 'Check the king while simultaneously attacking the unprotected rook on a8.',
  },
  {
    category: 'fork',
    theme: 'Central Pawn Fork on Minors',
    baseRating: 1100,
    fen: 'r1bqk2r/pppp1ppp/2n5/4p3/3bn3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1',
    description: 'Advance the central pawn to strike two minor pieces at once.',
  },
  {
    category: 'fork',
    theme: 'Queen Fork on King & Loose Rook',
    baseRating: 1250,
    fen: 'r3k3/8/8/8/8/8/8/Q3K3 w - - 0 1',
    description: 'Deliver a powerful diagonal queen check that wins the undefended rook.',
  },
  {
    category: 'fork',
    theme: 'Knight Fork on Queen & Rook',
    baseRating: 1350,
    fen: 'r3r1k1/ppp2ppp/8/3N4/8/q7/PPP2PPP/R4RK1 w - - 0 1',
    description: 'Infiltrate with the knight to fork Black’s major pieces.',
  },
  {
    category: 'fork',
    theme: 'Rook Fork on 7th Rank',
    baseRating: 1400,
    fen: '4k3/4r1p1/8/8/8/8/4R1K1/8 w - - 0 1',
    description: 'Dominate the open file and fork disconnected targets.',
  },
  {
    category: 'fork',
    theme: 'Bishop Fork on Disconnected Rooks',
    baseRating: 1300,
    fen: 'r5r1/ppp2kpp/8/8/8/4B3/PPP2PPP/4K3 w - - 0 1',
    description: 'Position the bishop on a central diagonal striking both enemy rooks.',
  },
  {
    category: 'fork',
    theme: 'King & Bishop Fork via d5',
    baseRating: 1200,
    fen: 'r1bqk2r/ppp2ppp/2n2n2/3pp3/1b2P3/2NP1N2/PPP2PPP/R1BQKB1R w KQkq - 0 1',
    description: 'Execute a decisive tactical fork to shatter Black’s center.',
  },

  // ==========================================
  // 3. ABSOLUTE & RELATIVE PINS (1000 - 1800)
  // ==========================================
  {
    category: 'pin',
    theme: 'Absolute King Pin on e-File',
    baseRating: 1050,
    fen: '4k3/4r3/8/8/8/8/8/4R1K1 w - - 0 1',
    description: 'Pin the enemy rook directly to the king along the open e-file.',
  },
  {
    category: 'pin',
    theme: 'Bishop Pin on the Queen',
    baseRating: 1200,
    fen: '4k3/3q4/8/8/1B6/8/8/4K3 w - - 0 1',
    description: 'Pin the enemy queen to the king along the long diagonal.',
  },
  {
    category: 'pin',
    theme: 'Cross-Pin Pressure on c6',
    baseRating: 1550,
    fen: 'r1b1k2r/pp3ppp/2n1pn2/2qp4/8/2N1PN2/PPP2PPP/R2QKB1R w KQkq - 0 1',
    description: 'Stack multiple attacking pieces against a pinned defender.',
  },
  {
    category: 'pin',
    theme: 'Knight Pinned by Long Bishop Diagonal',
    baseRating: 1300,
    fen: 'r1bqk2r/ppp2ppp/2n5/3p4/1b1P4/2N2N2/PPP2PPP/R1BQK2R w KQkq - 0 1',
    description: 'Exploit an absolute pin to win positional or material dominance.',
  },

  // ==========================================
  // 4. SKEWERS & X-RAY ATTACKS (1100 - 1750)
  // ==========================================
  {
    category: 'skewer',
    theme: 'Linear Rook Skewer (King & Queen)',
    baseRating: 1150,
    fen: '8/8/8/8/8/k2q4/8/R3K3 w - - 0 1',
    description: 'Check the king along the rank to win the queen behind it.',
  },
  {
    category: 'skewer',
    theme: 'Bishop Skewer on King & Rook',
    baseRating: 1200,
    fen: '8/8/8/4k3/8/2B5/8/r3K3 w - - 0 1',
    description: 'Slice diagonally through the enemy king to capture the rook.',
  },
  {
    category: 'skewer',
    theme: 'Queen Skewer on Castled King',
    baseRating: 1450,
    fen: '4r1k1/5ppp/8/8/8/8/8/1Q4K1 w - - 0 1',
    description: 'Attack through the king to win the hanging piece behind.',
  },
  {
    category: 'skewer',
    theme: 'Rook X-Ray Skewer along File',
    baseRating: 1350,
    fen: '4k3/8/8/8/4q3/8/8/4R1K1 w - - 0 1',
    description: 'Pin and skewer the queen against the unprotected king.',
  },

  // ==========================================
  // 5. TACTICAL SACRIFICES (1400 - 2200)
  // ==========================================
  {
    category: 'sacrifice',
    theme: 'Greek Gift Sacrifice (Bxh7+!)',
    baseRating: 1650,
    fen: 'r1bq1rk1/ppp2ppp/2n1pn2/8/3P4/2PB1N2/P1P2PPP/R1BQR1K1 w - - 0 1',
    description: 'Sacrifice the bishop on h7 to shatter the castled king’s pawn shield.',
  },
  {
    category: 'sacrifice',
    theme: 'Queen Sacrifice for Back-Rank Mate',
    baseRating: 1750,
    fen: '4r1k1/5ppp/8/8/8/8/4QPPP/4R1K1 w - - 0 1',
    description: 'Sacrifice the queen on e8 to force an inevitable back-rank mate.',
  },
  {
    category: 'sacrifice',
    theme: 'Deflection Rook Sacrifice',
    baseRating: 1550,
    fen: '5rk1/5ppp/8/8/8/8/5PPP/1R1Q2K1 w - - 0 1',
    description: 'Deflect the key defender away from protecting the eighth rank.',
  },
  {
    category: 'sacrifice',
    theme: 'Exchange Sacrifice on c3',
    baseRating: 1800,
    fen: 'r1b2rk1/pp2ppbp/2np1np1/q7/2PNP3/2N1BP2/PP2B1PP/R2QK2R w KQ - 0 1',
    description: 'Sacrifice the exchange to destroy White’s central pawn structure.',
  },
  {
    category: 'sacrifice',
    theme: 'Bishop Clearance Sacrifice on f7',
    baseRating: 1600,
    fen: 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 1',
    description: 'Strike on f7 to draw the enemy king out into the open.',
  },

  // ==========================================
  // 6. DISCOVERED ATTACKS & BATTERIES (1200 - 1900)
  // ==========================================
  {
    category: 'discovered',
    theme: 'Discovered Check with Knight Jump',
    baseRating: 1300,
    fen: 'r1bqk2r/pppp1ppp/8/4N3/1b2n3/8/PPPP1PPP/R1BQKB1R w KQkq - 0 1',
    description: 'Move the knight to unmask a devastating queen check on the king.',
  },
  {
    category: 'discovered',
    theme: 'Discovered Attack on the Enemy Queen',
    baseRating: 1450,
    fen: 'r1b1k2r/ppp2ppp/2n5/3qp3/3P4/2P2N2/PP3PPP/R1BQKB1R w KQkq - 0 1',
    description: 'Move the blocking piece to attack the unprotected queen.',
  },
  {
    category: 'discovered',
    theme: 'Double Check (King Must Flee)',
    baseRating: 1600,
    fen: 'r1bqkb1r/pppp1Npp/2n5/4p3/2B1n3/8/PPPP1PPP/RNBQK2R w KQkq - 0 1',
    description: 'Deliver check from two pieces simultaneously, forcing an immediate king retreat.',
  },
  {
    category: 'discovered',
    theme: 'Windmill Battery Attack',
    baseRating: 1850,
    fen: '6k1/5ppp/8/8/8/8/1R3PPP/4B1K1 w - - 0 1',
    description: 'Coordinate bishop and rook for continuous discovered checks and captures.',
  },

  // ==========================================
  // 7. TRAPPED PIECES (1150 - 1750)
  // ==========================================
  {
    category: 'trapped',
    theme: 'Noah’s Ark Trap (Bishop on b3/b6)',
    baseRating: 1250,
    fen: 'r1bqk2r/1ppp1ppp/p1n5/4p3/B3P3/3P1N2/PPP2PPP/R1BQK2R w KQkq - 0 1',
    description: 'Advance flank pawns to completely trap the enemy bishop.',
  },
  {
    category: 'trapped',
    theme: 'Trapped Queen on the Queenside',
    baseRating: 1500,
    fen: 'rn2kb1r/p1p1pppp/1p6/3q4/3P4/5N2/PPP2PPP/R1BQK2R w KQkq - 0 1',
    description: 'Coordinate minor pieces to cut off all retreat squares for the queen.',
  },
  {
    category: 'trapped',
    theme: 'Trapped Knight on Corner Square (a8/h8)',
    baseRating: 1200,
    fen: 'N1b1k2r/pp1p1ppp/2n5/8/8/8/PPP2PPP/R1B1K2R w KQk - 0 1',
    description: 'Surround the stranded corner knight before it can escape.',
  },

  // ==========================================
  // 8. TACTICAL ENDGAMES (1100 - 2100)
  // ==========================================
  {
    category: 'endgame',
    theme: 'Pawn Breakthrough on the Flank',
    baseRating: 1400,
    fen: '8/ppp5/8/8/8/8/PPP5/4K2k w - - 0 1',
    description: 'Sacrifice a pawn to create an unstoppable outside passed pawn.',
  },
  {
    category: 'endgame',
    theme: 'Lucena Bridge Building Pattern',
    baseRating: 1650,
    fen: '1K1k4/1P1r4/8/8/8/8/8/2R5 w - - 0 1',
    description: 'Build a bridge with the rook on the 4th rank to escort the pawn to queen.',
  },
  {
    category: 'endgame',
    theme: 'Direct King Opposition & Outflanking',
    baseRating: 1200,
    fen: '8/8/4k3/8/4P3/8/4K3/8 w - - 0 1',
    description: 'Take the direct opposition to control key breakthrough squares.',
  },
  {
    category: 'endgame',
    theme: 'Philidor Rook Cut-Off',
    baseRating: 1500,
    fen: '8/8/8/8/3R4/4k3/4p3/4K3 w - - 0 1',
    description: 'Use the rook to cut off the enemy king from the passed pawn.',
  },
];

/**
 * Inverts board perspective (swaps colors & flips ranks) to double the variety.
 */
function flipPerspectiveFen(fen: string): string {
  const parts = fen.split(' ');
  const rows = parts[0].split('/');
  const invertedRows = rows.reverse().map((row) => {
    let newRow = '';
    for (const char of row) {
      if (!isNaN(Number(char))) {
        newRow += char;
      } else if (char === char.toUpperCase()) {
        newRow += char.toLowerCase();
      } else {
        newRow += char.toUpperCase();
      }
    }
    return newRow;
  });

  const newTurn = parts[1] === 'w' ? 'b' : 'w';
  let newCastling = '-';
  if (parts[2] && parts[2] !== '-') {
    newCastling = '';
    if (parts[2].includes('k')) newCastling += 'K';
    if (parts[2].includes('q')) newCastling += 'Q';
    if (parts[2].includes('K')) newCastling += 'k';
    if (parts[2].includes('Q')) newCastling += 'q';
    if (!newCastling) newCastling = '-';
  }

  return `${invertedRows.join('/')} ${newTurn} ${newCastling} - 0 1`;
}

/**
 * Procedurally perturb board by shifting flank pawns or adjusting pieces on harmless squares.
 */
function perturbBoardVariations(fen: string): string {
  try {
    const chess = new Chess(fen);
    const turn = chess.turn;

    // Randomize flank pawns (a-file, h-file)
    if (turn === 'w') {
      const a2 = nameToSq('a2');
      const a3 = nameToSq('a3');
      const h2 = nameToSq('h2');
      const h3 = nameToSq('h3');

      if (chess.board[a2] === 'P' && !chess.board[a3] && Math.random() < 0.45) {
        chess.board[a3] = 'P';
        chess.board[a2] = null;
      }
      if (chess.board[h2] === 'P' && !chess.board[h3] && Math.random() < 0.45) {
        chess.board[h3] = 'P';
        chess.board[h2] = null;
      }
    } else {
      const a7 = nameToSq('a7');
      const a6 = nameToSq('a6');
      const h7 = nameToSq('h7');
      const h6 = nameToSq('h6');

      if (chess.board[a7] === 'p' && !chess.board[a6] && Math.random() < 0.45) {
        chess.board[a6] = 'p';
        chess.board[a7] = null;
      }
      if (chess.board[h7] === 'p' && !chess.board[h6] && Math.random() < 0.45) {
        chess.board[h6] = 'p';
        chess.board[h7] = null;
      }
    }

    return chess.fen();
  } catch {
    return fen;
  }
}

export interface GeneratePuzzleOptions {
  category?: PuzzleCategory;
  targetRating?: number;
  theme?: string;
}

/**
 * Engine-driven procedural tactical puzzle generator.
 * Uses Negamax search to evaluate positions and synthesize tactical puzzle lines.
 */
export function generateEnginePuzzle(opts: GeneratePuzzleOptions = {}): Puzzle {
  let pool = TACTICAL_BLUEPRINTS;

  if (opts.category && opts.category !== 'all') {
    const filtered = pool.filter((b) => b.category === opts.category);
    if (filtered.length > 0) pool = filtered;
  }

  if (opts.targetRating) {
    const target = opts.targetRating;
    const ratingFiltered = pool.filter((b) => Math.abs(b.baseRating - target) <= 500);
    if (ratingFiltered.length > 0) pool = ratingFiltered;
  }

  // Random blueprint selection
  const blueprint = pool[Math.floor(Math.random() * pool.length)] || TACTICAL_BLUEPRINTS[0];

  // Perspective inversion (50% chance to play as Black or White)
  const shouldFlip = Math.random() < 0.5;
  let candidateFen = shouldFlip ? flipPerspectiveFen(blueprint.fen) : blueprint.fen;
  candidateFen = perturbBoardVariations(candidateFen);

  let chess: Chess;
  try {
    chess = new Chess(candidateFen);
  } catch {
    chess = new Chess(blueprint.fen);
    candidateFen = blueprint.fen;
  }

  // Run deep Negamax multi-PV search to compute and verify the exact tactical line
  const searcher = new Searcher();
  const searchRes = searcher.searchMultiPV(chess, {
    maxDepth: 10,
    multipv: 2,
    timeMs: 400,
  });

  let solutionMoves: string[] = [];
  if (searchRes.lines.length && searchRes.lines[0].pv.length) {
    solutionMoves = searchRes.lines[0].pv.slice(0, 5);
  } else {
    const legal = chess.legalMoves();
    if (legal.length) {
      solutionMoves = [sqName(legal[0].from) + sqName(legal[0].to)];
    }
  }

  const eloOffset = Math.floor(Math.random() * 80 - 40);
  const puzzleRating = Math.max(750, blueprint.baseRating + eloOffset);
  const puzzleId = `dyn-${blueprint.category}-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
  const toMoveColor = chess.turn === 'w' ? 'White' : 'Black';

  return {
    id: puzzleId,
    rating: puzzleRating,
    theme: `${blueprint.theme}${shouldFlip ? ' (Flipped)' : ''}`,
    category: blueprint.category,
    fen: chess.fen(),
    toMove: chess.turn,
    solution: solutionMoves,
    description: `${blueprint.description} ${toMoveColor} to move and win.`,
  };
}
