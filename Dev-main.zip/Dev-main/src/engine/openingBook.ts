import { OpeningVariation, OpeningChapter, OpeningExplanation, OpeningQuizItem, PieceColor, Square } from '../types/chess';
import { nameToSq, Chess } from './chessRules';

/**
 * 100% Theoretically Accurate Grandmaster Opening Database
 * Includes all canonical opening moves, variants, move-by-move explanations,
 * strategic arrows, opponent threats, and counter-measures.
 */
export const OPENINGS_DATABASE: OpeningVariation[] = [
  // ==========================================
  // 1. SICILIAN DEFENSE (B90 / B70 / B22)
  // ==========================================
  {
    name: 'Sicilian Defense',
    eco: 'B90',
    category: "King's Pawn (1.e4)",
    moves: '1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6',
    tokens: ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6'],
    description: "The most popular, sharp, and respected response to 1.e4 in chess history. Played by World Champions Bobby Fischer and Garry Kasparov, the Sicilian allows Black to fight for the win from move one with unmatched dynamic counterplay.",
    keyPlans: [
      'Trade a flank pawn (c5) for White’s central d-pawn to establish central pawn superiority (d6+e7 vs e4).',
      'Use the semi-open c-file for aggressive queenside rook pressure.',
      'Control the b5 square with ...a6 and expand with ...b5, ...Bb7, and ...Nbd7.',
      'White attacks with rapid piece play and kingside pawn storms (f3/g4/h4 in English Attack, or Bg5/Bc4).'
    ],
    chapters: [
      {
        id: 'sicilian-najdorf-main',
        title: 'Variant 1: Najdorf - English Attack (6.Be3)',
        description: 'The modern gold standard of the Najdorf. White prepares a kingside pawn storm (f3, g4, Qd2, O-O-O) while Black counter-attacks on the queenside.',
        color: 'b',
        moves: '1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Be3 e5 7. Nb3 Be6 8. f3 Be7 9. Qd2 O-O 10. O-O-O Nbd7',
        tokens: ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6', 'Be3', 'e5', 'Nb3', 'Be6', 'f3', 'Be7', 'Qd2', 'O-O', 'O-O-O', 'Nbd7'],
        explanations: [
          {
            move: 'e4',
            ply: 1,
            title: "White's Central Claim",
            why: 'White seizes the center, freeing lines for the queen and light-squared bishop.',
            plans: 'Control d5 and f5, develop quickly.',
            arrows: [{ from: nameToSq('e2'), to: nameToSq('e4'), tier: 'best' }],
            keySquare: nameToSq('e4'),
          },
          {
            move: 'c5',
            ply: 2,
            title: 'Asymmetrical Counter-Attack',
            why: 'Black fights for the center from the flank, preventing White from owning both d4 and e4 without concessions.',
            plans: 'Trade the c-pawn for White\'s d-pawn to gain central pawn majority.',
            arrows: [{ from: nameToSq('c7'), to: nameToSq('c5'), tier: 'best' }],
            keySquare: nameToSq('d4'),
          },
          {
            move: 'Nf3',
            ply: 3,
            title: 'Preparing the d4 Break',
            why: 'Develops a knight toward the center and prepares the pawn thrust d2-d4.',
            plans: 'Open the center with d4.',
            arrows: [{ from: nameToSq('g1'), to: nameToSq('f3'), tier: 'best' }],
          },
          {
            move: 'd6',
            ply: 4,
            title: 'Guarding e5 & Freeing the Bishop',
            why: 'Stops White from advancing e4-e5 and opens the c8 bishop diagonal.',
            plans: 'Prepare ...Nf6 without allowing e4-e5 kicks.',
            arrows: [{ from: nameToSq('d7'), to: nameToSq('d6'), tier: 'best' }],
          },
          {
            move: 'd4',
            ply: 5,
            title: 'The Open Sicilian Breakthrough',
            why: 'White blows open the center to accelerate piece development.',
            plans: 'Recapture on d4 with knight to establish active central pieces.',
            arrows: [{ from: nameToSq('d2'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'cxd4',
            ply: 6,
            title: 'The Favorable Flank Trade',
            why: 'Exchanges a wing pawn for a center pawn. Black now possesses two central pawns (d6/e7) vs White\'s one (e4).',
            plans: 'Open the c-file for rooks and queens.',
            arrows: [{ from: nameToSq('c5'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'Nxd4',
            ply: 7,
            title: 'Dominant Central Knight',
            why: 'The knight reaches a powerful central outpost on d4.',
            plans: 'Support kingside or queenside expansion.',
            arrows: [{ from: nameToSq('f3'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'Nf6',
            ply: 8,
            title: 'Attacking e4 with Tempo',
            why: 'Forces White to commit a piece to defend the undefended e4 pawn.',
            plans: 'Force 6.Nc3 before Black plays ...a6.',
            arrows: [{ from: nameToSq('g8'), to: nameToSq('f6'), tier: 'best' }, { from: nameToSq('f6'), to: nameToSq('e4'), tier: 'second' }],
          },
          {
            move: 'Nc3',
            ply: 9,
            title: 'Defending e4 & Developing',
            why: 'Natural developing move defending the e4 pawn.',
            plans: 'Prepare Be3 or Bg5.',
            arrows: [{ from: nameToSq('b1'), to: nameToSq('c3'), tier: 'best' }],
          },
          {
            move: 'a6',
            ply: 10,
            title: 'The Defining Najdorf Move',
            why: 'Denies b5 to all White knights and bishops, while preparing Black\'s own ...b5 expansion.',
            plans: 'Play ...e5, ...Be6, ...Be7, ...Nbd7, ...b5.',
            arrows: [{ from: nameToSq('a7'), to: nameToSq('a6'), tier: 'best' }],
            keySquare: nameToSq('b5'),
          },
          {
            move: 'Be3',
            ply: 11,
            title: 'English Attack Setup',
            why: 'White prepares f3, Qd2, and O-O-O with a vicious g4-h4 pawn assault.',
            plans: 'Castle queenside and launch kingside pawns.',
            arrows: [{ from: nameToSq('c1'), to: nameToSq('e3'), tier: 'best' }],
          },
          {
            move: 'e5',
            ply: 12,
            title: 'Dynamic Central Strike',
            why: 'Black kicks White\'s strong d4 knight and claims space in the center.',
            plans: 'Push the knight to b3 and follow up with ...Be6.',
            arrows: [{ from: nameToSq('e7'), to: nameToSq('e5'), tier: 'best' }],
            keySquare: nameToSq('d5'),
          },
          {
            move: 'Nb3',
            ply: 13,
            title: 'Knight Retracts to Safety',
            why: 'White retreats the knight to b3, guarding the queenside.',
            plans: 'Support Qd2 and f3.',
            arrows: [{ from: nameToSq('d4'), to: nameToSq('b3'), tier: 'best' }],
          },
          {
            move: 'Be6',
            ply: 14,
            title: 'Controlling the Critical d5 Hole',
            why: 'Controls the d5 square and develops the light-squared bishop actively.',
            plans: 'Prepare ...Nbd7, ...Rc8, and ...d5 break.',
            arrows: [{ from: nameToSq('c8'), to: nameToSq('e6'), tier: 'best' }],
            keySquare: nameToSq('d5'),
          },
        ],
      },
      {
        id: 'sicilian-dragon',
        title: 'Variant 2: Dragon Variation - Yugoslav Attack (B78)',
        description: 'The sharpest tactical battlefield in chess. Black fianchettos the dark-squared bishop on g7; White launches the devastating Yugoslav Attack with opposite-side castling.',
        color: 'b',
        moves: '1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 g6 6. Be3 Bg7 7. f3 O-O 8. Qd2 Nc6 9. Bc4 Bd7 10. O-O-O',
        tokens: ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'g6', 'Be3', 'Bg7', 'f3', 'O-O', 'Qd2', 'Nc6', 'Bc4', 'Bd7', 'O-O-O'],
        explanations: [
          {
            move: 'g6',
            ply: 10,
            title: 'The Dragon Fianchetto',
            why: 'Black prepares to place the bishop on the great diagonal h8-a1 where it breathes fire on White’s queenside.',
            plans: 'Fianchetto ...Bg7, castle kingside, and attack on the c-file.',
            arrows: [{ from: nameToSq('g7'), to: nameToSq('g6'), tier: 'best' }],
          },
          {
            move: 'Be3',
            ply: 11,
            title: 'The Yugoslav Anchor',
            why: 'White develops bishop to support Qd2 and prepare Bh6 to trade Black\'s defensive dragon bishop.',
            plans: 'Follow with f3, Qd2, O-O-O, and h4-h5.',
            arrows: [{ from: nameToSq('c1'), to: nameToSq('e3'), tier: 'best' }],
          },
          {
            move: 'Bg7',
            ply: 12,
            title: 'The Dragon Bishop Awakens',
            why: 'The bishop exerts massive long-range diagonal pressure on d4 and the queenside.',
            plans: 'Castle kingside immediately.',
            arrows: [{ from: nameToSq('f8'), to: nameToSq('g7'), tier: 'best' }],
          },
          {
            move: 'f3',
            ply: 13,
            title: 'Solidifying e4 & Preparing g4',
            why: 'Prevents Black from playing ...Ng4 attacking the e3 bishop, while preparing g4-h4.',
            plans: 'Play Qd2, O-O-O, and launch the h-pawn.',
            arrows: [{ from: nameToSq('f2'), to: nameToSq('f3'), tier: 'best' }],
          },
        ],
      },
      {
        id: 'sicilian-alapin',
        title: 'Variant 3: Alapin Variation (2.c3)',
        description: 'White’s primary anti-Sicilian weapon. White prepares an immediate d2-d4 pawn center. Black must counter-strike in the center with 2...d5 or 2...Nf6.',
        color: 'w',
        moves: '1. e4 c5 2. c3 d5 3. exd5 Qxd5 4. d4 Nf6 5. Nf3 e6 6. Be2 Nc6',
        tokens: ['e4', 'c5', 'c3', 'd5', 'exd5', 'Qxd5', 'd4', 'Nf6', 'Nf3', 'e6', 'Be2', 'Nc6'],
        explanations: [
          {
            move: 'c3',
            ply: 3,
            title: 'The Alapin Foundation',
            why: 'White prepares to build a classical pawn center with d2-d4 supported by c3.',
            plans: 'Push d4 on the next move and recapture with the c-pawn if Black takes.',
            arrows: [{ from: nameToSq('c2'), to: nameToSq('c3'), tier: 'best' }],
          },
          {
            move: 'd5',
            ply: 4,
            title: 'Black’s Immediate Counter-Strike',
            why: 'Strikes at e4 before White can solidify d4. Best way to challenge White\'s setup.',
            plans: 'Force exd5 and bring Queen to active d5 post.',
            arrows: [{ from: nameToSq('d7'), to: nameToSq('d5'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'sicilian-q1',
        fen: 'rnbqkb1r/pp2pppp/3p1n2/8/3NP3/2N5/PPP2PPP/R1BQKB1R b KQkq - 2 5',
        question: 'Why does Black play 5...a6 in the Sicilian Najdorf?',
        correctMoveSan: 'a6',
        explanation: '5...a6 prevents all White pieces (knights and bishop) from using the critical b5 outpost, while preparing Black\'s ...b5 expansion.',
        options: ['a6', 'e5', 'g6', 'Nc6'],
      },
      {
        id: 'sicilian-q2',
        fen: 'rnbqkb1r/1p2pppp/p2p1n2/8/3NP3/2N1B3/PPP2PPP/R2QKB1R b KQkq - 1 6',
        question: 'White plays 6.Be3 (English Attack). What is Black’s primary energetic reply?',
        correctMoveSan: 'e5',
        explanation: '6...e5 immediately challenges White’s centralized knight on d4 and fights for central space.',
        options: ['e5', 'b5', 'e6', 'Nbd7'],
      },
    ],
  },

  // ==========================================
  // 2. ITALIAN GAME (C50 / C53 / C57)
  // ==========================================
  {
    name: 'Italian Game',
    eco: 'C50',
    category: "King's Pawn (1.e4)",
    moves: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5',
    tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5'],
    description: "One of the oldest and most classical openings in chess. White develops the bishop to c4 targeting Black’s vulnerable f7 square. Offers rich strategic maneuvering in the Giuoco Piano and sharp fireworks in the Evans Gambit and Fried Liver.",
    keyPlans: [
      'White develops rapidly with Bc4, targeting Black\'s vulnerable f7 pawn.',
      'In Giuoco Piano (c3/d4 or c3/d3), White builds a strong central pawn front.',
      'Black mirrors with ...Bc5 or plays the aggressive Two Knights with ...Nf6.',
      'White can sacrifice a pawn with the Evans Gambit (4.b4) for rapid attacking lines.'
    ],
    chapters: [
      {
        id: 'italian-giuoco-piano',
        title: 'Variant 1: Classical Giuoco Piano (4.c3 & 5.d4)',
        description: 'White plays 4.c3 to build a full pawn center with 5.d4. Black must react actively with 4...Nf6 and 5...exd4 6.cxd4 Bb4+.',
        color: 'w',
        moves: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. cxd4 Bb4+ 7. Bd2 Bxd2+ 8. Nbxd2 d5',
        tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'c3', 'Nf6', 'd4', 'exd4', 'cxd4', 'Bb4+', 'Bd2', 'Bxd2+', 'Nbxd2', 'd5'],
        explanations: [
          {
            move: 'Bc4',
            ply: 5,
            title: 'The Italian Bishop',
            why: 'Targets the f7 square, the weakest point in Black\'s camp since it is defended only by the king.',
            plans: 'Prepare castling and center advances.',
            arrows: [{ from: nameToSq('f1'), to: nameToSq('c4'), tier: 'best' }, { from: nameToSq('c4'), to: nameToSq('f7'), tier: 'second' }],
            keySquare: nameToSq('f7'),
          },
          {
            move: 'Bc5',
            ply: 6,
            title: 'Classical Symmetrical Development',
            why: 'Black develops actively, controlling d4 and preparing kingside castling.',
            plans: 'Answer 4.c3 with 4...Nf6 attacking e4.',
            arrows: [{ from: nameToSq('f8'), to: nameToSq('c5'), tier: 'best' }],
          },
          {
            move: 'c3',
            ply: 7,
            title: 'Building the Broad Center',
            why: 'Prepares the decisive central push d2-d4 to gain full control of the center.',
            plans: 'Play d4 on the next move.',
            arrows: [{ from: nameToSq('c2'), to: nameToSq('c3'), tier: 'best' }],
          },
          {
            move: 'Nf6',
            ply: 8,
            title: 'Counter-Attacking e4',
            why: 'Black attacks the e4 pawn immediately, punishing White if they play passively.',
            plans: 'Take e4 if White does not defend properly, or meet 5.d4 with 5...exd4.',
            arrows: [{ from: nameToSq('g8'), to: nameToSq('f6'), tier: 'best' }, { from: nameToSq('f6'), to: nameToSq('e4'), tier: 'second' }],
          },
          {
            move: 'd4',
            ply: 9,
            title: 'The Central Push',
            why: 'White seizes the center and attacks Black\'s c5 bishop.',
            plans: 'Recapture on d4 with c-pawn to form an imposing duo on d4 and e4.',
            arrows: [{ from: nameToSq('d2'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'exd4',
            ply: 10,
            title: 'Forced Capture',
            why: 'Black relieves central pressure and opens lines.',
            plans: 'Meet 6.cxd4 with 6...Bb4+ checking the White king.',
            arrows: [{ from: nameToSq('e5'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'cxd4',
            ply: 11,
            title: 'Dominant Pawn Duo',
            why: 'White establishes pawns on d4 and e4.',
            plans: 'Support the center and advance d5 if permitted.',
            arrows: [{ from: nameToSq('c3'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'Bb4+',
            ply: 12,
            title: 'Crucial Intermezzo Check',
            why: 'Checks the king and gains tempo to prevent White from rolling forward with d5 unpunished.',
            plans: 'Force White to block with Bd2 or Nc3.',
            arrows: [{ from: nameToSq('c5'), to: nameToSq('b4'), tier: 'best' }],
          },
        ],
      },
      {
        id: 'italian-evans-gambit',
        title: 'Variant 2: Evans Gambit (4.b4!)',
        description: 'One of the most thrilling romantic gambits in chess history. White sacrifices a wing pawn (b4) to gain rapid piece development and central dominance.',
        color: 'w',
        moves: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4 Bxb4 5. c3 Ba5 6. d4 exd4 7. O-O',
        tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'b4', 'Bxb4', 'c3', 'Ba5', 'd4', 'exd4', 'O-O'],
        explanations: [
          {
            move: 'b4',
            ply: 7,
            title: 'The Evans Gambit Pawn Sacrifice',
            why: 'White sacrifices the b4 pawn to deflect Black\'s bishop, gain time with c3, and roll the center with d4.',
            plans: 'Follow with 5.c3, 6.d4, and fast kingside castling.',
            arrows: [{ from: nameToSq('b2'), to: nameToSq('b4'), tier: 'best' }],
            keySquare: nameToSq('b4'),
          },
          {
            move: 'Bxb4',
            ply: 8,
            title: 'Gambit Accepted',
            why: 'Black accepts the challenge and grabs the material.',
            plans: 'Retreat the bishop to a5 or e7 after 5.c3.',
            arrows: [{ from: nameToSq('c5'), to: nameToSq('b4'), tier: 'best' }],
          },
          {
            move: 'c3',
            ply: 9,
            title: 'Gaining Tempo on the Bishop',
            why: 'Attacks the bishop and sets up 6.d4.',
            plans: 'Push d4 immediately on the next move.',
            arrows: [{ from: nameToSq('c2'), to: nameToSq('c3'), tier: 'best' }],
          },
          {
            move: 'Ba5',
            ply: 10,
            title: 'The Main Retreat',
            why: 'Maintains pressure on the c3 pawn and pins it against the king.',
            plans: 'Prepare ...Nf6 and ...d6.',
            arrows: [{ from: nameToSq('b4'), to: nameToSq('a5'), tier: 'best' }],
          },
        ],
      },
      {
        id: 'italian-fried-liver',
        title: 'Variant 3: Two Knights & Fried Liver Attack (4.Ng5)',
        description: 'When Black plays 3...Nf6, White can strike at f7 with 4.Ng5. Modern theory requires Black to sacrifice a pawn with 4...d5 5.exd5 Na5! for superior piece activity.',
        color: 'w',
        moves: '1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Na5 6. Bb5+ c6 7. dxc6 bxc6 8. Be2 h6 9. Nf3 e4',
        tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5', 'd5', 'exd5', 'Na5', 'Bb5+', 'c6', 'dxc6', 'bxc6', 'Be2', 'h6', 'Nf3', 'e4'],
        explanations: [
          {
            move: 'Ng5',
            ply: 7,
            title: 'Aggressive Strike on f7',
            why: 'Coordinates with Bc4 to create an overwhelming double-threat against the weak f7 square.',
            plans: 'Force Black into defensive concessions or win material on f7.',
            arrows: [{ from: nameToSq('f3'), to: nameToSq('g5'), tier: 'best' }, { from: nameToSq('g5'), to: nameToSq('f7'), tier: 'best' }, { from: nameToSq('c4'), to: nameToSq('f7'), tier: 'second' }],
            keySquare: nameToSq('f7'),
          },
          {
            move: 'd5',
            ply: 8,
            title: 'The Only Theoretical Defense',
            why: 'Blocks the c4 bishop\'s diagonal to protect f7.',
            plans: 'Follow with 5...Na5 after White takes on d5.',
            arrows: [{ from: nameToSq('d7'), to: nameToSq('d5'), tier: 'best' }],
          },
          {
            move: 'Na5',
            ply: 10,
            title: 'Modern Grandmaster Refutation',
            why: 'Attacks White\'s bishop on c4. Black gives up a pawn for relentless initiative and piece coordination.',
            plans: 'Drive away White\'s pieces with ...h6 and ...e4.',
            arrows: [{ from: nameToSq('c6'), to: nameToSq('a5'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'italian-q1',
        fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p1N1/2B1P3/8/PPPP1PPP/RNBQK2R b KQkq - 5 4',
        question: 'White plays 4.Ng5 threatening Nxf7. What is Black’s only correct move?',
        correctMoveSan: 'd5',
        explanation: '4...d5 is mandatory! It shuts down the c4 bishop’s attack on f7.',
        options: ['d5', 'Bc5', 'Qe7', 'h6'],
      },
      {
        id: 'italian-q2',
        fen: 'r1bqk2r/pppp1ppp/2n5/4P1N1/2B3n1/8/PPP2bPP/RNBQK2R w KQkq - 0 7',
        question: 'What is the key target square in the Italian Game that White targets with Bc4 and Ng5?',
        correctMoveSan: 'f7',
        explanation: 'The f7 square is defended only by Black’s king at the start, making it the primary focal point of early tactical assaults.',
        options: ['f7', 'e5', 'd5', 'c7'],
      },
    ],
  },

  // ==========================================
  // 3. RUY LOPEZ / SPANISH OPENING (C65 / C70 / C88)
  // ==========================================
  {
    name: 'Ruy Lopez (Spanish Opening)',
    eco: 'C65',
    category: "King's Pawn (1.e4)",
    moves: '1. e4 e5 2. Nf3 Nc6 3. Bb5 a6',
    tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6'],
    description: "The cornerstone of classical chess strategy. Developed in the 16th century by Spanish priest Ruy López de Segura, this opening puts indirect pressure on Black’s e5 pawn by attacking its Nc6 defender. It leads to deep strategic plans and rich endgames.",
    keyPlans: [
      'White pins or attacks the Nc6 defender of the e5 pawn with 3.Bb5.',
      'Black chooses between 3...a6 (Morphy Defense), 3...Nf6 (Berlin Defense), or 3...f5 (Schliemann).',
      'In Closed lines, White maneuvers with c3, d4, Re1, Nbd2-f1-g3.',
      'Black gains space on the queenside with ...b5 and counter-attacks in the center with ...d5 or ...c5.'
    ],
    chapters: [
      {
        id: 'ruy-berlin',
        title: 'Variant 1: Berlin Defense (3...Nf6 & The Berlin Wall)',
        description: 'Made famous by Vladimir Kramnik against Garry Kasparov in 2000. Black creates an impregnable endgame fortress that has withstood all modern grandmaster efforts.',
        color: 'b',
        moves: '1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. O-O Nxe4 5. d4 Nd6 6. Bxc6 dxc6 7. dxe5 Nf5 8. Qxd8+ Kxd8',
        tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'Nf6', 'O-O', 'Nxe4', 'd4', 'Nd6', 'Bxc6', 'dxc6', 'dxe5', 'Nf5', 'Qxd8+', 'Kxd8'],
        explanations: [
          {
            move: 'Bb5',
            ply: 5,
            title: 'The Spanish Pin',
            why: 'Pressures the c6 knight which guards the e5 pawn.',
            plans: 'Prepare castling and d4.',
            arrows: [{ from: nameToSq('f1'), to: nameToSq('b5'), tier: 'best' }, { from: nameToSq('b5'), to: nameToSq('c6'), tier: 'second' }],
            keySquare: nameToSq('c6'),
          },
          {
            move: 'Nf6',
            ply: 6,
            title: 'The Berlin Counter-Strike',
            why: 'Black develops the knight and attacks the e4 pawn rather than playing 3...a6.',
            plans: 'Grab e4 if White castles.',
            arrows: [{ from: nameToSq('g8'), to: nameToSq('f6'), tier: 'best' }, { from: nameToSq('f6'), to: nameToSq('e4'), tier: 'second' }],
          },
          {
            move: 'O-O',
            ply: 7,
            title: 'White Castles Safely',
            why: 'White secures the king and invites Black to take the poisoned e4 pawn.',
            plans: 'Open the e-file with Re1 or d4.',
            arrows: [{ from: nameToSq('e1'), to: nameToSq('g1'), tier: 'best' }],
          },
          {
            move: 'Nxe4',
            ply: 8,
            title: 'Accepting the Center Pawn',
            why: 'Black grabs the e4 pawn to initiate the Berlin endgame structure.',
            plans: 'Retreat the knight to d6 when attacked.',
            arrows: [{ from: nameToSq('f6'), to: nameToSq('e4'), tier: 'best' }],
          },
          {
            move: 'd4',
            ply: 9,
            title: 'Central Break',
            why: 'White opens lines immediately against Black\'s uncastled king.',
            plans: 'Recapture and pin down the e-file.',
            arrows: [{ from: nameToSq('d2'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'Nd6',
            ply: 10,
            title: 'Attacking the Spanish Bishop',
            why: 'The knight retreats while hitting White\'s b5 bishop.',
            plans: 'Take the bishop pair advantage after Bxc6.',
            arrows: [{ from: nameToSq('e4'), to: nameToSq('d6'), tier: 'best' }, { from: nameToSq('d6'), to: nameToSq('b5'), tier: 'second' }],
          },
        ],
      },
      {
        id: 'ruy-closed-morphy',
        title: 'Variant 2: Closed Morphy Main Line (3...a6 & 4...Nf6)',
        description: 'The classical foundation of the Ruy Lopez. Black kicks the bishop with 3...a6, develops with ...Be7, castles, and expands with ...b5 and ...d6.',
        color: 'w',
        moves: '1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3',
        tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'O-O', 'Be7', 'Re1', 'b5', 'Bb3', 'd6', 'c3', 'O-O', 'h3'],
        explanations: [
          {
            move: 'a6',
            ply: 6,
            title: 'Morphy’s Defense',
            why: 'Asks the bishop what it wants to do and prepares queenside space expansion.',
            plans: 'Follow with ...b5 when necessary.',
            arrows: [{ from: nameToSq('a7'), to: nameToSq('a6'), tier: 'best' }],
          },
          {
            move: 'Ba4',
            ply: 7,
            title: 'Retaining the Tension',
            why: 'White keeps the bishop on the diagonal rather than trading on c6.',
            plans: 'Retreat to b3 if kicked with ...b5.',
            arrows: [{ from: nameToSq('b5'), to: nameToSq('a4'), tier: 'best' }],
          },
          {
            move: 'h3',
            ply: 17,
            title: 'Prophylactic Masterstroke',
            why: 'Prevents Black from pinning the f3 knight with ...Bg4 before White plays d2-d4.',
            plans: 'Prepare d4 and Nbd2-f1-g3.',
            arrows: [{ from: nameToSq('h2'), to: nameToSq('h3'), tier: 'best' }],
            keySquare: nameToSq('g4'),
          },
        ],
      },
      {
        id: 'ruy-marshall',
        title: 'Variant 3: Marshall Attack (8...d5!)',
        description: 'Invented by Frank Marshall against Capablanca. Black sacrifices a central pawn on move 8 with 8...d5! to unleash a blistering kingside attack.',
        color: 'b',
        moves: '1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 O-O 8. c3 d5 9. exd5 Nxd5 10. Nxe5 Nxe5 11. Rxe5 c6',
        tokens: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'O-O', 'Be7', 'Re1', 'b5', 'Bb3', 'O-O', 'c3', 'd5', 'exd5', 'Nxd5', 'Nxe5', 'Nxe5', 'Rxe5', 'c6'],
        explanations: [
          {
            move: 'd5',
            ply: 16,
            title: 'The Legendary Marshall Gambit',
            why: 'Black sacrifices the e5 pawn to blow open the center and launch all minor pieces at White\'s king.',
            plans: 'Follow with ...c6, ...Bd6, ...Qh4, and ...Bg4.',
            arrows: [{ from: nameToSq('d7'), to: nameToSq('d5'), tier: 'best' }],
            keySquare: nameToSq('d5'),
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'ruy-q1',
        fen: 'r1bqk2r/1ppp1ppp/p1n2n2/4p3/B3P3/5N2/PPPP1PPP/RNBQ1RK1 b kq - 3 5',
        question: 'Why does White play 9.h3 in the Closed Ruy Lopez before pushing d4?',
        correctMoveSan: 'h3',
        explanation: '9.h3 is vital prophylaxis! It prevents Black from pinning the f3 knight with ...Bg4.',
        options: ['h3', 'd4', 'Re1', 'Nc3'],
      },
    ],
  },

  // ==========================================
  // 4. QUEEN'S GAMBIT (D10 / D30 / D37)
  // ==========================================
  {
    name: "Queen's Gambit",
    eco: 'D30',
    category: "Queen's Pawn (1.d4)",
    moves: '1. d4 d5 2. c4 e6 3. Nc3 Nf6',
    tokens: ['d4', 'd5', 'c4', 'e6', 'Nc3', 'Nf6'],
    description: "The most prestigious and foundational opening of 1.d4. White offers a wing pawn (c4) to trade for Black’s central d5 pawn, aiming for complete center dominance. Black can Decline (2...e6), Accept (2...dxc4), or play the Slav (2...c6).",
    keyPlans: [
      'White offers the c4 pawn to exchange Black’s center pawn and open the c-file.',
      'In QGD (2...e6), Black maintains a firm central stake on d5.',
      'In Slav Defense (2...c6), Black supports d5 without blocking the c8 light-squared bishop.',
      'White pressures d5 with Nc3, Bg5, cxd5, and minority attack on the queenside (b4-b5).'
    ],
    chapters: [
      {
        id: 'qgd-classical',
        title: 'Variant 1: Queen\'s Gambit Declined - Classical (3...Nf6 & 4.Bg5)',
        description: 'The timeless battleground of World Championship matches. White pins the f6 knight with Bg5; Black castles, plays ...Nbd7, and breaks with ...c5 or ...e5.',
        color: 'w',
        moves: '1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Nf3 Be7 5. Bg5 O-O 6. e3 Nbd7 7. Rc1 c6 8. Bd3 dxc4 9. Bxc4 Nd5',
        tokens: ['d4', 'd5', 'c4', 'e6', 'Nc3', 'Nf6', 'Nf3', 'Be7', 'Bg5', 'O-O', 'e3', 'Nbd7', 'Rc1', 'c6', 'Bd3', 'dxc4', 'Bxc4', 'Nd5'],
        explanations: [
          {
            move: 'd4',
            ply: 1,
            title: "Queen's Pawn Opening",
            why: 'White establishes a strong pawn in the center, protected by the queen.',
            plans: 'Play c4 to challenge Black\'s d5 pawn.',
            arrows: [{ from: nameToSq('d2'), to: nameToSq('d4'), tier: 'best' }],
          },
          {
            move: 'c4',
            ply: 3,
            title: "The Queen's Gambit Offer",
            why: 'Challenges Black\'s center pawn from the flank. Not a true gambit since White can easily win the pawn back.',
            plans: 'Gain a superior center after cxd5 or e3/Bxc4.',
            arrows: [{ from: nameToSq('c2'), to: nameToSq('c4'), tier: 'best' }],
            keySquare: nameToSq('d5'),
          },
          {
            move: 'e6',
            ply: 4,
            title: "Declining the Gambit",
            why: 'Black solidly reinforces the d5 outpost.',
            plans: 'Develop ...Nf6 and ...Be7.',
            arrows: [{ from: nameToSq('e7'), to: nameToSq('e6'), tier: 'best' }],
          },
          {
            move: 'Bg5',
            ply: 9,
            title: 'Pinning the Knight',
            why: 'Pins the f6 knight against the queen, undermining Black\'s control of d5 and e4.',
            plans: 'Play e3, Bd3, and Rc1.',
            arrows: [{ from: nameToSq('c1'), to: nameToSq('g5'), tier: 'best' }],
          },
        ],
      },
      {
        id: 'qg-slav',
        title: 'Variant 2: Slav Defense (2...c6)',
        description: 'One of Black’s most resilient weapons against 1.d4. By supporting d5 with 2...c6, Black avoids locking in the c8 bishop and prepares ...Bf5 or ...Bg4.',
        color: 'b',
        moves: '1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 dxc4 5. a4 Bf5 6. e3 e6 7. Bxc4 Bb4 8. O-O O-O',
        tokens: ['d4', 'd5', 'c4', 'c6', 'Nf3', 'Nf6', 'Nc3', 'dxc4', 'a4', 'Bf5', 'e3', 'e6', 'Bxc4', 'Bb4', 'O-O', 'O-O'],
        explanations: [
          {
            move: 'c6',
            ply: 4,
            title: 'The Slav Defense',
            why: 'Defends d5 with a pawn without trapping the c8 bishop.',
            plans: 'Develop ...Bf5 after taking on c4 or supporting the center.',
            arrows: [{ from: nameToSq('c7'), to: nameToSq('c6'), tier: 'best' }],
          },
          {
            move: 'Bf5',
            ply: 10,
            title: 'Activating the Light-Squared Bishop',
            why: 'Develops the bishop outside the pawn chain before playing ...e6.',
            plans: 'Solidify with ...e6 and ...Bb4.',
            arrows: [{ from: nameToSq('c8'), to: nameToSq('f5'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'qgd-q1',
        fen: 'rnbqkb1r/ppp2ppp/4pn2/3p2B1/2PP4/2N5/PP2PPPP/R2QKBNR b KQkq - 1 4',
        question: 'Why is the Queen\'s Gambit (1.d4 d5 2.c4) not considered a true sacrificial gambit?',
        correctMoveSan: 'c4',
        explanation: 'Because if Black accepts with 2...dxc4, White can easily recover the pawn with 3.e3 or 3.Qa4+ while gaining massive center control.',
        options: ['c4', 'e3', 'Nf3', 'Bf4'],
      },
    ],
  },

  // ==========================================
  // 5. FRENCH DEFENSE (C02 / C11 / C15)
  // ==========================================
  {
    name: 'French Defense',
    eco: 'C02',
    category: "King's Pawn (1.e4)",
    moves: '1. e4 e6 2. d4 d5',
    tokens: ['e4', 'e6', 'd4', 'd5'],
    description: "A counter-attacking opening where Black concedes space to establish an unshakeable central pawn chain on d5 and e6. Black systematically undermines White's center with ...c5 and ...f6.",
    keyPlans: [
      'Advance pawn to d5 supported by e6.',
      'In Advance Variation (3.e5), Black strikes at the base of White\'s chain with ...c5, ...Nc6, ...Qb6.',
      'In Winawer (3.Nc3 Bb4), Black creates dynamic imbalances and pins White\'s knight.',
      'Solve the "French Bishop problem" (c8 bishop) via ...Bd7-e8-h5 or queenside fianchetto ...b6/Bb7.'
    ],
    chapters: [
      {
        id: 'french-advance',
        title: 'Variant 1: Advance Variation (3.e5 & 3...c5)',
        description: 'White closes the center with 3.e5. Black immediately targets White’s d4 pawn base with 3...c5, 4...Nc6, 5...Qb6, and 6...Nh6-f5.',
        color: 'b',
        moves: '1. e4 e6 2. d4 d5 3. e5 c5 4. c3 Nc6 5. Nf3 Qb6 6. a3 Nh6 7. b4 cxd4 8. cxd4 Nf5',
        tokens: ['e4', 'e6', 'd4', 'd5', 'e5', 'c5', 'c3', 'Nc6', 'Nf3', 'Qb6', 'a3', 'Nh6', 'b4', 'cxd4', 'cxd4', 'Nf5'],
        explanations: [
          {
            move: 'e5',
            ply: 5,
            title: 'Closing the Center',
            why: 'White locks the center, claiming space on the kingside and cramping Black.',
            plans: 'Defend d4 with c3 and attack on the kingside.',
            arrows: [{ from: nameToSq('e4'), to: nameToSq('e5'), tier: 'best' }],
            keySquare: nameToSq('e5'),
          },
          {
            move: 'c5',
            ply: 6,
            title: 'Attacking the Base of the Pawn Chain',
            why: 'Strikes immediately at the d4 pawn supporting White\'s entire structure.',
            plans: 'Pressure d4 with ...Nc6, ...Qb6, and ...Nge7-f5.',
            arrows: [{ from: nameToSq('c7'), to: nameToSq('c5'), tier: 'best' }, { from: nameToSq('c5'), to: nameToSq('d4'), tier: 'second' }],
            keySquare: nameToSq('d4'),
          },
          {
            move: 'Qb6',
            ply: 10,
            title: 'Tripling Pressure on d4',
            why: 'Puts maximum firepower on d4 while eyeing the b2 pawn.',
            plans: 'Bring knight to f5 via h6 or e7.',
            arrows: [{ from: nameToSq('d8'), to: nameToSq('b6'), tier: 'best' }, { from: nameToSq('b6'), to: nameToSq('d4'), tier: 'best' }],
          },
        ],
      },
      {
        id: 'french-winawer',
        title: 'Variant 2: Winawer Variation (3.Nc3 Bb4)',
        description: 'The sharpest tactical branch of the French. Black pins White’s knight on c3, willing to trade the dark-squared bishop to double White’s c-pawns.',
        color: 'b',
        moves: '1. e4 e6 2. d4 d5 3. Nc3 Bb4 4. e5 c5 5. a3 Bxc3+ 6. bxc3 Ne7 7. Qg4',
        tokens: ['e4', 'e6', 'd4', 'd5', 'Nc3', 'Bb4', 'e5', 'c5', 'a3', 'Bxc3+', 'bxc3', 'Ne7', 'Qg4'],
        explanations: [
          {
            move: 'Bb4',
            ply: 6,
            title: 'The Winawer Pin',
            why: 'Pins the c3 knight to White\'s king, threatening to capture and inflict doubled c-pawns.',
            plans: 'Trade on c3 and target White\'s weak queenside pawns.',
            arrows: [{ from: nameToSq('f8'), to: nameToSq('b4'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'french-q1',
        fen: 'rnbqkbnr/pppp1ppp/4p3/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2',
        question: 'What is the primary strategic weakness Black must resolve in the French Defense?',
        correctMoveSan: 'd4',
        explanation: 'Black\'s light-squared bishop on c8 is locked behind the e6 and d5 pawns, requiring careful maneuvers (...Bd7-e8-h5 or ...b6) to activate.',
        options: ['d4', 'c4', 'Nf3', 'f4'],
      },
    ],
  },

  // ==========================================
  // 6. CARO-KANN DEFENSE (B12 / B18)
  // ==========================================
  {
    name: 'Caro-Kann Defense',
    eco: 'B12',
    category: "King's Pawn (1.e4)",
    moves: '1. e4 c6 2. d4 d5',
    tokens: ['e4', 'c6', 'd4', 'd5'],
    description: "Renowned as one of the most solid, dependable, and resilient responses to 1.e4. Unlike the French Defense, Black's light-squared bishop remains free to develop to f5 or g4 outside the pawn chain.",
    keyPlans: [
      'Support d5 with c6 to maintain solid central control.',
      'Develop light-squared bishop to f5 or g4 before locking pawns with ...e6.',
      'In Advance Variation (3.e5 Bf5), Black establishes a rock-solid pawn structure.',
      'In Classical (3.Nc3 dxe4 4.Nxe4 Bf5), Black trades pieces and plays for superior endgame pawn structures.'
    ],
    chapters: [
      {
        id: 'caro-advance',
        title: 'Variant 1: Advance Variation (3.e5 & 3...Bf5)',
        description: 'White closes the center with 3.e5. Black successfully brings the bishop out to f5 before playing ...e6, avoiding the bad bishop problem.',
        color: 'b',
        moves: '1. e4 c6 2. d4 d5 3. e5 Bf5 4. Nf3 e6 5. Be2 c5 6. Be3 Qb6 7. Nc3 Nc6',
        tokens: ['e4', 'c6', 'd4', 'd5', 'e5', 'Bf5', 'Nf3', 'e6', 'Be2', 'c5', 'Be3', 'Qb6', 'Nc3', 'Nc6'],
        explanations: [
          {
            move: 'Bf5',
            ply: 6,
            title: 'Bishop Liberated Outside Chain',
            why: 'Black gets the light-squared bishop outside the pawn chain before locking the door with ...e6.',
            plans: 'Play ...e6, ...c5, and ...Nc6.',
            arrows: [{ from: nameToSq('c8'), to: nameToSq('f5'), tier: 'best' }],
            keySquare: nameToSq('f5'),
          },
          {
            move: 'c5',
            ply: 10,
            title: 'Counter-Striking the Center',
            why: 'Strikes at White\'s d4 base now that the bishop is actively placed.',
            plans: 'Apply pressure with ...Nc6 and ...Qb6.',
            arrows: [{ from: nameToSq('c6'), to: nameToSq('c5'), tier: 'best' }],
          },
        ],
      },
      {
        id: 'caro-classical',
        title: 'Variant 2: Classical Capablanca (3.Nc3 dxe4 4.Nxe4 Bf5)',
        description: 'The historical main line favored by World Champion José Raúl Capablanca. Black exchanges on e4, develops ...Bf5, and forces piece simplifications.',
        color: 'b',
        moves: '1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. h4 h6 7. Nf3 Nd7 8. h5 Bh7 9. Bd3 Bxd3 10. Qxd3',
        tokens: ['e4', 'c6', 'd4', 'd5', 'Nc3', 'dxe4', 'Nxe4', 'Bf5', 'Ng3', 'Bg6', 'h4', 'h6', 'Nf3', 'Nd7', 'h5', 'Bh7', 'Bd3', 'Bxd3', 'Qxd3'],
        explanations: [
          {
            move: 'Bf5',
            ply: 8,
            title: 'Capablanca’s Key Developing Move',
            why: 'Develops with tempo by challenging White\'s central knight on e4.',
            plans: 'Retreat to g6 when attacked, and secure an escape square with ...h6.',
            arrows: [{ from: nameToSq('c8'), to: nameToSq('f5'), tier: 'best' }, { from: nameToSq('f5'), to: nameToSq('e4'), tier: 'second' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'caro-q1',
        fen: 'rnbqkbnr/pp1ppppp/2p5/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2',
        question: 'What is the main advantage of the Caro-Kann over the French Defense?',
        correctMoveSan: 'd4',
        explanation: 'In the Caro-Kann, Black can develop the light-squared bishop to f5 or g4 before playing ...e6, avoiding a passive "bad bishop".',
        options: ['d4', 'c4', 'Nf3', 'Nc3'],
      },
    ],
  },

  // ==========================================
  // 7. KING'S INDIAN DEFENSE (E60 / E90 / E97)
  // ==========================================
  {
    name: "King's Indian Defense",
    eco: 'E60',
    category: "Queen's Pawn (1.d4)",
    moves: '1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6',
    tokens: ['d4', 'Nf6', 'c4', 'g6', 'Nc3', 'Bg7', 'e4', 'd6'],
    description: "The ultimate hypermodern weapon for aggressive players. Favored by Garry Kasparov and Bobby Fischer, Black allows White a huge pawn center, then strikes back with ...e5 and a ferocious kingside attack with ...f5-f4 and ...g5.",
    keyPlans: [
      'Fianchetto dark-squared bishop on g7 and castle quickly.',
      'Strike in the center with ...e5 (or ...c5).',
      'In Classical Mar del Plata (d5 Ne7), Black launches kingside pawns (...f5, ...f4, ...g5, ...Ng6, ...g4).',
      'White counter-attacks on the queenside with c5 and b4.'
    ],
    chapters: [
      {
        id: 'kid-classical',
        title: 'Variant 1: Classical Mar del Plata (9.Ne1 Nd7 & 10...f5)',
        description: 'The immortal romantic line of the King\'s Indian. White closes the center with d5; Black launches a full-scale kingside pawn storm aiming for checkmate.',
        color: 'b',
        moves: '1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Be2 e5 7. O-O Nc6 8. d5 Ne7 9. Ne1 Nd7 10. Be3 f5 11. f3 f4 12. Bf2 g5',
        tokens: ['d4', 'Nf6', 'c4', 'g6', 'Nc3', 'Bg7', 'e4', 'd6', 'Nf3', 'O-O', 'Be2', 'e5', 'O-O', 'Nc6', 'd5', 'Ne7', 'Ne1', 'Nd7', 'Be3', 'f5', 'f3', 'f4', 'Bf2', 'g5'],
        explanations: [
          {
            move: 'e5',
            ply: 12,
            title: 'Central Counter-Strike',
            why: 'Black directly challenges White\'s center, forcing White to commit with d5 or take on e5.',
            plans: 'Force 8.d5 and route knight to e7.',
            arrows: [{ from: nameToSq('e7'), to: nameToSq('e5'), tier: 'best' }],
            keySquare: nameToSq('d4'),
          },
          {
            move: 'd5',
            ply: 15,
            title: 'Closing the Center',
            why: 'Locks the center. With the center closed, the game becomes a race: Black attacks White\'s king, White attacks Black\'s queenside.',
            plans: 'Push c5 and expand on the queenside with b4.',
            arrows: [{ from: nameToSq('d4'), to: nameToSq('d5'), tier: 'best' }],
          },
          {
            move: 'f5',
            ply: 20,
            title: 'The Kingside Assault Begins',
            why: 'Black breaks open the f-file and prepares to push ...f4 and ...g5.',
            plans: 'Push ...f4, followed by ...g5, ...Ng6, and ...h5.',
            arrows: [{ from: nameToSq('f7'), to: nameToSq('f5'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'kid-q1',
        fen: 'rnbqkb1r/pppppp1p/5np1/8/2PP4/8/PP2PPPP/RNBQKBNR w KQkq - 0 2',
        question: 'What is Black\'s main plan in the Classical King\'s Indian after White closes the center with d4-d5?',
        correctMoveSan: 'Nc3',
        explanation: 'Black launches a direct kingside pawn storm with ...f5-f4 and ...g5 targeting White\'s king for checkmate.',
        options: ['Nc3', 'e4', 'Nf3', 'g3'],
      },
    ],
  },

  // ==========================================
  // 8. LONDON SYSTEM (D02)
  // ==========================================
  {
    name: 'London System',
    eco: 'D02',
    category: "Queen's Pawn (1.d4)",
    moves: '1. d4 d5 2. Nf3 Nf6 3. Bf4 c5 4. e3 Nc6 5. c3',
    tokens: ['d4', 'd5', 'Nf3', 'Nf6', 'Bf4', 'c5', 'e3', 'Nc6', 'c3'],
    description: "A solid, universal opening system for White. White develops the dark-squared bishop to f4 before playing e3, building an unshakeable pyramid pawn center on c3, d4, and e3.",
    keyPlans: [
      'Develop dark-squared bishop to f4 outside the pawn chain before playing e3.',
      'Build the "London Pyramid" with pawns on c3, d4, e3.',
      'Post knight on the commanding e5 outpost supported by f4.',
      'Maneuver Nd2, Bd3, and launch a kingside attack or maintain solid positional control.'
    ],
    chapters: [
      {
        id: 'london-classical',
        title: 'Variant 1: Modern Classical Setup (3.Bf4 & c3/e3 Pyramid)',
        description: 'White sets up the harmonious classical setup with Bf4, e3, c3, Nbd2, and Ne5.',
        color: 'w',
        moves: '1. d4 d5 2. Nf3 Nf6 3. Bf4 c5 4. e3 Nc6 5. c3 e6 6. Nbd2 Bd6 7. Bg3 O-O 8. Bd3',
        tokens: ['d4', 'd5', 'Nf3', 'Nf6', 'Bf4', 'c5', 'e3', 'Nc6', 'c3', 'e6', 'Nbd2', 'Bd6', 'Bg3', 'O-O', 'Bd3'],
        explanations: [
          {
            move: 'Bf4',
            ply: 5,
            title: 'The London Bishop',
            why: 'The defining move. White activates the bishop outside the pawn chain before locking the door with e3.',
            plans: 'Follow with e3, c3, Nbd2, and Bd3.',
            arrows: [{ from: nameToSq('c1'), to: nameToSq('f4'), tier: 'best' }],
            keySquare: nameToSq('f4'),
          },
          {
            move: 'e3',
            ply: 7,
            title: 'Solidifying the Center',
            why: 'Locks the center and frees the f1 bishop.',
            plans: 'Support d4 and prepare Bd3.',
            arrows: [{ from: nameToSq('e2'), to: nameToSq('e3'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'london-q1',
        fen: 'rnbqkb1r/ppp1pppp/5n2/3p4/3P1B2/5N2/PPP1PPPP/RN1QKB1R b KQkq - 3 3',
        question: 'Why does White play 3.Bf4 in the London System before playing e3?',
        correctMoveSan: 'Bf4',
        explanation: 'Developing the bishop to f4 first ensures it is not trapped behind the e3 pawn chain.',
        options: ['Bf4', 'e3', 'c4', 'Nc3'],
      },
    ],
  },

  // ==========================================
  // 9. ENGLISH OPENING (A20 / A28)
  // ==========================================
  {
    name: 'English Opening',
    eco: 'A20',
    category: 'Flank Openings',
    moves: '1. c4 e5 2. Nc3 Nf6 3. Nf3 Nc6 4. g3',
    tokens: ['c4', 'e5', 'Nc3', 'Nf6', 'Nf3', 'Nc6', 'g3'],
    description: "A flexible, hypermodern flank opening. White stakes a claim in the center from the wing (c4), controlling the d5 square. Often transposes into Reversed Sicilian or Catalan-style structures.",
    keyPlans: [
      'Control the central d5 square with the c4 pawn and Nc3.',
      'Fianchetto the light-squared bishop on g2 for long-diagonal pressure on d5 and b7.',
      'In Four Knights (1...e5), White fights for central space while Black strikes with ...d5.',
      'Can transpose smoothly into 1.d4 setups or maintain distinct flank strategy.'
    ],
    chapters: [
      {
        id: 'english-four-knights',
        title: 'Variant 1: Four Knights Reversed Sicilian (4.g3 & 4...d5)',
        description: 'The main theoretical battleground of the English Opening.',
        color: 'w',
        moves: '1. c4 e5 2. Nc3 Nf6 3. Nf3 Nc6 4. g3 d5 5. cxd5 Nxd5 6. Bg2 Nb6 7. O-O Be7',
        tokens: ['c4', 'e5', 'Nc3', 'Nf6', 'Nf3', 'Nc6', 'g3', 'd5', 'cxd5', 'Nxd5', 'Bg2', 'Nb6', 'O-O', 'Be7'],
        explanations: [
          {
            move: 'c4',
            ply: 1,
            title: 'The Flank Stake',
            why: 'Controls d5 from the flank while keeping center pawns flexible.',
            plans: 'Follow with Nc3 and g3/Bg2.',
            arrows: [{ from: nameToSq('c2'), to: nameToSq('c4'), tier: 'best' }],
            keySquare: nameToSq('d5'),
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'english-q1',
        fen: 'rnbqkbnr/pppppppp/8/8/2P5/8/PP1PPPPP/RNBQKBNR b KQkq - 0 1',
        question: 'What central square does White primarily control with the 1.c4 English Opening move?',
        correctMoveSan: 'd5',
        explanation: '1.c4 immediately fights for control of the critical d5 square without committing the d-pawn.',
        options: ['d5', 'e4', 'f5', 'b4'],
      },
    ],
  },

  // ==========================================
  // 10. SCANDINAVIAN DEFENSE (B01)
  // ==========================================
  {
    name: 'Scandinavian Defense',
    eco: 'B01',
    category: "King's Pawn (1.e4)",
    moves: '1. e4 d5 2. exd5 Qxd5 3. Nc3 Qa5 4. d4 Nf6',
    tokens: ['e4', 'd5', 'exd5', 'Qxd5', 'Nc3', 'Qa5', 'd4', 'Nf6'],
    description: "Direct and straightforward. Black immediately challenges White’s e4 pawn on move one. Leads to open positions where Black can achieve clean piece development with ...c6, ...Bf5, and queenside castling.",
    keyPlans: [
      'Challenge e4 immediately on move one with 1...d5.',
      'Recapture with Queen (2...Qxd5) and retreat to a5, d6, or d8.',
      'Solidify with ...c6, develop ...Bf5 or ...Bg4, and castle queenside.'
    ],
    chapters: [
      {
        id: 'scandi-main',
        title: 'Variant 1: Classical 3...Qa5 Main Line',
        description: 'The historical main line where Black pins White\'s c3 knight with 3...Qa5.',
        color: 'b',
        moves: '1. e4 d5 2. exd5 Qxd5 3. Nc3 Qa5 4. d4 Nf6 5. Nf3 c6 6. Bc4 Bf5 7. Bd2 e6',
        tokens: ['e4', 'd5', 'exd5', 'Qxd5', 'Nc3', 'Qa5', 'd4', 'Nf6', 'Nf3', 'c6', 'Bc4', 'Bf5', 'Bd2', 'e6'],
        explanations: [
          {
            move: 'd5',
            ply: 2,
            title: 'Immediate Central Challenge',
            why: 'Forces White to make a central decision immediately on move one.',
            plans: 'Bring queen to active a5 or d6 outpost.',
            arrows: [{ from: nameToSq('d7'), to: nameToSq('d5'), tier: 'best' }],
          },
        ],
      },
    ],
    quiz: [
      {
        id: 'scandi-q1',
        fen: 'rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b KQkq - 0 2',
        question: 'What are Black\'s two main moves after White plays 2.exd5 in the Scandinavian?',
        correctMoveSan: 'Qxd5',
        explanation: 'Black can either recapture immediately with 2...Qxd5 or play the modern gambit 2...Nf6 (Portuguese / Modern Scandinavian).',
        options: ['Qxd5', 'Nf6', 'c6', 'e6'],
      },
    ],
  },
];

// Clean token lists
OPENINGS_DATABASE.forEach((o) => {
  o.tokens = o.moves
    .replace(/\d+\./g, '')
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (o.chapters) {
    o.chapters.forEach((ch) => {
      ch.tokens = ch.moves
        .replace(/\d+\./g, '')
        .trim()
        .split(/\s+/)
        .filter(Boolean);
    });
  }
});

/**
 * Fast FEN-based Opening Book Graph
 * Maps FEN board positions (or truncated FENs without halfmove clock)
 * to theoretical continuations with weights and descriptions.
 */
export interface BookMoveEntry {
  san: string;
  uci: string;
  weight: number; // probability weight (e.g. 10..100)
  openingName: string;
  eco: string;
  style: 'aggressive' | 'solid' | 'balanced';
  comment?: string;
}

// Global FEN Transposition Book Map
const FEN_BOOK_MAP = new Map<string, BookMoveEntry[]>();

function getFenKey(fen: string): string {
  // Normalize FEN by taking board pieces, turn, and castling availability
  const parts = fen.trim().split(/\s+/);
  return `${parts[0]} ${parts[1]} ${parts[2]}`;
}

// Build the book tree dynamically from all database variations and known grandmaster paths
function registerBookLine(moves: string[], openingName: string, eco: string, style: 'aggressive' | 'solid' | 'balanced' = 'balanced') {
  try {
    const chess = new Chess();
    for (let i = 0; i < moves.length; i++) {
      const san = moves[i];
      const fenKey = getFenKey(chess.fen());
      
      const moveRes = chess.move(san);
      if (!moveRes) break;

      const uci = `${moveRes.from}${moveRes.to}${moveRes.promotion ? moveRes.promotion.toLowerCase() : ''}`;
      const entry: BookMoveEntry = {
        san: moveRes.san,
        uci,
        weight: 50,
        openingName,
        eco,
        style,
      };

      const existing = FEN_BOOK_MAP.get(fenKey) || [];
      if (!existing.some((e) => e.san === moveRes.san)) {
        existing.push(entry);
        FEN_BOOK_MAP.set(fenKey, existing);
      }
    }
  } catch (e) {
    // Ignore invalid move strings
  }
}

// Populate FEN Book Map
OPENINGS_DATABASE.forEach((op) => {
  registerBookLine(op.tokens, op.name, op.eco, 'balanced');
  if (op.chapters) {
    op.chapters.forEach((ch) => {
      const isAggressive = ch.title.toLowerCase().includes('gambit') || ch.title.toLowerCase().includes('attack') || ch.title.toLowerCase().includes('dragon');
      registerBookLine(ch.tokens, `${op.name}: ${ch.title}`, op.eco, isAggressive ? 'aggressive' : 'solid');
    });
  }
});

// Additional classical grandmaster continuations to reinforce engine diversity:
const EXTRA_BOOK_LINES = [
  // 1.e4 Open Games
  { moves: ['e4', 'e5', 'Nf3', 'Nc6', 'd4', 'exd4', 'Nxd4', 'Nf6', 'Nc3', 'Bb4'], name: 'Scotch Game: Classical', eco: 'C45', style: 'aggressive' },
  { moves: ['e4', 'e5', 'f4', 'exf4', 'Nf3', 'g5', 'h4', 'g4', 'Ne5'], name: "King's Gambit: Kieseritzky", eco: 'C39', style: 'aggressive' },
  { moves: ['e4', 'e5', 'Nc3', 'Nf6', 'f4', 'd5', 'fxe5', 'Nxe4', 'Qf3'], name: 'Vienna Gambit', eco: 'C29', style: 'aggressive' },
  { moves: ['e4', 'e5', 'Nf3', 'Nf6', 'Nxe5', 'd6', 'Nf3', 'Nxe4', 'd4', 'd5'], name: 'Petrov Defense: Classical', eco: 'C42', style: 'solid' },
  
  // 1.e4 Sicilian Variations
  { moves: ['e4', 'c5', 'Nf3', 'e6', 'd4', 'cxd4', 'Nxd4', 'Nc6', 'Nc3', 'a6'], name: 'Sicilian Defense: Taimanov', eco: 'B48', style: 'solid' },
  { moves: ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'e6', 'g4'], name: 'Sicilian Defense: Scheveningen, Keres Attack', eco: 'B81', style: 'aggressive' },
  { moves: ['e4', 'c5', 'Nc3', 'Nc6', 'g3', 'g6', 'Bg2', 'Bg7', 'd3', 'd6'], name: 'Closed Sicilian', eco: 'B23', style: 'solid' },

  // 1.d4 Variations
  { moves: ['d4', 'Nf6', 'c4', 'e6', 'Nc3', 'Bb4', 'Qc2', 'O-O', 'a3', 'Bxc3+', 'Qxc3'], name: 'Nimzo-Indian Defense: Classical 4.Qc2', eco: 'E32', style: 'solid' },
  { moves: ['d4', 'Nf6', 'c4', 'e6', 'Nf3', 'b6', 'g3', 'Bb7', 'Bg2', 'Be7'], name: "Queen's Indian Defense", eco: 'E15', style: 'solid' },
  { moves: ['d4', 'Nf6', 'c4', 'g6', 'Nc3', 'd5', 'cxd5', 'Nxd5', 'e4', 'Nxc3', 'bxc3', 'Bg7'], name: 'Grünfeld Defense: Exchange Variation', eco: 'D85', style: 'aggressive' },
  { moves: ['d4', 'Nf6', 'c4', 'c5', 'd5', 'e6', 'Nc3', 'exd5', 'cxd5', 'd6', 'e4', 'g6'], name: 'Modern Benoni Defense', eco: 'A70', style: 'aggressive' },
  { moves: ['d4', 'f5', 'g3', 'Nf6', 'Bg2', 'e6', 'Nf3', 'd5', 'O-O', 'Bd6'], name: 'Dutch Defense: Stonewall', eco: 'A90', style: 'aggressive' },

  // Flank Openings
  { moves: ['Nf3', 'd5', 'g3', 'Nf6', 'Bg2', 'c6', 'O-O', 'Bf5', 'd3', 'e6'], name: 'Réti Opening: King\'s Indian Attack', eco: 'A07', style: 'solid' },
  { moves: ['b3', 'e5', 'Bb2', 'Nc6', 'e3', 'd5', 'Bb5', 'Bd6'], name: 'Nimzo-Larsen Attack', eco: 'A01', style: 'aggressive' },
];

EXTRA_BOOK_LINES.forEach((line) => {
  registerBookLine(line.moves, line.name, line.eco, line.style as any);
});

/**
 * Identify opening for a given SAN move sequence
 */
export function findOpening(sanList: string[]): OpeningVariation | null {
  let best: OpeningVariation | null = null;
  let maxMatchedTokens = 0;

  for (const o of OPENINGS_DATABASE) {
    if (o.tokens.length > sanList.length) continue;
    let match = true;
    for (let i = 0; i < o.tokens.length; i++) {
      if (o.tokens[i] !== sanList[i]) {
        match = false;
        break;
      }
    }
    if (match && o.tokens.length > maxMatchedTokens) {
      best = o;
      maxMatchedTokens = o.tokens.length;
    }
  }
  return best;
}

/**
 * Find all theoretical continuations for a given path of SAN moves
 * Checks both SAN token prefixes across all openings/chapters AND FEN transpositions!
 */
export function findBookMoves(sanPath: string[], currentFen?: string): string[] {
  const out = new Set<string>();

  // 1. Search all opening and chapter token paths
  for (const o of OPENINGS_DATABASE) {
    // Check main tokens
    if (o.tokens.length > sanPath.length) {
      let match = true;
      for (let i = 0; i < sanPath.length; i++) {
        if (o.tokens[i] !== sanPath[i]) {
          match = false;
          break;
        }
      }
      if (match) {
        out.add(o.tokens[sanPath.length]);
      }
    }

    // Check all sub-chapters
    if (o.chapters) {
      for (const ch of o.chapters) {
        if (ch.tokens && ch.tokens.length > sanPath.length) {
          let match = true;
          for (let i = 0; i < sanPath.length; i++) {
            if (ch.tokens[i] !== sanPath[i]) {
              match = false;
              break;
            }
          }
          if (match) {
            out.add(ch.tokens[sanPath.length]);
          }
        }
      }
    }
  }

  // 2. Search FEN-based transposition graph if FEN is available
  if (currentFen) {
    const key = getFenKey(currentFen);
    const entries = FEN_BOOK_MAP.get(key);
    if (entries) {
      entries.forEach((e) => out.add(e.san));
    }
  }

  return Array.from(out);
}

/**
 * Engine Book Move Selector
 * Picks a theoretical book move based on the current FEN position
 * with randomized variety and playstyle awareness.
 */
export function getEngineBookMove(
  fen: string,
  botPreset?: string
): { uci: string; san: string; openingName: string; eco: string; style: string } | null {
  const key = getFenKey(fen);
  const candidates = FEN_BOOK_MAP.get(key);
  if (!candidates || candidates.length === 0) return null;

  // Filter or weight by bot preset style
  let pool = [...candidates];
  if (botPreset === 'expert' || botPreset === 'master' || botPreset === 'grandmaster') {
    // High-elo bots play sharp/accurate moves
    pool = candidates.filter((c) => c.style === 'aggressive' || c.weight >= 50);
    if (!pool.length) pool = candidates;
  }

  // Weighted random pick
  const totalWeight = pool.reduce((sum, c) => sum + c.weight, 0);
  let randomVal = Math.random() * totalWeight;

  for (const c of pool) {
    randomVal -= c.weight;
    if (randomVal <= 0) {
      return {
        uci: c.uci,
        san: c.san,
        openingName: c.openingName,
        eco: c.eco,
        style: c.style,
      };
    }
  }

  const fallback = pool[0];
  return {
    uci: fallback.uci,
    san: fallback.san,
    openingName: fallback.openingName,
    eco: fallback.eco,
    style: fallback.style,
  };
}
