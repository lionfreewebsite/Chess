/**
 * Fischer Random Chess (Chess960) Generator
 * Supports generating any position from #0 to #959 by index or random generation.
 */

const KNIGHT_COMBOS: [number, number][] = [
  [0, 1], [0, 2], [0, 3], [0, 4],
  [1, 2], [1, 3], [1, 4],
  [2, 3], [2, 4],
  [3, 4]
];

export interface Chess960Position {
  id: number;
  fen: string;
  rankString: string;
  isStandard: boolean;
}

export function generateChess960(index?: number): Chess960Position {
  let id = typeof index === 'number' ? Math.max(0, Math.min(959, Math.floor(index))) : Math.floor(Math.random() * 960);
  
  const lightSquares = [1, 3, 5, 7]; // b1, d1, f1, h1
  const darkSquares = [0, 2, 4, 6];  // a1, c1, e1, g1

  let n = id;
  
  // 1. Dark-square Bishop (0..3)
  const b1Idx = n % 4;
  n = Math.floor(n / 4);
  const b1Pos = darkSquares[b1Idx];

  // 2. Light-square Bishop (0..3)
  const b2Idx = n % 4;
  n = Math.floor(n / 4);
  const b2Pos = lightSquares[b2Idx];

  // 3. Queen (0..5 on remaining 6 empty squares)
  const qIdx = n % 6;
  n = Math.floor(n / 6);

  // 4. Knights (0..9 combination of 2 in 5 remaining squares)
  const nIdx = n % 10;

  const row: (string | null)[] = new Array(8).fill(null);
  row[b1Pos] = 'B';
  row[b2Pos] = 'B';

  // Find remaining empty slots for Queen
  const emptyForQueen: number[] = [];
  for (let i = 0; i < 8; i++) {
    if (!row[i]) emptyForQueen.push(i);
  }
  row[emptyForQueen[qIdx]] = 'Q';

  // Find remaining empty slots for Knights
  const emptyForKnights: number[] = [];
  for (let i = 0; i < 8; i++) {
    if (!row[i]) emptyForKnights.push(i);
  }
  const [k1, k2] = KNIGHT_COMBOS[nIdx];
  row[emptyForKnights[k1]] = 'N';
  row[emptyForKnights[k2]] = 'N';

  // The remaining 3 empty squares must be filled with R, K, R (King between Rooks)
  const emptyForRKR: number[] = [];
  for (let i = 0; i < 8; i++) {
    if (!row[i]) emptyForRKR.push(i);
  }
  row[emptyForRKR[0]] = 'R';
  row[emptyForRKR[1]] = 'K';
  row[emptyForRKR[2]] = 'R';

  const whiteRank = row.join('');
  const blackRank = whiteRank.toLowerCase();

  const fen = `${blackRank}/pppppppp/8/8/8/8/PPPPPPPP/${whiteRank} w KQkq - 0 1`;

  return {
    id,
    fen,
    rankString: whiteRank,
    isStandard: id === 518, // 518 is RNBQKBNR
  };
}

export function getRandomChess960(): Chess960Position {
  return generateChess960(Math.floor(Math.random() * 960));
}
