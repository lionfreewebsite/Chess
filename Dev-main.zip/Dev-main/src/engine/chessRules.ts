/**
 * High-performance, full-rule Chess Engine in pure TypeScript.
 * Square indices: 0..63 where a1=0, b1=1 ... h1=7, a2=8 ... h8=63
 * file = sq % 8, rank = sq >> 3
 */

import { Move, MoveResult, GameStatus, PieceColor, Square } from '../types/chess';

export const FILES = 'abcdefgh';
export const RANKS = '12345678';
export const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

export function fileOf(sq: Square): number {
  return sq & 7;
}

export function rankOf(sq: Square): number {
  return sq >> 3;
}

export function sqOf(file: number, rank: number): Square {
  return (rank << 3) | file;
}

export function onBoard(file: number, rank: number): boolean {
  return file >= 0 && file < 8 && rank >= 0 && rank < 8;
}

export function sqName(sq: Square): string {
  if (sq < 0 || sq > 63) return '-';
  return FILES[fileOf(sq)] + (rankOf(sq) + 1);
}

export function nameToSq(name: string): Square {
  if (!name || name.length < 2) return -1;
  const f = FILES.indexOf(name[0].toLowerCase());
  const r = parseInt(name[1], 10) - 1;
  if (f < 0 || r < 0 || r > 7) return -1;
  return sqOf(f, r);
}

export function isWhite(p: string | null): boolean {
  return !!p && p === p.toUpperCase();
}

export function isBlack(p: string | null): boolean {
  return !!p && p === p.toLowerCase() && p !== p.toUpperCase();
}

export function colorOf(p: string | null): PieceColor | null {
  if (!p) return null;
  return isWhite(p) ? 'w' : 'b';
}

const KNIGHT_OFFS: [number, number][] = [
  [1, 2], [2, 1], [2, -1], [1, -2],
  [-1, -2], [-2, -1], [-2, 1], [-1, 2]
];

const KING_OFFS: [number, number][] = [
  [1, 0], [1, 1], [0, 1], [-1, 1],
  [-1, 0], [-1, -1], [0, -1], [1, -1]
];

const BISHOP_DIRS: [number, number][] = [
  [1, 1], [1, -1], [-1, 1], [-1, -1]
];

const ROOK_DIRS: [number, number][] = [
  [1, 0], [-1, 0], [0, 1], [0, -1]
];

const QUEEN_DIRS: [number, number][] = [...BISHOP_DIRS, ...ROOK_DIRS];

export interface UndoRecord {
  move: Move;
  board_from: Square;
  board_to: Square;
  prevCastling: { K: boolean; Q: boolean; k: boolean; q: boolean };
  prevEp: Square;
  prevHalfmove: number;
  prevFullmove: number;
  capturedSquare: Square | null;
  capturedPiece: string | null;
  rookFrom: Square | null;
  rookTo: Square | null;
  rookPiece: string | null;
}

export interface HistoryRecord {
  mv: Move;
  undo: UndoRecord;
  san: string;
  fenBefore: string;
  fenAfter: string;
}

export class Chess {
  board: (string | null)[];
  turn: PieceColor;
  castling: { K: boolean; Q: boolean; k: boolean; q: boolean };
  ep: Square;
  halfmove: number;
  fullmove: number;
  history: HistoryRecord[];
  repMap: Map<string, number>;

  constructor(fen?: string) {
    this.board = new Array(64).fill(null);
    this.turn = 'w';
    this.castling = { K: true, Q: true, k: true, q: true };
    this.ep = -1;
    this.halfmove = 0;
    this.fullmove = 1;
    this.history = [];
    this.repMap = new Map();
    const initFen = fen && typeof fen === 'string' && fen.trim() ? fen.trim() : START_FEN;
    this.load(initFen);
  }

  load(fen: string): void {
    const cleanFen = (fen && typeof fen === 'string' && fen.trim()) ? fen.trim() : START_FEN;
    const parts = cleanFen.split(/\s+/);
    const [placement, turn, castling, ep, halfmove, fullmove] = parts;
    if (!placement) {
      this.load(START_FEN);
      return;
    }
    this.board = new Array(64).fill(null);
    const ranks = placement.split('/');
    if (ranks.length !== 8) throw new Error('Invalid FEN: must have 8 ranks');

    for (let r = 0; r < 8; r++) {
      const rankStr = ranks[r];
      let file = 0;
      const boardRank = 7 - r;
      for (const ch of rankStr) {
        if (/[1-8]/.test(ch)) {
          file += parseInt(ch, 10);
        } else {
          if (file > 7) throw new Error('Invalid FEN: rank overflow');
          this.board[sqOf(file, boardRank)] = ch;
          file++;
        }
      }
      if (file !== 8) throw new Error(`Invalid FEN: rank ${8 - r} does not sum to 8`);
    }

    this.turn = turn === 'b' ? 'b' : 'w';
    this.castling = { K: false, Q: false, k: false, q: false };
    if (castling && castling !== '-') {
      const whiteKingSq = this.kingSquare('w');
      const whiteKingFile = whiteKingSq !== -1 ? fileOf(whiteKingSq) : 4;
      const blackKingSq = this.kingSquare('b');
      const blackKingFile = blackKingSq !== -1 ? fileOf(blackKingSq) : 4;

      for (const c of castling) {
        if (c === 'K') this.castling.K = true;
        else if (c === 'Q') this.castling.Q = true;
        else if (c === 'k') this.castling.k = true;
        else if (c === 'q') this.castling.q = true;
        else if (c >= 'A' && c <= 'H') {
          // Shredder-FEN / X-FEN uppercase file letter for White rook
          const file = c.charCodeAt(0) - 'A'.charCodeAt(0);
          if (file > whiteKingFile) this.castling.K = true;
          else if (file < whiteKingFile) this.castling.Q = true;
        } else if (c >= 'a' && c <= 'h') {
          // Shredder-FEN / X-FEN lowercase file letter for Black rook
          const file = c.charCodeAt(0) - 'a'.charCodeAt(0);
          if (file > blackKingFile) this.castling.k = true;
          else if (file < blackKingFile) this.castling.q = true;
        }
      }
    }

    this.ep = ep && ep !== '-' ? nameToSq(ep) : -1;
    this.halfmove = halfmove !== undefined ? parseInt(halfmove, 10) || 0 : 0;
    this.fullmove = fullmove !== undefined ? parseInt(fullmove, 10) || 1 : 1;
    this.history = [];
    this.repMap = new Map();
    this._bumpRep();
  }

  fen(): string {
    let out = '';
    for (let r = 7; r >= 0; r--) {
      let empty = 0;
      for (let f = 0; f < 8; f++) {
        const p = this.board[sqOf(f, r)];
        if (!p) {
          empty++;
        } else {
          if (empty) {
            out += empty;
            empty = 0;
          }
          out += p;
        }
      }
      if (empty) out += empty;
      if (r > 0) out += '/';
    }

    let cast = '';
    if (this.castling.K) cast += 'K';
    if (this.castling.Q) cast += 'Q';
    if (this.castling.k) cast += 'k';
    if (this.castling.q) cast += 'q';
    if (!cast) cast = '-';

    const epStr = this.ep >= 0 ? sqName(this.ep) : '-';
    return `${out} ${this.turn} ${cast} ${epStr} ${this.halfmove} ${this.fullmove}`;
  }

  _repKey(): string {
    return (
      this.board.map((p) => p || '.').join('') +
      this.turn +
      (this.castling.K ? 'K' : '') +
      (this.castling.Q ? 'Q' : '') +
      (this.castling.k ? 'k' : '') +
      (this.castling.q ? 'q' : '') +
      (this.ep >= 0 ? sqName(this.ep) : '-')
    );
  }

  _bumpRep(): void {
    const k = this._repKey();
    this.repMap.set(k, (this.repMap.get(k) || 0) + 1);
  }

  clone(): Chess {
    const c = new Chess(this.fen());
    c.repMap = new Map(this.repMap);
    return c;
  }

  isSquareAttacked(sq: Square, bySide: PieceColor): boolean {
    const f0 = fileOf(sq);
    const r0 = rankOf(sq);

    // Pawns
    const pawnPiece = bySide === 'w' ? 'P' : 'p';
    const dr = bySide === 'w' ? -1 : 1;
    for (const df of [-1, 1]) {
      const f = f0 + df;
      const r = r0 + dr;
      if (onBoard(f, r) && this.board[sqOf(f, r)] === pawnPiece) return true;
    }

    // Knights
    const knightPiece = bySide === 'w' ? 'N' : 'n';
    for (const [df, dr2] of KNIGHT_OFFS) {
      const f = f0 + df;
      const r = r0 + dr2;
      if (onBoard(f, r) && this.board[sqOf(f, r)] === knightPiece) return true;
    }

    // King
    const kingPiece = bySide === 'w' ? 'K' : 'k';
    for (const [df, dr2] of KING_OFFS) {
      const f = f0 + df;
      const r = r0 + dr2;
      if (onBoard(f, r) && this.board[sqOf(f, r)] === kingPiece) return true;
    }

    // Bishops / Queens
    const bishopLike = bySide === 'w' ? ['B', 'Q'] : ['b', 'q'];
    for (const [df, dr2] of BISHOP_DIRS) {
      let f = f0 + df;
      let r = r0 + dr2;
      while (onBoard(f, r)) {
        const p = this.board[sqOf(f, r)];
        if (p) {
          if (bishopLike.includes(p)) return true;
          break;
        }
        f += df;
        r += dr2;
      }
    }

    // Rooks / Queens
    const rookLike = bySide === 'w' ? ['R', 'Q'] : ['r', 'q'];
    for (const [df, dr2] of ROOK_DIRS) {
      let f = f0 + df;
      let r = r0 + dr2;
      while (onBoard(f, r)) {
        const p = this.board[sqOf(f, r)];
        if (p) {
          if (rookLike.includes(p)) return true;
          break;
        }
        f += df;
        r += dr2;
      }
    }

    return false;
  }

  kingSquare(side: PieceColor): Square {
    const k = side === 'w' ? 'K' : 'k';
    for (let sq = 0; sq < 64; sq++) {
      if (this.board[sq] === k) return sq;
    }
    return -1;
  }

  inCheck(side?: PieceColor): boolean {
    const s = side || this.turn;
    const ks = this.kingSquare(s);
    if (ks < 0) return false;
    return this.isSquareAttacked(ks, s === 'w' ? 'b' : 'w');
  }

  _pseudoMoves(side: PieceColor): Move[] {
    const moves: Move[] = [];
    for (let sq = 0; sq < 64; sq++) {
      const p = this.board[sq];
      if (!p) continue;
      if (colorOf(p) !== side) continue;

      const type = p.toUpperCase();
      const f0 = fileOf(sq);
      const r0 = rankOf(sq);

      if (type === 'P') {
        const dir = side === 'w' ? 1 : -1;
        const startRank = side === 'w' ? 1 : 6;
        const promoRank = side === 'w' ? 7 : 0;
        const oneF = f0;
        const oneR = r0 + dir;

        if (onBoard(oneF, oneR) && !this.board[sqOf(oneF, oneR)]) {
          const to = sqOf(oneF, oneR);
          if (oneR === promoRank) {
            for (const pr of ['Q', 'R', 'B', 'N']) {
              moves.push({ from: sq, to, piece: p, promotion: pr, capture: false });
            }
          } else {
            moves.push({ from: sq, to, piece: p, capture: false });
            const twoR = r0 + dir * 2;
            if (r0 === startRank && !this.board[sqOf(f0, twoR)]) {
              moves.push({ from: sq, to: sqOf(f0, twoR), piece: p, capture: false, doubleStep: true });
            }
          }
        }

        for (const df of [-1, 1]) {
          const cf = f0 + df;
          const cr = r0 + dir;
          if (!onBoard(cf, cr)) continue;
          const to = sqOf(cf, cr);
          const target = this.board[to];
          if (target && colorOf(target) !== side) {
            if (cr === promoRank) {
              for (const pr of ['Q', 'R', 'B', 'N']) {
                moves.push({ from: sq, to, piece: p, promotion: pr, capture: true, captured: target });
              }
            } else {
              moves.push({ from: sq, to, piece: p, capture: true, captured: target });
            }
          } else if (to === this.ep && this.ep >= 0) {
            moves.push({ from: sq, to, piece: p, capture: true, enPassant: true, captured: side === 'w' ? 'p' : 'P' });
          }
        }
      } else if (type === 'N') {
        for (const [df, dr] of KNIGHT_OFFS) {
          const f = f0 + df;
          const r = r0 + dr;
          if (!onBoard(f, r)) continue;
          const to = sqOf(f, r);
          const target = this.board[to];
          if (!target) {
            moves.push({ from: sq, to, piece: p, capture: false });
          } else if (colorOf(target) !== side) {
            moves.push({ from: sq, to, piece: p, capture: true, captured: target });
          }
        }
      } else if (type === 'K') {
        for (const [df, dr] of KING_OFFS) {
          const f = f0 + df;
          const r = r0 + dr;
          if (!onBoard(f, r)) continue;
          const to = sqOf(f, r);
          const target = this.board[to];
          if (!target) {
            moves.push({ from: sq, to, piece: p, capture: false });
          } else if (colorOf(target) !== side) {
            moves.push({ from: sq, to, piece: p, capture: true, captured: target });
          }
        }

        // FIDE Chess960 & Standard Castling
        const rank = side === 'w' ? 0 : 7;
        if (rankOf(sq) === rank) {
          const kRight = side === 'w' ? this.castling.K : this.castling.k;
          const qRight = side === 'w' ? this.castling.Q : this.castling.q;
          const oppSide: PieceColor = side === 'w' ? 'b' : 'w';
          const kFile = fileOf(sq);
          const rookPiece = side === 'w' ? 'R' : 'r';

          // 1. Kingside Castling (O-O) -> King to g-file (6), Rook to f-file (5)
          if (kRight) {
            let rFileK = -1;
            for (let f = 7; f > kFile; f--) {
              if (this.board[sqOf(f, rank)] === rookPiece) {
                rFileK = f;
                break;
              }
            }
            if (rFileK !== -1) {
              const rSqK = sqOf(rFileK, rank);
              const kTarget = sqOf(6, rank);

              // Check path is vacant between king & g-file, and rook & f-file (except king & rook)
              let pathClear = true;
              const minF = Math.min(kFile, 6, rFileK, 5);
              const maxF = Math.max(kFile, 6, rFileK, 5);
              for (let f = minF; f <= maxF; f++) {
                const s = sqOf(f, rank);
                if (s !== sq && s !== rSqK && this.board[s] !== null) {
                  pathClear = false;
                  break;
                }
              }

              if (pathClear) {
                // King cannot be in check and cannot pass through attacked squares
                let kingSafe = true;
                const kMin = Math.min(kFile, 6);
                const kMax = Math.max(kFile, 6);
                for (let f = kMin; f <= kMax; f++) {
                  if (this.isSquareAttacked(sqOf(f, rank), oppSide)) {
                    kingSafe = false;
                    break;
                  }
                }

                if (kingSafe) {
                  moves.push({ from: sq, to: kTarget, piece: p, capture: false, castle: 'k' });
                }
              }
            }
          }

          // 2. Queenside Castling (O-O-O) -> King to c-file (2), Rook to d-file (3)
          if (qRight) {
            let rFileQ = -1;
            for (let f = 0; f < kFile; f++) {
              if (this.board[sqOf(f, rank)] === rookPiece) {
                rFileQ = f;
                break;
              }
            }
            if (rFileQ !== -1) {
              const rSqQ = sqOf(rFileQ, rank);
              const kTarget = sqOf(2, rank);

              // Check path is vacant between king & c-file, and rook & d-file (except king & rook)
              let pathClear = true;
              const minF = Math.min(kFile, 2, rFileQ, 3);
              const maxF = Math.max(kFile, 2, rFileQ, 3);
              for (let f = minF; f <= maxF; f++) {
                const s = sqOf(f, rank);
                if (s !== sq && s !== rSqQ && this.board[s] !== null) {
                  pathClear = false;
                  break;
                }
              }

              if (pathClear) {
                // King cannot be in check and cannot pass through attacked squares (kFile to 2)
                let kingSafe = true;
                const kMin = Math.min(kFile, 2);
                const kMax = Math.max(kFile, 2);
                for (let f = kMin; f <= kMax; f++) {
                  if (this.isSquareAttacked(sqOf(f, rank), oppSide)) {
                    kingSafe = false;
                    break;
                  }
                }

                if (kingSafe) {
                  moves.push({ from: sq, to: kTarget, piece: p, capture: false, castle: 'q' });
                }
              }
            }
          }
        }
      } else {
        const dirs = type === 'B' ? BISHOP_DIRS : type === 'R' ? ROOK_DIRS : QUEEN_DIRS;
        for (const [df, dr] of dirs) {
          let f = f0 + df;
          let r = r0 + dr;
          while (onBoard(f, r)) {
            const to = sqOf(f, r);
            const target = this.board[to];
            if (!target) {
              moves.push({ from: sq, to, piece: p, capture: false });
            } else {
              if (colorOf(target) !== side) {
                moves.push({ from: sq, to, piece: p, capture: true, captured: target });
              }
              break;
            }
            f += df;
            r += dr;
          }
        }
      }
    }
    return moves;
  }

  _applyRaw(move: Move): UndoRecord {
    const undo: UndoRecord = {
      move,
      board_from: move.from,
      board_to: move.to,
      prevCastling: { ...this.castling },
      prevEp: this.ep,
      prevHalfmove: this.halfmove,
      prevFullmove: this.fullmove,
      capturedSquare: null,
      capturedPiece: null,
      rookFrom: null,
      rookTo: null,
      rookPiece: null,
    };

    const side = colorOf(move.piece)!;
    const opp: PieceColor = side === 'w' ? 'b' : 'w';

    if (move.enPassant) {
      const capSq = move.to + (side === 'w' ? -8 : 8);
      undo.capturedSquare = capSq;
      undo.capturedPiece = this.board[capSq];
      this.board[capSq] = null;
    } else if (move.capture) {
      undo.capturedSquare = move.to;
      undo.capturedPiece = this.board[move.to];
    }

    if (move.castle) {
      const rank = side === 'w' ? 0 : 7;
      const rookPiece = side === 'w' ? 'R' : 'r';
      let rookFrom: Square = -1;
      let rookTo: Square = -1;

      if (move.castle === 'k') {
        rookTo = sqOf(5, rank);
        for (let f = 7; f > fileOf(move.from); f--) {
          const s = sqOf(f, rank);
          if (this.board[s] === rookPiece) {
            rookFrom = s;
            break;
          }
        }
        if (rookFrom === -1) rookFrom = sqOf(7, rank);
      } else {
        rookTo = sqOf(3, rank);
        for (let f = 0; f < fileOf(move.from); f++) {
          const s = sqOf(f, rank);
          if (this.board[s] === rookPiece) {
            rookFrom = s;
            break;
          }
        }
        if (rookFrom === -1) rookFrom = sqOf(0, rank);
      }

      undo.rookFrom = rookFrom;
      undo.rookTo = rookTo;
      undo.rookPiece = this.board[rookFrom] || rookPiece;

      // Clear both king and rook squares first to avoid overwrite collisions
      this.board[move.from] = null;
      this.board[rookFrom] = null;

      // Place king and rook in their target destinations
      this.board[move.to] = move.piece;
      this.board[rookTo] = undo.rookPiece;
    } else {
      this.board[move.from] = null;
      this.board[move.to] = move.promotion
        ? side === 'w'
          ? move.promotion.toUpperCase()
          : move.promotion.toLowerCase()
        : move.piece;
    }

    const type = move.piece.toUpperCase();
    if (type === 'K') {
      if (side === 'w') {
        this.castling.K = false;
        this.castling.Q = false;
      } else {
        this.castling.k = false;
        this.castling.q = false;
      }
    }

    const clearIfRook = (sq: Square) => {
      const rank = rankOf(sq);
      const file = fileOf(sq);
      if (rank === 0) {
        const kSq = this.kingSquare('w');
        const kFile = kSq !== -1 ? fileOf(kSq) : 4;
        if (file > kFile) this.castling.K = false;
        else if (file < kFile) this.castling.Q = false;
      } else if (rank === 7) {
        const kSq = this.kingSquare('b');
        const kFile = kSq !== -1 ? fileOf(kSq) : 4;
        if (file > kFile) this.castling.k = false;
        else if (file < kFile) this.castling.q = false;
      }
    };

    if (type === 'R') clearIfRook(move.from);
    if (move.capture && undo.capturedSquare !== null) clearIfRook(undo.capturedSquare);

    this.ep = move.doubleStep ? ((move.from + move.to) >> 1) : -1;

    if (type === 'P' || move.capture) this.halfmove = 0;
    else this.halfmove++;

    if (side === 'b') this.fullmove++;
    this.turn = opp;

    return undo;
  }

  _undoRaw(undo: UndoRecord): void {
    const move = undo.move;
    const side = colorOf(move.piece)!;
    this.turn = side;
    this.fullmove = undo.prevFullmove;
    this.halfmove = undo.prevHalfmove;
    this.ep = undo.prevEp;
    this.castling = undo.prevCastling;

    if (move.castle && undo.rookFrom !== null && undo.rookTo !== null) {
      this.board[move.to] = null;
      this.board[undo.rookTo] = null;
      this.board[move.from] = move.piece;
      this.board[undo.rookFrom] = undo.rookPiece;
    } else {
      this.board[move.from] = move.piece;
      this.board[move.to] = null;
    }

    if (undo.capturedSquare !== null) {
      this.board[undo.capturedSquare] = undo.capturedPiece;
    }
  }

  _pinnedSquares(side: PieceColor, kingSq: Square): Set<Square> {
    const pinned = new Set<Square>();
    if (kingSq < 0) return pinned;
    const oppSide: PieceColor = side === 'w' ? 'b' : 'w';
    const bishopLike = oppSide === 'w' ? ['B', 'Q'] : ['b', 'q'];
    const rookLike = oppSide === 'w' ? ['R', 'Q'] : ['r', 'q'];
    const f0 = fileOf(kingSq);
    const r0 = rankOf(kingSq);

    for (const [df, dr] of QUEEN_DIRS) {
      let f = f0 + df;
      let r = r0 + dr;
      let firstOwn: Square = -1;
      const isDiag = df !== 0 && dr !== 0;

      while (onBoard(f, r)) {
        const sq = sqOf(f, r);
        const p = this.board[sq];
        if (p) {
          if (colorOf(p) === side) {
            if (firstOwn === -1) firstOwn = sq;
            else break;
          } else {
            const matches = isDiag ? bishopLike.includes(p) : rookLike.includes(p);
            if (firstOwn !== -1 && matches) pinned.add(firstOwn);
            break;
          }
        }
        f += df;
        r += dr;
      }
    }
    return pinned;
  }

  legalMoves(opts?: { side?: PieceColor; from?: Square }): Move[] {
    const side = (opts && opts.side) || this.turn;
    const from = opts && opts.from;
    const pseudo = this._pseudoMoves(side);
    const legal: Move[] = [];
    const kingSq = this.kingSquare(side);
    const oppSide: PieceColor = side === 'w' ? 'b' : 'w';
    const inCheck = this.isSquareAttacked(kingSq, oppSide);
    const pinned = this._pinnedSquares(side, kingSq);

    for (const m of pseudo) {
      if (from !== undefined && m.from !== from) continue;
      const type = m.piece.toUpperCase();

      if (!inCheck && type !== 'K' && !m.enPassant && !pinned.has(m.from)) {
        legal.push(m);
        continue;
      }

      const undo = this._applyRaw(m);
      const stillCheck = this.isSquareAttacked(this.kingSquare(side), oppSide);
      this._undoRaw(undo);
      if (!stillCheck) legal.push(m);
    }
    return legal;
  }

  getLegalTargetsForSquare(sq: Square): Square[] {
    const moves = this.legalMoves({ from: sq });
    const targets = new Set<Square>();
    for (const m of moves) {
      targets.add(m.to);
      if (m.castle) {
        const kFile = fileOf(m.from);
        const rank = rankOf(m.from);
        const rookPiece = this.turn === 'w' ? 'R' : 'r';
        if (m.castle === 'k') {
          for (let f = 7; f > kFile; f--) {
            if (this.board[sqOf(f, rank)] === rookPiece) {
              targets.add(sqOf(f, rank));
              break;
            }
          }
        } else {
          for (let f = 0; f < kFile; f++) {
            if (this.board[sqOf(f, rank)] === rookPiece) {
              targets.add(sqOf(f, rank));
              break;
            }
          }
        }
      }
    }
    return Array.from(targets);
  }

  _disambiguate(move: Move, legalSiblings: Move[]): string {
    const type = move.piece.toUpperCase();
    if (type === 'P' || type === 'K') return '';
    const others = legalSiblings.filter(
      (m) => m !== move && m.piece === move.piece && m.to === move.to
    );
    if (!others.length) return '';
    const sameFile = others.some((m) => fileOf(m.from) === fileOf(move.from));
    const sameRank = others.some((m) => rankOf(m.from) === rankOf(move.from));
    if (!sameFile) return FILES[fileOf(move.from)];
    if (!sameRank) return String(rankOf(move.from) + 1);
    return sqName(move.from);
  }

  moveToSAN(move: Move, legalSiblings?: Move[]): string {
    if (move.castle === 'k') return this._sanSuffix(move, 'O-O');
    if (move.castle === 'q') return this._sanSuffix(move, 'O-O-O');

    const type = move.piece.toUpperCase();
    let san = '';
    if (type === 'P') {
      if (move.capture) san += FILES[fileOf(move.from)] + 'x';
      san += sqName(move.to);
      if (move.promotion) san += '=' + move.promotion.toUpperCase();
    } else {
      san += type;
      san += this._disambiguate(move, legalSiblings || this.legalMoves());
      if (move.capture) san += 'x';
      san += sqName(move.to);
    }
    return this._sanSuffix(move, san);
  }

  _sanSuffix(move: Move, base: string): string {
    const undo = this._applyRaw(move);
    const opp = this.turn;
    const inCheck = this.inCheck(opp);
    const noMoves = this.legalMoves({ side: opp }).length === 0;
    this._undoRaw(undo);
    if (inCheck && noMoves) return base + '#';
    if (inCheck) return base + '+';
    return base;
  }

  move(input: { from: Square | string; to: Square | string; promotion?: string } | string): MoveResult | null {
    let mv: Move | null = null;
    const legal = this.legalMoves();

    if (typeof input === 'string') {
      mv = this._matchSAN(input, legal);
      if (!mv) return null;
    } else {
      const from = typeof input.from === 'string' ? nameToSq(input.from) : input.from;
      const to = typeof input.to === 'string' ? nameToSq(input.to) : input.to;
      const promo = input.promotion ? input.promotion.toUpperCase() : undefined;

      mv = legal.find(
        (m) =>
          m.from === from &&
          m.to === to &&
          (!promo || (m.promotion && m.promotion.toUpperCase() === promo))
      ) || null;

      if (!mv && !promo) {
        mv = legal.find((m) => m.from === from && m.to === to && (!m.promotion || m.promotion === 'Q')) || null;
      }

      // Also support Chess960 castling where player drops King onto friendly Rook
      if (!mv && from !== -1 && to !== -1) {
        const pieceFrom = this.board[from];
        const pieceTo = this.board[to];
        if (pieceFrom && pieceFrom.toUpperCase() === 'K' && pieceTo && pieceTo.toUpperCase() === 'R' && colorOf(pieceFrom) === colorOf(pieceTo)) {
          const kFile = fileOf(from);
          const rFile = fileOf(to);
          const castleSide = rFile > kFile ? 'k' : 'q';
          mv = legal.find((m) => m.from === from && m.castle === castleSide) || null;
        }
      }
    }

    if (!mv) return null;
    const san = this.moveToSAN(mv, legal);
    const fenBefore = this.fen();
    const undo = this._applyRaw(mv);
    this._bumpRep();
    const fenAfter = this.fen();

    this.history.push({ mv, undo, san, fenBefore, fenAfter });

    return {
      san,
      from: sqName(mv.from),
      to: sqName(mv.to),
      promotion: mv.promotion || null,
      capture: !!mv.capture,
      castle: mv.castle || null,
      enPassant: !!mv.enPassant,
      fenBefore,
      fenAfter,
      piece: mv.piece,
    };
  }

  _matchSAN(token: string, legal: Move[]): Move | null {
    let clean = token.trim().replace(/[+#!?]+$/g, '');
    if (/^0-0-0$/i.test(clean) || /^O-O-O$/i.test(clean)) return legal.find((m) => m.castle === 'q') || null;
    if (/^0-0$/i.test(clean) || /^O-O$/i.test(clean)) return legal.find((m) => m.castle === 'k') || null;

    // Standard SAN has uppercase piece letters [NBRQK] or empty for pawn.
    // Testing case-sensitively first ensures pawn captures like "bxc6" or "bxc3" are parsed as b-file pawn moves, not Bishop moves.
    let m = clean.match(/^([NBRQK]?)([a-h]?)([1-8]?)(x?)([a-h][1-8])(?:=?([NBRQ]))?$/);
    if (!m) {
      m = clean.match(/^([NBRQK]?)([a-h]?)([1-8]?)(x?)([a-h][1-8])(?:=?([NBRQ]))?$/i);
    }
    if (!m) return null;

    const [, pieceLetter, df, dr, , dest, promo] = m;
    const destSq = nameToSq(dest);
    const type = (pieceLetter || 'P').toUpperCase();
    const promoUpper = promo ? promo.toUpperCase() : null;

    const cands = legal.filter((mv) => {
      if (mv.piece.toUpperCase() !== type) return false;
      if (mv.to !== destSq) return false;
      if (df && FILES[fileOf(mv.from)] !== df.toLowerCase()) return false;
      if (dr && String(rankOf(mv.from) + 1) !== dr) return false;
      if (promoUpper && mv.promotion !== promoUpper) return false;
      return true;
    });

    return cands[0] || null;
  }

  undo(): HistoryRecord | null {
    const last = this.history.pop();
    if (!last) return null;
    this._undoRaw(last.undo);

    const k = this._repKey();
    const c = this.repMap.get(k) || 1;
    if (c <= 1) this.repMap.delete(k);
    else this.repMap.set(k, c - 1);

    return last;
  }

  isCheckmate(): boolean {
    return this.inCheck(this.turn) && this.legalMoves().length === 0;
  }

  isStalemate(): boolean {
    return !this.inCheck(this.turn) && this.legalMoves().length === 0;
  }

  isInsufficientMaterial(): boolean {
    const nonKing = this.board
      .map((p, sq) => ({ p, sq }))
      .filter((x) => x.p && x.p.toUpperCase() !== 'K');

    if (nonKing.length === 0) return true; // K vs K
    if (nonKing.length === 1 && ['N', 'B'].includes(nonKing[0].p!.toUpperCase())) return true; // K+B vs K or K+N vs K

    if (nonKing.length === 2 && nonKing.every((x) => x.p!.toUpperCase() === 'B')) {
      const colors = nonKing.map((x) => (fileOf(x.sq) + rankOf(x.sq)) % 2);
      if (colors[0] === colors[1] && colorOf(nonKing[0].p) !== colorOf(nonKing[1].p)) return true; // same-color bishops
    }
    return false;
  }

  isThreefold(): boolean {
    return Array.from(this.repMap.values()).some((c) => c >= 3);
  }

  isFivefold(): boolean {
    return Array.from(this.repMap.values()).some((c) => c >= 5);
  }

  isFiftyMove(): boolean {
    return this.halfmove >= 100;
  }

  isSeventyFive(): boolean {
    return this.halfmove >= 150;
  }

  canClaimDraw(): boolean {
    return this.isThreefold() || this.isFiftyMove();
  }

  status(): GameStatus {
    if (this.isCheckmate()) {
      return { over: true, result: this.turn === 'w' ? '0-1' : '1-0', reason: 'checkmate' };
    }
    if (this.isStalemate()) {
      return { over: true, result: '1/2-1/2', reason: 'stalemate' };
    }
    if (this.isInsufficientMaterial()) {
      return { over: true, result: '1/2-1/2', reason: 'insufficient material' };
    }
    if (this.isSeventyFive()) {
      return { over: true, result: '1/2-1/2', reason: '75-move rule' };
    }
    if (this.isFivefold()) {
      return { over: true, result: '1/2-1/2', reason: 'fivefold repetition' };
    }
    return {
      over: false,
      result: '*',
      reason: null,
      canClaimDraw: this.canClaimDraw(),
      claimReason: this.isThreefold()
        ? 'threefold repetition'
        : this.isFiftyMove()
        ? 'fifty-move rule'
        : null,
    };
  }

  material(side: PieceColor): number {
    const vals: Record<string, number> = { P: 1, N: 3, B: 3, R: 5, Q: 9, K: 0 };
    let total = 0;
    for (const p of this.board) {
      if (p && colorOf(p) === side) total += vals[p.toUpperCase()] || 0;
    }
    return total;
  }

  getCapturedPieces(): { w: string[]; b: string[] } {
    const initialCounts: Record<string, number> = { P: 8, N: 2, B: 2, R: 2, Q: 1, p: 8, n: 2, b: 2, r: 2, q: 1 };
    const currentCounts: Record<string, number> = {};

    for (const p of this.board) {
      if (p && p.toUpperCase() !== 'K') {
        currentCounts[p] = (currentCounts[p] || 0) + 1;
      }
    }

    const capturedW: string[] = []; // Black pieces captured by White (lowercase pieces missing)
    const capturedB: string[] = []; // White pieces captured by Black (uppercase pieces missing)

    for (const p of ['q', 'r', 'b', 'n', 'p']) {
      const missing = Math.max(0, (initialCounts[p] || 0) - (currentCounts[p] || 0));
      for (let i = 0; i < missing; i++) capturedW.push(p);
    }
    for (const p of ['Q', 'R', 'B', 'N', 'P']) {
      const missing = Math.max(0, (initialCounts[p] || 0) - (currentCounts[p] || 0));
      for (let i = 0; i < missing; i++) capturedB.push(p);
    }

    return { w: capturedW, b: capturedB };
  }
}
