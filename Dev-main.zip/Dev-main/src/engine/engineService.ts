/**
 * Robust Engine Service with Automatic Fallback.
 * Ensures the engine works 100% reliably in ANY environment (including iframe,
 * sandboxed, CSP-restricted, or headless environments).
 */

import { Chess } from './chessRules';
import { Searcher, TIME_UP } from './search';
import { PVLine, EngineInfo, EngineBestMoveResult } from '../types/chess';
import { getEngineBookMove } from './openingBook';

export type EngineEvent = 'info' | 'bestmove' | 'error' | 'stopped' | 'source';

export interface EngineSearchOptions {
  multipv?: number;
  maxDepth?: number;
  timeMs?: number;
  infinite?: boolean;
  useBook?: boolean;
  botPreset?: string;
}

export class EngineService {
  private generation: number = 0;
  private activeGen: number | null = null;
  private activeCancelToken: { cancelled: boolean } | null = null;
  private searcher: Searcher = new Searcher();
  private listeners: Map<EngineEvent, Set<(data: any) => void>> = new Map();
  public source: 'in-thread' = 'in-thread';

  constructor() {
    this.init();
  }

  private init() {
    this.source = 'in-thread';
    this.emit('source', { source: this.source });
  }

  public on(event: EngineEvent, fn: (data: any) => void): this {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(fn);
    return this;
  }

  public off(event: EngineEvent, fn: (data: any) => void): this {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.delete(fn);
    }
    return this;
  }

  private emit(event: EngineEvent, payload: any): void {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.forEach((fn) => {
        try {
          fn(payload);
        } catch (e) {
          console.error('[EngineService] Error in listener for', event, e);
        }
      });
    }
  }

  public analyze(fen: string, opts: EngineSearchOptions = {}): number {
    this.stop();
    this.generation++;
    const gen = this.generation;
    this.activeGen = gen;

    const token = { cancelled: false };
    this.activeCancelToken = token;

    this.runSearchAsync(fen, opts, gen, token);
    return gen;
  }

  public stop(): void {
    if (this.activeCancelToken) {
      this.activeCancelToken.cancelled = true;
      this.activeCancelToken = null;
    }
    if (this.activeGen !== null) {
      const oldGen = this.activeGen;
      this.activeGen = null;
      this.emit('stopped', { id: oldGen });
    }
  }

  private async runSearchAsync(
    fen: string,
    opts: EngineSearchOptions,
    gen: number,
    token: { cancelled: boolean }
  ) {
    let chess: Chess;
    try {
      chess = new Chess(fen);
    } catch (err: any) {
      if (this.activeGen === gen) {
        this.emit('error', { id: gen, message: 'Invalid position: ' + (err?.message || err) });
      }
      return;
    }

    const multipv = Math.max(1, opts.multipv || 1);
    const maxDepth = opts.maxDepth || (opts.infinite ? 18 : 14);
    const timeMs = opts.infinite ? 15 * 60 * 1000 : opts.timeMs || 2500;

    const t0 = Date.now();
    let order: any = null;
    let lastLines: PVLine[] = [];
    this.searcher = new Searcher();
    this.searcher.isCancelled = () => token.cancelled || this.activeGen !== gen;

    for (let d = 1; d <= maxDepth; d++) {
      if (token.cancelled || this.activeGen !== gen) return;

      const remaining = timeMs - (Date.now() - t0);
      if (remaining <= 0) break;

      let res: { order: any; lines: PVLine[]; nodes: number };
      try {
        res = await this.searcher.rootSearchDepthAsync(chess, d, multipv, order, Math.max(80, remaining));
      } catch (err) {
        if (err === TIME_UP) break;
        if (this.activeGen === gen) {
          this.emit('error', { id: gen, message: String(err) });
        }
        return;
      }

      if (token.cancelled || this.activeGen !== gen) return;

      order = res.order;
      lastLines = res.lines;
      const elapsed = Math.max(1, Date.now() - t0);

      const info: EngineInfo = {
        id: gen,
        depth: d,
        nodes: res.nodes,
        nps: Math.round(res.nodes / (elapsed / 1000)),
        timeMs: elapsed,
        lines: res.lines,
      };
      this.emit('info', info);

      if (
        res.lines[0] &&
        res.lines[0].score &&
        res.lines[0].score.mate !== undefined &&
        Math.abs(res.lines[0].score.mate) < 1000
      ) {
        break;
      }

      if (Date.now() - t0 >= timeMs) break;

      // Yield smoothly to main event loop between depth levels
      await new Promise((r) => setTimeout(r, 4));
    }

    if (token.cancelled || this.activeGen !== gen) return;
    this.activeGen = null;
    const bestMove = lastLines[0] && lastLines[0].pv[0] ? lastLines[0].pv[0] : null;
    this.emit('bestmove', { id: gen, move: bestMove, lines: lastLines });
  }

  public getBestMove(fen: string, opts: EngineSearchOptions = {}): Promise<string | null> {
    if (opts.useBook !== false) {
      const bookChoice = getEngineBookMove(fen, opts.botPreset);
      if (bookChoice) {
        return Promise.resolve(bookChoice.uci);
      }
    }

    return new Promise((resolve, reject) => {
      const gen = this.analyze(fen, opts);
      const onBest = (payload: EngineBestMoveResult) => {
        if (payload.id !== gen) return;
        cleanup();
        resolve(payload.move);
      };
      const onErr = (payload: any) => {
        if (payload.id !== gen) return;
        cleanup();
        reject(new Error(payload.message || 'Engine error'));
      };
      const cleanup = () => {
        this.off('bestmove', onBest);
        this.off('error', onErr);
      };
      this.on('bestmove', onBest);
      this.on('error', onErr);
    });
  }

  public getBestMoveWithAlternatives(
    fen: string,
    opts: EngineSearchOptions = {}
  ): Promise<{ move: string | null; lines: PVLine[] }> {
    if (opts.useBook !== false) {
      const bookChoice = getEngineBookMove(fen, opts.botPreset);
      if (bookChoice) {
        return Promise.resolve({
          move: bookChoice.uci,
          lines: [
            {
              score: { cp: 15 },
              pv: [bookChoice.uci],
              pvSan: [bookChoice.san],
              depth: 24,
            },
          ],
        });
      }
    }

    return new Promise((resolve, reject) => {
      const gen = this.analyze(fen, opts);
      let lastLines: PVLine[] = [];

      const onInfo = (payload: EngineInfo) => {
        if (payload.id === gen && payload.lines) lastLines = payload.lines;
      };
      const onBest = (payload: EngineBestMoveResult) => {
        if (payload.id !== gen) return;
        cleanup();
        resolve({ move: payload.move, lines: payload.lines || lastLines });
      };
      const onErr = (payload: any) => {
        if (payload.id !== gen) return;
        cleanup();
        reject(new Error(payload.message || 'Engine error'));
      };
      const cleanup = () => {
        this.off('info', onInfo);
        this.off('bestmove', onBest);
        this.off('error', onErr);
      };
      this.on('info', onInfo);
      this.on('bestmove', onBest);
      this.on('error', onErr);
    });
  }
}

export const globalEngine = new EngineService();
