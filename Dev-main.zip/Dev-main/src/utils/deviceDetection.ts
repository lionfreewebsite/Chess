export interface DeviceCapabilities {
  isLowOrMidEnd: boolean;
  hardwareConcurrency: number;
  isMobile: boolean;
  suggestedDepth: number;
  suggestedMultiPV: number;
}

export function detectDeviceCapabilities(): DeviceCapabilities {
  const hardwareConcurrency = typeof navigator !== 'undefined' && navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 4;
  const isMobile = typeof navigator !== 'undefined' && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent || '');
  
  // Consider low or mid-end if cores <= 4 or mobile device
  const isLowOrMidEnd = isMobile || hardwareConcurrency <= 4;
  
  return {
    isLowOrMidEnd,
    hardwareConcurrency,
    isMobile,
    suggestedDepth: isLowOrMidEnd ? 12 : 16,
    suggestedMultiPV: isLowOrMidEnd ? 2 : 3,
  };
}

export function getOptimizationMode(): boolean {
  try {
    const saved = localStorage.getItem('aperture_optimization_mode');
    if (saved === 'true') return true;
    if (saved === 'false') return false;
    // Default: Auto-detect
    return detectDeviceCapabilities().isLowOrMidEnd;
  } catch {
    return true;
  }
}

export function setOptimizationMode(enabled: boolean): void {
  try {
    localStorage.setItem('aperture_optimization_mode', String(enabled));
  } catch {}
}
