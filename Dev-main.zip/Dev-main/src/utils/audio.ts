/**
 * Synthesizer Audio Manager for Chess.
 * Produces crisp, non-distracting, high-fidelity procedural game sound effects
 * without external audio asset downloads.
 */

export type SoundType =
  | 'move'
  | 'capture'
  | 'check'
  | 'castle'
  | 'promote'
  | 'victory'
  | 'defeat'
  | 'draw'
  | 'resign'
  | 'gameStart'
  | 'error';

export interface SoundConfig {
  move: boolean;
  capture: boolean;
  check: boolean;
  castle: boolean;
  promote: boolean;
  victory: boolean;
  defeat: boolean;
  draw: boolean;
  resign: boolean;
  gameStart: boolean;
  error: boolean;
}

export const DEFAULT_SOUND_CONFIG: SoundConfig = {
  move: true,
  capture: true,
  check: true,
  castle: true,
  promote: true,
  victory: true,
  defeat: true,
  draw: true,
  resign: true,
  gameStart: true,
  error: true,
};

const SOUND_CONFIG_STORAGE_KEY = 'aperture_sound_fx_config';

export class AudioManager {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;
  public volume: number = 0.5;
  private soundConfig: SoundConfig;

  constructor() {
    this.soundConfig = this.loadConfig();
  }

  private loadConfig(): SoundConfig {
    try {
      const stored = localStorage.getItem(SOUND_CONFIG_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_SOUND_CONFIG, ...parsed };
      }
    } catch {
      // Fall back to default
    }
    return { ...DEFAULT_SOUND_CONFIG };
  }

  public saveConfig(): void {
    try {
      localStorage.setItem(SOUND_CONFIG_STORAGE_KEY, JSON.stringify(this.soundConfig));
    } catch {
      // Ignore storage errors
    }
  }

  public getConfig(): SoundConfig {
    return { ...this.soundConfig };
  }

  public setSoundEffectEnabled(type: SoundType, isEnabled: boolean): void {
    this.soundConfig[type] = isEnabled;
    this.saveConfig();
  }

  public setAllSoundEffects(isEnabled: boolean): void {
    for (const key of Object.keys(this.soundConfig) as SoundType[]) {
      this.soundConfig[key] = isEnabled;
    }
    this.saveConfig();
  }

  public isSoundActive(type: SoundType): boolean {
    return this.enabled && (this.soundConfig[type] ?? true);
  }

  private ensureContext(): AudioContext | null {
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || (window as any).webkitAudioContext;
        if (AC) this.ctx = new AC();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    } catch {
      return null;
    }
  }

  private tone(
    freq: number,
    duration: number,
    opts: { type?: OscillatorType; delay?: number; gain?: number; freqTo?: number } = {}
  ): void {
    if (!this.enabled) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx) return;

      const vol = Math.max(0, Math.min(1, this.volume * (opts.gain !== undefined ? opts.gain : 1)));
      const t0 = ctx.currentTime + (opts.delay || 0);

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = opts.type || 'sine';
      osc.frequency.setValueAtTime(freq, t0);
      if (opts.freqTo) {
        osc.frequency.exponentialRampToValueAtTime(opts.freqTo, t0 + duration);
      }

      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t0 + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t0);
      osc.stop(t0 + duration + 0.03);
    } catch {
      // Audio failure should never impede UI
    }
  }

  /** Standard Piece Movement */
  move(): void {
    if (!this.isSoundActive('move')) return;
    this.tone(520, 0.07, { type: 'triangle', gain: 0.9 });
    this.tone(1100, 0.02, { type: 'sine', gain: 0.3 });
  }

  /** Piece Capture */
  capture(): void {
    if (!this.isSoundActive('capture')) return;
    this.tone(320, 0.09, { type: 'square', gain: 0.55 });
    this.tone(160, 0.11, { type: 'triangle', delay: 0.015, gain: 0.5 });
  }

  /** Check Alert Bell */
  check(): void {
    if (!this.isSoundActive('check')) return;
    this.tone(740, 0.11, { type: 'sine', gain: 0.85 });
    this.tone(920, 0.14, { type: 'sine', delay: 0.045, gain: 0.9 });
  }

  /** Castling Double Piece Slide */
  castle(): void {
    if (!this.isSoundActive('castle')) return;
    this.tone(440, 0.07, { type: 'triangle', gain: 0.85 });
    this.tone(580, 0.09, { type: 'triangle', delay: 0.045, gain: 0.85 });
  }

  /** Pawn Promotion Jingle */
  promote(): void {
    if (!this.isSoundActive('promote')) return;
    [523, 659, 784, 1046].forEach((f, i) => {
      this.tone(f, 0.1, { type: 'sine', delay: i * 0.045, gain: 0.75 });
    });
  }

  /** Game Start */
  gameStart(): void {
    if (!this.isSoundActive('gameStart')) return;
    this.tone(392, 0.09, { type: 'triangle', gain: 0.8 });
    this.tone(523, 0.13, { type: 'triangle', delay: 0.06, gain: 0.85 });
  }

  /** Triumphant Victory / Winning Checkmate */
  victory(): void {
    if (!this.isSoundActive('victory')) return;
    [523, 659, 784, 987, 1046].forEach((f, i) => {
      this.tone(f, 0.16, { type: 'triangle', delay: i * 0.07, gain: 0.9 });
    });
  }

  /** Defeat / Checkmate Loss (descending minor cadence) */
  defeat(): void {
    if (!this.isSoundActive('defeat')) return;
    [392, 311, 261, 196].forEach((f, i) => {
      this.tone(f, 0.2, { type: 'sine', delay: i * 0.09, gain: 0.8 });
    });
  }

  /** Draw Outcome (balanced harmonic chime) */
  draw(): void {
    if (!this.isSoundActive('draw')) return;
    this.tone(440, 0.16, { type: 'sine', gain: 0.7 });
    this.tone(554, 0.18, { type: 'sine', delay: 0.04, gain: 0.7 });
    this.tone(440, 0.22, { type: 'sine', delay: 0.14, gain: 0.6 });
  }

  /** Resignation Tone (gentle acknowledging descent) */
  resign(): void {
    if (!this.isSoundActive('resign')) return;
    this.tone(392, 0.12, { type: 'sine', gain: 0.75 });
    this.tone(293, 0.18, { type: 'sine', delay: 0.08, gain: 0.7 });
  }

  /** Illegal Move or Puzzle Error */
  error(): void {
    if (!this.isSoundActive('error')) return;
    this.tone(180, 0.14, { type: 'sawtooth', gain: 0.35 });
  }

  /** Sound Preview Test */
  test(): void {
    this.tone(523, 0.18, { type: 'sine', gain: 0.8 });
  }
}

export const globalAudio = new AudioManager();
