import { UIThemeColor } from '../types/chess';

export interface UIThemeOption {
  id: UIThemeColor;
  label: string;
  desc: string;
  previewColor: string;
  hex: string;
  primaryClass: string;
  hoverClass: string;
  textClass: string;
  borderClass: string;
  ringClass: string;
  badgeBg: string;
  activeTabClass: string;
  subtleBgClass: string;
  sliderAccent: string;
}

export const UI_THEMES: UIThemeOption[] = [
  {
    id: 'amber',
    label: 'Amber Gold (Default)',
    desc: 'Warm grandmaster amber & gold tones',
    previewColor: '#f59e0b',
    hex: '#f59e0b',
    primaryClass: 'bg-amber-400 hover:bg-amber-300 text-stone-950',
    hoverClass: 'hover:bg-amber-400/20 hover:text-amber-500',
    textClass: 'text-amber-500 dark:text-amber-400',
    borderClass: 'border-amber-400 dark:border-amber-500',
    ringClass: 'ring-amber-400/40',
    badgeBg: 'bg-amber-500/20 text-amber-700 dark:text-amber-300',
    activeTabClass: 'bg-amber-400 text-stone-950 font-bold shadow-xs',
    subtleBgClass: 'bg-amber-500/10 dark:bg-amber-500/15',
    sliderAccent: 'accent-amber-500',
  },
  {
    id: 'emerald',
    label: 'Tournament Emerald',
    desc: 'Classic international chess green',
    previewColor: '#10b981',
    hex: '#10b981',
    primaryClass: 'bg-emerald-500 hover:bg-emerald-400 text-stone-950',
    hoverClass: 'hover:bg-emerald-500/20 hover:text-emerald-500',
    textClass: 'text-emerald-500 dark:text-emerald-400',
    borderClass: 'border-emerald-500 dark:border-emerald-400',
    ringClass: 'ring-emerald-400/40',
    badgeBg: 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300',
    activeTabClass: 'bg-emerald-500 text-stone-950 font-bold shadow-xs',
    subtleBgClass: 'bg-emerald-500/10 dark:bg-emerald-500/15',
    sliderAccent: 'accent-emerald-500',
  },
  {
    id: 'sapphire',
    label: 'Sapphire Modern Blue',
    desc: 'Crisp deep cobalt & ocean azure',
    previewColor: '#3b82f6',
    hex: '#3b82f6',
    primaryClass: 'bg-blue-500 hover:bg-blue-400 text-white',
    hoverClass: 'hover:bg-blue-500/20 hover:text-blue-500',
    textClass: 'text-blue-500 dark:text-blue-400',
    borderClass: 'border-blue-500 dark:border-blue-400',
    ringClass: 'ring-blue-400/40',
    badgeBg: 'bg-blue-500/20 text-blue-700 dark:text-blue-300',
    activeTabClass: 'bg-blue-500 text-white font-bold shadow-xs',
    subtleBgClass: 'bg-blue-500/10 dark:bg-blue-500/15',
    sliderAccent: 'accent-blue-500',
  },
  {
    id: 'violet',
    label: 'Royal Amethyst',
    desc: 'Sophisticated royal purple & lavender',
    previewColor: '#8b5cf6',
    hex: '#8b5cf6',
    primaryClass: 'bg-purple-500 hover:bg-purple-400 text-white',
    hoverClass: 'hover:bg-purple-500/20 hover:text-purple-400',
    textClass: 'text-purple-500 dark:text-purple-400',
    borderClass: 'border-purple-500 dark:border-purple-400',
    ringClass: 'ring-purple-400/40',
    badgeBg: 'bg-purple-500/20 text-purple-700 dark:text-purple-300',
    activeTabClass: 'bg-purple-500 text-white font-bold shadow-xs',
    subtleBgClass: 'bg-purple-500/10 dark:bg-purple-500/15',
    sliderAccent: 'accent-purple-500',
  },
  {
    id: 'rose',
    label: 'Crimson Rose',
    desc: 'Vibrant championship crimson ruby',
    previewColor: '#f43f5e',
    hex: '#f43f5e',
    primaryClass: 'bg-rose-500 hover:bg-rose-400 text-white',
    hoverClass: 'hover:bg-rose-500/20 hover:text-rose-400',
    textClass: 'text-rose-500 dark:text-rose-400',
    borderClass: 'border-rose-500 dark:border-rose-400',
    ringClass: 'ring-rose-400/40',
    badgeBg: 'bg-rose-500/20 text-rose-700 dark:text-rose-300',
    activeTabClass: 'bg-rose-500 text-white font-bold shadow-xs',
    subtleBgClass: 'bg-rose-500/10 dark:bg-rose-500/15',
    sliderAccent: 'accent-rose-500',
  },
  {
    id: 'cyan',
    label: 'Cyber Cyan / Teal',
    desc: 'Modern oceanic high-contrast teal',
    previewColor: '#06b6d4',
    hex: '#06b6d4',
    primaryClass: 'bg-cyan-500 hover:bg-cyan-400 text-stone-950',
    hoverClass: 'hover:bg-cyan-500/20 hover:text-cyan-400',
    textClass: 'text-cyan-500 dark:text-cyan-400',
    borderClass: 'border-cyan-500 dark:border-cyan-400',
    ringClass: 'ring-cyan-400/40',
    badgeBg: 'bg-cyan-500/20 text-cyan-700 dark:text-cyan-300',
    activeTabClass: 'bg-cyan-500 text-stone-950 font-bold shadow-xs',
    subtleBgClass: 'bg-cyan-500/10 dark:bg-cyan-500/15',
    sliderAccent: 'accent-cyan-500',
  },
  {
    id: 'ruby',
    label: 'Fiery Ruby Red',
    desc: 'High energy scarlet tactical highlight',
    previewColor: '#ef4444',
    hex: '#ef4444',
    primaryClass: 'bg-red-500 hover:bg-red-400 text-white',
    hoverClass: 'hover:bg-red-500/20 hover:text-red-400',
    textClass: 'text-red-500 dark:text-red-400',
    borderClass: 'border-red-500 dark:border-red-400',
    ringClass: 'ring-red-400/40',
    badgeBg: 'bg-red-500/20 text-red-700 dark:text-red-300',
    activeTabClass: 'bg-red-500 text-white font-bold shadow-xs',
    subtleBgClass: 'bg-red-500/10 dark:bg-red-500/15',
    sliderAccent: 'accent-red-500',
  },
];

export function getThemeConfig(themeId?: UIThemeColor | string): UIThemeOption {
  if (themeId === 'orange') return UI_THEMES[0];
  return UI_THEMES.find((t) => t.id === themeId) || UI_THEMES[0];
}

