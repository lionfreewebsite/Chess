import { MoveClassification } from '../types/chess';

export interface ClassificationBadgeConfig {
  label: string;
  badgeText: string;
  bgClass: string;
  textClass: string;
  ringClass: string;
  borderClass: string;
  badgeBgLight: string;
  iconType: 'text' | 'star' | 'book' | 'check' | 'cross' | 'double_excl';
}

export const CLASSIFICATION_CONFIGS: Record<MoveClassification, ClassificationBadgeConfig> = {
  brilliant: {
    label: 'Brilliant Move',
    badgeText: '!!',
    bgClass: 'bg-cyan-500',
    textClass: 'text-white',
    ringClass: 'ring-cyan-300 dark:ring-cyan-400',
    borderClass: 'border-cyan-500/40',
    badgeBgLight: 'bg-cyan-500/20 text-cyan-700 dark:text-cyan-300',
    iconType: 'double_excl',
  },
  best: {
    label: 'Best Move',
    badgeText: '★',
    bgClass: 'bg-emerald-600',
    textClass: 'text-white',
    ringClass: 'ring-emerald-400 dark:ring-emerald-300',
    borderClass: 'border-emerald-500/40',
    badgeBgLight: 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300',
    iconType: 'star',
  },
  excellent: {
    label: 'Excellent Move',
    badgeText: '✓',
    bgClass: 'bg-emerald-400 dark:bg-emerald-500',
    textClass: 'text-stone-950 dark:text-stone-900',
    ringClass: 'ring-emerald-200 dark:ring-emerald-400',
    borderClass: 'border-emerald-500/30',
    badgeBgLight: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300',
    iconType: 'check',
  },
  good: {
    label: 'Good Move',
    badgeText: '✓',
    bgClass: 'bg-sky-500',
    textClass: 'text-white',
    ringClass: 'ring-sky-300 dark:ring-sky-400',
    borderClass: 'border-sky-500/30',
    badgeBgLight: 'bg-sky-500/15 text-sky-700 dark:text-sky-300',
    iconType: 'check',
  },
  book: {
    label: 'Opening Book Move',
    badgeText: '📖',
    bgClass: 'bg-amber-700',
    textClass: 'text-white',
    ringClass: 'ring-amber-400 dark:ring-amber-500',
    borderClass: 'border-amber-500/40',
    badgeBgLight: 'bg-amber-500/20 text-amber-700 dark:text-amber-300',
    iconType: 'book',
  },
  inaccuracy: {
    label: 'Inaccuracy',
    badgeText: '?!',
    bgClass: 'bg-yellow-400',
    textClass: 'text-stone-950',
    ringClass: 'ring-yellow-200 dark:ring-yellow-300',
    borderClass: 'border-yellow-500/40',
    badgeBgLight: 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-300',
    iconType: 'text',
  },
  mistake: {
    label: 'Mistake',
    badgeText: '?',
    bgClass: 'bg-orange-500',
    textClass: 'text-white',
    ringClass: 'ring-orange-300 dark:ring-orange-400',
    borderClass: 'border-orange-500/40',
    badgeBgLight: 'bg-orange-500/20 text-orange-700 dark:text-orange-300',
    iconType: 'text',
  },
  blunder: {
    label: 'Blunder',
    badgeText: '??',
    bgClass: 'bg-red-600',
    textClass: 'text-white',
    ringClass: 'ring-red-400 dark:ring-red-300',
    borderClass: 'border-red-500/40',
    badgeBgLight: 'bg-red-500/20 text-red-700 dark:text-red-300',
    iconType: 'text',
  },
  missedwin: {
    label: 'Missed Win',
    badgeText: '✕',
    bgClass: 'bg-pink-600',
    textClass: 'text-white',
    ringClass: 'ring-pink-400 dark:ring-pink-300',
    borderClass: 'border-pink-500/40',
    badgeBgLight: 'bg-pink-500/20 text-pink-700 dark:text-pink-300',
    iconType: 'cross',
  },
  miss: {
    label: 'Miss',
    badgeText: '✕',
    bgClass: 'bg-pink-600',
    textClass: 'text-white',
    ringClass: 'ring-pink-400 dark:ring-pink-300',
    borderClass: 'border-pink-500/40',
    badgeBgLight: 'bg-pink-500/20 text-pink-700 dark:text-pink-300',
    iconType: 'cross',
  },
};

export function getClassificationConfig(cls?: MoveClassification | null): ClassificationBadgeConfig | null {
  if (!cls) return null;
  return CLASSIFICATION_CONFIGS[cls] || null;
}
