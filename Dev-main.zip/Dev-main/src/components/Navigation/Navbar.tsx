import React, { useState } from 'react';
import {
  Swords,
  Activity,
  Bot,
  Puzzle,
  BookOpen,
  Edit3,
  Archive,
  Settings,
  ChevronDown,
  Sun,
  Moon,
  Sparkles,
  Zap,
} from 'lucide-react';
import { AppMode, UIThemeColor } from '../../types/chess';
import { getThemeConfig } from '../../utils/themeColors';

interface NavbarProps {
  currentMode: AppMode;
  onSelectMode: (mode: AppMode) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  uiTheme?: UIThemeColor;
}

interface ModeItem {
  id: AppMode;
  label: string;
  shortLabel: string;
  icon: React.ElementType;
  description: string;
  badge?: string;
}

const MODES: ModeItem[] = [
  {
    id: 'play',
    label: 'Play Game',
    shortLabel: 'Play',
    icon: Swords,
    description: 'Human vs Bot & Two Player match with clocks',
  },
  {
    id: 'analysis',
    label: 'Analysis & Review',
    shortLabel: 'Analysis',
    icon: Activity,
    description: 'Live evaluation, deep multi-PV lines, and game review',
    badge: 'Live',
  },
  {
    id: 'opening',
    label: 'Opening Trainer',
    shortLabel: 'Openings',
    icon: BookOpen,
    description: 'Master grandmaster theory, variants & practice',
    badge: 'New',
  },
  {
    id: 'puzzles',
    label: 'Tactical Puzzles',
    shortLabel: 'Puzzles',
    icon: Puzzle,
    description: 'Engine-generated tactical positions & rating climb',
    badge: 'Beta',
  },
  {
    id: 'botmatch',
    label: 'Bot vs Bot',
    shortLabel: 'Bot Match',
    icon: Bot,
    description: 'Simulate automated engine duels & analyze games',
  },
  {
    id: 'editor',
    label: 'Board Editor',
    shortLabel: 'Editor',
    icon: Edit3,
    description: 'Set up custom positions, edit FEN, and analyze',
  },
  {
    id: 'games',
    label: 'Saved Games',
    shortLabel: 'Games',
    icon: Archive,
    description: 'PGN database, game history, and exports',
  },
  {
    id: 'settings',
    label: 'Settings',
    shortLabel: 'Settings',
    icon: Settings,
    description: 'Board themes, piece styles, sounds & preferences',
  },
];

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  onSelectMode,
  isDarkMode,
  onToggleTheme,
  uiTheme = 'amber',
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const activeModeItem = MODES.find((m) => m.id === currentMode) || MODES[0];
  const themeCfg = getThemeConfig(uiTheme);

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-b border-stone-200 dark:border-stone-800 text-stone-900 dark:text-stone-100 shadow-sm transition-colors">
      {/* Top Header Row */}
      <div className="max-w-7xl mx-auto px-3 sm:px-5 h-14 flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <div
            className={`w-8 h-8 rounded-lg ${themeCfg.badgeBg} border ${themeCfg.borderClass} flex items-center justify-center ${themeCfg.textClass} font-serif font-black text-lg shadow-inner`}
          >
            ♟
          </div>
          <div className="flex flex-col">
            <span className="font-serif font-black tracking-wider text-base sm:text-lg leading-tight text-stone-900 dark:text-stone-100">
              APER<span className={themeCfg.textClass}>TURE</span>
            </span>
            <span className="text-[9px] font-mono tracking-widest text-stone-500 dark:text-stone-400 uppercase -mt-0.5 hidden xs:inline">
              CHESS WORKBENCH
            </span>
          </div>
        </div>

        {/* Engine Status Badge */}
        <div
          id="engine-status-pill"
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-stone-100 dark:bg-stone-800/80 border border-stone-200 dark:border-stone-700/60 text-[11px] font-mono text-emerald-600 dark:text-emerald-400 shadow-xs"
          title="Search engine is live and running"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-pulse shadow-sm" />
          <span>Local Engine Active</span>
        </div>

        {/* Mode Selector Dropdown Button for Mobile */}
        <div className="relative md:hidden">
          <button
            id="mobile-mode-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 border border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold shadow-xs transition-colors"
            aria-expanded={mobileMenuOpen}
            aria-label="Select Game Mode"
          >
            <activeModeItem.icon className={`w-4 h-4 ${themeCfg.textClass}`} />
            <span>{activeModeItem.label}</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${mobileMenuOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Mobile Dropdown Popover */}
          {mobileMenuOpen && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl shadow-2xl p-2 z-50 flex flex-col gap-1 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-2 py-1 text-[10px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400 border-b border-stone-100 dark:border-stone-800 mb-1">
                Select Application Mode
              </div>
              {MODES.map((mode) => {
                const Icon = mode.icon;
                const isActive = mode.id === currentMode;
                return (
                  <button
                    key={mode.id}
                    id={`mobile-nav-${mode.id}`}
                    onClick={() => {
                      onSelectMode(mode.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-start gap-3 p-2 rounded-lg text-left transition-all ${
                      isActive
                        ? `${themeCfg.primaryClass} font-semibold shadow-xs`
                        : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 hover:text-stone-950 dark:hover:text-white'
                    }`}
                  >
                    <Icon className={`w-5 h-5 shrink-0 mt-0.5 ${isActive ? 'text-inherit' : themeCfg.textClass}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium truncate">{mode.label}</span>
                        {mode.badge && (
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                              isActive
                                ? 'bg-black/20 text-inherit'
                                : themeCfg.badgeBg
                            }`}
                          >
                            {mode.badge}
                          </span>
                        )}
                      </div>
                      <p className={`text-[10px] leading-tight truncate ${isActive ? 'opacity-80' : 'text-stone-500 dark:text-stone-400'}`}>
                        {mode.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            id="theme-toggle-btn"
            onClick={onToggleTheme}
            className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Theme"
          >
            {isDarkMode ? <Sun className={`w-4 h-4 ${themeCfg.textClass}`} /> : <Moon className="w-4 h-4 text-stone-700" />}
          </button>
        </div>
      </div>

      {/* Dynamic Scrollable Modes Bar */}
      <div className="border-t border-stone-200 dark:border-stone-800/80 bg-stone-50/80 dark:bg-stone-950/50">
        <div className="max-w-7xl mx-auto px-2 sm:px-4">
          <nav
            className="flex items-center gap-1 overflow-x-auto py-1.5 no-scrollbar scroll-smooth"
            role="tablist"
            aria-label="Modes Navigation Bar"
          >
            {MODES.map((mode) => {
              const Icon = mode.icon;
              const isActive = mode.id === currentMode;
              return (
                <button
                  key={mode.id}
                  id={`nav-tab-${mode.id}`}
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => onSelectMode(mode.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all shrink-0 cursor-pointer ${
                    isActive
                      ? `${themeCfg.primaryClass} shadow-xs font-bold`
                      : 'text-stone-600 dark:text-stone-300 hover:text-stone-950 dark:hover:text-white hover:bg-stone-200/60 dark:hover:bg-stone-800/70'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-inherit' : themeCfg.textClass}`} />
                  <span>{mode.label}</span>
                  {mode.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono ${
                        isActive
                          ? 'bg-black/20 text-inherit font-bold'
                          : `${themeCfg.badgeBg} font-bold`
                      }`}
                    >
                      {mode.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};

