import React from 'react';
import { PieceStyle, PieceTheme } from '../../types/chess';

interface ChessPieceSvgProps {
  piece: string; // 'P','N','B','R','Q','K','p','n','b','r','q','k'
  styleType?: PieceStyle;
  theme?: PieceTheme;
  className?: string;
}

export const ChessPieceSvg: React.FC<ChessPieceSvgProps> = ({
  piece,
  styleType = 'svg',
  theme = 'ivory',
  className = '',
}) => {
  if (!piece) return null;
  const isWhite = piece === piece.toUpperCase();
  const type = piece.toUpperCase();

  if (styleType === 'letters') {
    return (
      <div
        className={`w-full h-full flex items-center justify-center rounded-full font-bold text-base select-none shadow-sm transition-transform ${
          isWhite
            ? 'bg-amber-50 text-stone-900 border-2 border-stone-800'
            : 'bg-stone-900 text-amber-50 border-2 border-amber-100'
        } ${className}`}
      >
        {type}
      </div>
    );
  }

  // Theme color maps
  let fill = isWhite ? '#fcfbf7' : '#22201e';
  let stroke = isWhite ? '#2c2925' : '#e6e2d8';
  let shadow = isWhite ? 'rgba(0,0,0,0.35)' : 'rgba(0,0,0,0.5)';

  if (theme === 'wood') {
    fill = isWhite ? '#fef3c7' : '#451a03';
    stroke = isWhite ? '#78350f' : '#fde68a';
    shadow = isWhite ? 'rgba(120,53,15,0.4)' : 'rgba(0,0,0,0.6)';
  } else if (theme === 'metallic') {
    fill = isWhite ? '#e2e8f0' : '#1e293b';
    stroke = isWhite ? '#334155' : '#94a3b8';
    shadow = isWhite ? 'rgba(51,65,85,0.4)' : 'rgba(0,0,0,0.6)';
  } else if (theme === 'neon') {
    fill = isWhite ? '#0891b2' : '#d97706';
    stroke = isWhite ? '#cffafe' : '#fef3c7';
    shadow = isWhite ? 'rgba(6,182,212,0.6)' : 'rgba(245,158,11,0.6)';
  }

  const strokeWidth = '2.8';

  return (
    <svg
      viewBox="0 0 100 100"
      className={`w-full h-full select-none overflow-visible ${className}`}
      style={{ filter: `drop-shadow(0 1px 2px ${shadow})` }}
    >
      <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
        {type === 'P' && (
          <>
            <circle cx="50" cy="27" r="13" />
            <polygon points="38,41 62,41 69,76 31,76" />
            <rect x="23" y="76" width="54" height="9" rx="3" />
          </>
        )}
        {type === 'R' && (
          <>
            <rect x="23" y="80" width="54" height="9" rx="3" />
            <polygon points="33,76 67,76 64,38 36,38" />
            <rect x="28" y="32" width="44" height="8" />
            <rect x="29" y="18" width="12" height="16" />
            <rect x="44" y="18" width="12" height="16" />
            <rect x="59" y="18" width="12" height="16" />
          </>
        )}
        {type === 'N' && (
          <>
            <rect x="23" y="80" width="54" height="9" rx="3" />
            <polygon points="70,78 66,60 71,50 61,44 68,35 57,30 62,21 51,17 45,24 40,19 25,27 17,35 24,41 19,47 30,49 27,58 34,66 30,78" />
            <circle cx="44" cy="32" r="3" fill="none" stroke={stroke} strokeWidth="2" />
          </>
        )}
        {type === 'B' && (
          <>
            <rect x="27" y="80" width="46" height="9" rx="3" />
            <ellipse cx="50" cy="77" rx="21" ry="7" />
            <path d="M50 18 C38 18 34 32 38 42 C30 50 28 63 32 78 L68 78 C72 63 70 50 62 42 C66 32 62 18 50 18 Z" />
            <ellipse cx="50" cy="52" rx="12" ry="3.5" />
            <line x1="43" y1="28" x2="55" y2="22" />
            <circle cx="50" cy="10" r="6" />
          </>
        )}
        {type === 'Q' && (
          <>
            <rect x="21" y="80" width="58" height="9" rx="3" />
            <path d="M29 78 Q27 55 35 41 L65 41 Q73 55 71 78 Z" />
            <ellipse cx="50" cy="41" rx="18" ry="4" />
            <rect x="25" y="34" width="50" height="9" rx="2" />
            <circle cx="27" cy="30" r="7" />
            <circle cx="41" cy="24" r="7" />
            <circle cx="50" cy="19" r="8" />
            <circle cx="59" cy="24" r="7" />
            <circle cx="73" cy="30" r="7" />
          </>
        )}
        {type === 'K' && (
          <>
            <rect x="21" y="80" width="58" height="9" rx="3" />
            <path d="M29 78 Q27 55 37 43 L63 43 Q73 55 71 78 Z" />
            <ellipse cx="50" cy="43" rx="17" ry="4" />
            <circle cx="50" cy="33" r="6" />
            <rect x="46.5" y="9" width="7" height="22" rx="1.5" />
            <rect x="39" y="15.5" width="22" height="7" rx="1.5" />
          </>
        )}
      </g>
    </svg>
  );
};
