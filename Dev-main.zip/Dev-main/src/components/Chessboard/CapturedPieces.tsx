import React from 'react';
import { PieceTheme, PieceStyle } from '../../types/chess';
import { ChessPieceSvg } from './ChessPieceSvg';

interface CapturedPiecesProps {
  pieces: string[]; // List of captured piece chars (e.g. ['p', 'p', 'n', 'b', 'r', 'q'])
  pieceTheme?: PieceTheme;
  pieceStyle?: PieceStyle;
  className?: string;
}

const PIECE_ORDER: Record<string, number> = {
  p: 1,
  n: 2,
  b: 3,
  r: 4,
  q: 5,
  k: 6,
  P: 1,
  N: 2,
  B: 3,
  R: 4,
  Q: 5,
  K: 6,
};

export const CapturedPieces: React.FC<CapturedPiecesProps> = ({
  pieces,
  pieceTheme = 'ivory',
  pieceStyle = 'svg',
  className = '',
}) => {
  if (!pieces || pieces.length === 0) {
    return <span className="text-[11px] text-stone-400 dark:text-stone-500 italic">None</span>;
  }

  // Sort pieces by standard chess value (Pawn -> Knight -> Bishop -> Rook -> Queen)
  const sorted = [...pieces].sort((a, b) => {
    const valA = PIECE_ORDER[a] || 0;
    const valB = PIECE_ORDER[b] || 0;
    return valA - valB;
  });

  return (
    <div className={`flex items-center flex-wrap gap-0.5 ${className}`}>
      {sorted.map((p, idx) => (
        <div
          key={`${p}-${idx}`}
          className="w-4 h-4 sm:w-4.5 sm:h-4.5 flex-shrink-0 transition-transform hover:scale-125"
          title={`Captured ${p.toUpperCase()}`}
        >
          <ChessPieceSvg piece={p} theme={pieceTheme} styleType={pieceStyle} />
        </div>
      ))}
    </div>
  );
};
