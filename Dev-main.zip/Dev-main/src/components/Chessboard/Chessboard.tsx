import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Square,
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  AnimationSpeed,
  DragRefreshRate,
  MoveClassification,
  UIThemeColor,
} from '../../types/chess';
import { fileOf, rankOf, sqOf, sqName, nameToSq, colorOf } from '../../engine/chessRules';
import { ChessPieceSvg } from './ChessPieceSvg';

export interface ArrowData {
  from: Square;
  to: Square;
  tier?: 'best' | 'second' | 'third' | 'user';
}

import { CLASSIFICATION_CONFIGS, ClassificationBadgeConfig } from '../../utils/classificationBadge';

export type { ClassificationBadgeConfig };
export const CLASSIFICATION_MAP = CLASSIFICATION_CONFIGS;

interface ChessboardProps {
  board?: (string | null)[];
  chess?: { board: (string | null)[] };
  orientation?: PieceColor;
  turn?: PieceColor;
  interactive?: boolean;
  canSelect?: (sq: Square) => boolean;
  getLegalTargets?: (sq: Square) => Square[];
  onMove?: (from: Square, to: Square, promotion?: string) => void;
  onSquareClick?: (sq: Square) => void;
  lastMove?: { from: Square; to: Square } | null;
  lastMoveClassification?: MoveClassification | null;
  checkSquare?: Square | null;
  hintSquare?: Square | null;
  engineArrows?: ArrowData[];
  arrows?: ArrowData[];
  boardTheme?: BoardTheme;
  pieceTheme?: PieceTheme;
  pieceStyle?: PieceStyle;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  dragRefreshRate?: DragRefreshRate;
  showCoordinates?: boolean;
  showLegalMoves?: boolean;
  showCheckHighlight?: boolean;
  showLastMoveHighlight?: boolean;
  dragAndDropEnabled?: boolean;
  autoQueenEnabled?: boolean;
  allowFreeDrag?: boolean;
  uiTheme?: UIThemeColor;
  className?: string;
}

export const Chessboard: React.FC<ChessboardProps> = ({
  board,
  chess,
  orientation = 'w',
  interactive = true,
  canSelect,
  getLegalTargets,
  onMove,
  onSquareClick,
  lastMove,
  lastMoveClassification,
  checkSquare,
  hintSquare,
  engineArrows = [],
  arrows = [],
  boardTheme = 'walnut',
  pieceTheme = 'ivory',
  pieceStyle = 'svg',
  animationEnabled = true,
  animationSpeed = 'normal',
  dragRefreshRate = '60fps',
  showCoordinates = true,
  showLegalMoves = true,
  showCheckHighlight = true,
  showLastMoveHighlight = true,
  dragAndDropEnabled = true,
  autoQueenEnabled = false,
  allowFreeDrag = false,
  className = '',
}) => {
  const activeBoard = board || chess?.board || [];
  const [selectedSq, setSelectedSq] = useState<Square | null>(null);
  const [legalTargets, setLegalTargets] = useState<Square[]>([]);
  const [userArrows, setUserArrows] = useState<ArrowData[]>([]);
  const [userCircles, setUserCircles] = useState<Square[]>([]);
  const [promoPending, setPromoPending] = useState<{ from: Square; to: Square; color: PieceColor } | null>(null);
  const [draggedSq, setDraggedSq] = useState<Square | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);

  // Animation state
  interface AnimMoveData {
    from: Square;
    to: Square;
    id: number;
    durationMs: number;
    isCastle?: boolean;
    rookFrom?: Square;
    rookTo?: Square;
  }
  const [animatingMove, setAnimatingMove] = useState<AnimMoveData | null>(null);
  const nextAnimIdRef = useRef<number>(1);
  const prevBoardRef = useRef<(string | null)[] | null>(null);
  const skipNextAnimForRef = useRef<string | null>(null);
  const animTimerRef = useRef<any>(null);

  const boardRef = useRef<HTMLDivElement>(null);
  const dragPosRef = useRef<{ x: number; y: number } | null>(null);
  const rightClickStartRef = useRef<Square | null>(null);
  const pointerStartRef = useRef<{ x: number; y: number; sq: Square; time: number } | null>(null);
  const isDraggingRef = useRef<boolean>(false);
  const justFinishedDragRef = useRef<boolean>(false);
  const rafIdRef = useRef<number | null>(null);

  const isWhiteOriented = orientation === 'w';

  // Coordinate transforms
  const rowColForSq = useCallback(
    (sq: Square) => {
      const file = fileOf(sq);
      const rank = rankOf(sq);
      return isWhiteOriented ? { row: 7 - rank, col: file } : { row: rank, col: 7 - file };
    },
    [isWhiteOriented]
  );

  const sqForRowCol = useCallback(
    (row: number, col: number): Square => {
      return isWhiteOriented ? sqOf(col, 7 - row) : sqOf(7 - col, row);
    },
    [isWhiteOriented]
  );

  // Normalize lastMove
  const normLastMove = React.useMemo(() => {
    if (!lastMove) return null;
    const from = typeof lastMove.from === 'string' ? nameToSq(lastMove.from) : lastMove.from;
    const to = typeof lastMove.to === 'string' ? nameToSq(lastMove.to) : lastMove.to;
    if (from === null || to === null || from < 0 || to < 0) return null;
    return { from: from as Square, to: to as Square };
  }, [lastMove?.from, lastMove?.to]);

  // Robust board diff-driven piece movement animation (handles forward, backward/undo, shuffle, and Chess960 castling)
  useEffect(() => {
    const prevBoard = prevBoardRef.current;
    prevBoardRef.current = [...activeBoard];

    if (!animationEnabled || animationSpeed === 'instant') {
      if (animTimerRef.current) {
        clearTimeout(animTimerRef.current);
        animTimerRef.current = null;
      }
      setAnimatingMove(null);
      return;
    }

    if (!prevBoard) {
      return;
    }

    // Cancel / bypass move animation if the piece was physically moved by dragging
    if (skipNextAnimForRef.current) {
      skipNextAnimForRef.current = null;
      if (animTimerRef.current) {
        clearTimeout(animTimerRef.current);
        animTimerRef.current = null;
      }
      setAnimatingMove(null);
      return;
    }

    // Find changed squares
    const changedSq: Square[] = [];
    for (let i = 0; i < 64; i++) {
      if (prevBoard[i] !== activeBoard[i]) {
        changedSq.push(i as Square);
      }
    }

    if (changedSq.length === 0) {
      return;
    }

    // If more than 4 squares changed (full reset, loaded FEN, multi-move jump), don't animate
    if (changedSq.length > 4) {
      if (animTimerRef.current) {
        clearTimeout(animTimerRef.current);
        animTimerRef.current = null;
      }
      setAnimatingMove(null);
      return;
    }

    let animData: {
      from: Square;
      to: Square;
      isCastle?: boolean;
      rookFrom?: Square;
      rookTo?: Square;
    } | null = null;

    // Detect White Castling (Forward or Backward)
    const wKingPrev = prevBoard.findIndex((p, idx) => p === 'K' && rankOf(idx) === 0);
    const wKingCurr = activeBoard.findIndex((p, idx) => p === 'K' && rankOf(idx) === 0);
    if (wKingPrev !== -1 && wKingCurr !== -1 && wKingPrev !== wKingCurr) {
      const kFrom = wKingPrev as Square;
      const kTo = wKingCurr as Square;
      const rFromCandidates = changedSq.filter(
        (s) => rankOf(s) === 0 && s !== kFrom && s !== kTo && prevBoard[s] === 'R'
      );
      const rToCandidates = changedSq.filter(
        (s) => rankOf(s) === 0 && s !== kFrom && s !== kTo && activeBoard[s] === 'R'
      );
      if (rFromCandidates.length > 0 || rToCandidates.length > 0) {
        const isKingside = fileOf(kTo) === 6 || fileOf(kTo) > fileOf(kFrom);
        const rFrom = rFromCandidates[0] ?? (isKingside ? sqOf(7, 0) : sqOf(0, 0));
        const rTo = rToCandidates[0] ?? (isKingside ? sqOf(5, 0) : sqOf(3, 0));
        animData = { from: kFrom, to: kTo, isCastle: true, rookFrom: rFrom, rookTo: rTo };
      }
    }

    // Detect Black Castling (Forward or Backward)
    const bKingPrev = prevBoard.findIndex((p, idx) => p === 'k' && rankOf(idx) === 7);
    const bKingCurr = activeBoard.findIndex((p, idx) => p === 'k' && rankOf(idx) === 7);
    if (!animData && bKingPrev !== -1 && bKingCurr !== -1 && bKingPrev !== bKingCurr) {
      const kFrom = bKingPrev as Square;
      const kTo = bKingCurr as Square;
      const rFromCandidates = changedSq.filter(
        (s) => rankOf(s) === 7 && s !== kFrom && s !== kTo && prevBoard[s] === 'r'
      );
      const rToCandidates = changedSq.filter(
        (s) => rankOf(s) === 7 && s !== kFrom && s !== kTo && activeBoard[s] === 'r'
      );
      if (rFromCandidates.length > 0 || rToCandidates.length > 0) {
        const isKingside = fileOf(kTo) === 6 || fileOf(kTo) > fileOf(kFrom);
        const rFrom = rFromCandidates[0] ?? (isKingside ? sqOf(7, 7) : sqOf(0, 7));
        const rTo = rToCandidates[0] ?? (isKingside ? sqOf(5, 7) : sqOf(3, 7));
        animData = { from: kFrom, to: kTo, isCastle: true, rookFrom: rFrom, rookTo: rTo };
      }
    }

    // Standard moves / Captures / En Passant / Promotion / Undo
    if (!animData) {
      if (normLastMove && changedSq.includes(normLastMove.from) && changedSq.includes(normLastMove.to)) {
        animData = { from: normLastMove.from, to: normLastMove.to };
      } else {
        let fSrc: Square | null = null;
        let fDst: Square | null = null;
        let bSrc: Square | null = null;
        let bDst: Square | null = null;

        for (const sq of changedSq) {
          const pPrev = prevBoard[sq];
          const pCurr = activeBoard[sq];
          if (pPrev && !pCurr) {
            fSrc = sq;
            bDst = sq;
          } else if (!pPrev && pCurr) {
            fDst = sq;
            bSrc = sq;
          } else if (pPrev && pCurr && pPrev !== pCurr) {
            fDst = sq;
            bSrc = sq;
          }
        }

        if (fSrc !== null && fDst !== null) {
          const pieceAtSrc = prevBoard[fSrc];
          const pieceAtDst = activeBoard[fDst];
          if (
            pieceAtSrc === pieceAtDst ||
            (pieceAtSrc?.toUpperCase() === 'P' && 'QRBNqrbn'.includes(pieceAtDst || ''))
          ) {
            animData = { from: fSrc, to: fDst };
          } else if (bSrc !== null && bDst !== null) {
            animData = { from: bSrc, to: bDst };
          }
        }
      }
    }

    if (!animData || animData.from === animData.to) {
      return;
    }

    const durationMs =
      animationSpeed === 'fast' ? 120 : animationSpeed === 'slow' ? 320 : 200;

    const animId = nextAnimIdRef.current++;
    if (animTimerRef.current) {
      clearTimeout(animTimerRef.current);
      animTimerRef.current = null;
    }

    setAnimatingMove({
      from: animData.from,
      to: animData.to,
      id: animId,
      durationMs,
      isCastle: animData.isCastle,
      rookFrom: animData.rookFrom,
      rookTo: animData.rookTo,
    });

    animTimerRef.current = setTimeout(() => {
      setAnimatingMove((curr) => (curr && curr.id === animId ? null : curr));
    }, durationMs + 20);

    return () => {
      if (animTimerRef.current) {
        clearTimeout(animTimerRef.current);
      }
    };
  }, [activeBoard, normLastMove, animationEnabled, animationSpeed]);

  // Extract square accurately from pointer/touch coordinate with edge-clamping
  const getSqFromEvent = useCallback(
    (e?: React.MouseEvent | React.TouchEvent | MouseEvent | TouchEvent): Square | null => {
      if (!boardRef.current) return null;
      const rect = boardRef.current.getBoundingClientRect();
      let clientX = -1;
      let clientY = -1;

      if (e) {
        if ('touches' in e && e.touches && e.touches.length > 0) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
        } else if ('changedTouches' in e && e.changedTouches && e.changedTouches.length > 0) {
          clientX = e.changedTouches[0].clientX;
          clientY = e.changedTouches[0].clientY;
        } else if ('clientX' in e && typeof (e as MouseEvent).clientX === 'number') {
          clientX = (e as MouseEvent).clientX;
          clientY = (e as MouseEvent).clientY;
        }
      }

      if (clientX < 0 || clientY < 0) {
        if (dragPosRef.current) {
          clientX = dragPosRef.current.x;
          clientY = dragPosRef.current.y;
        }
      }

      if (clientX < 0 || clientY < 0) return null;

      // Allow a generous tolerance margin (32px) around the board edges for reliable dropping
      const margin = 32;
      if (
        clientX < rect.left - margin ||
        clientX > rect.right + margin ||
        clientY < rect.top - margin ||
        clientY > rect.bottom + margin
      ) {
        return null;
      }

      const clampedX = Math.max(0, Math.min(rect.width - 1, clientX - rect.left));
      const clampedY = Math.max(0, Math.min(rect.height - 1, clientY - rect.top));

      const col = Math.min(7, Math.max(0, Math.floor((clampedX / rect.width) * 8)));
      const row = Math.min(7, Math.max(0, Math.floor((clampedY / rect.height) * 8)));
      return sqForRowCol(row, col);
    },
    [sqForRowCol]
  );

  const clearSelection = useCallback(() => {
    setSelectedSq(null);
    setLegalTargets([]);
  }, []);

  const handleSquareClick = useCallback(
    (sq: Square) => {
      if (!interactive) return;
      if (justFinishedDragRef.current) {
        justFinishedDragRef.current = false;
        return;
      }

      // Clear any ongoing animation on interaction
      if (animTimerRef.current) {
        clearTimeout(animTimerRef.current);
        animTimerRef.current = null;
      }
      if (animatingMove !== null) {
        setAnimatingMove(null);
      }

      if (onSquareClick) onSquareClick(sq);

      // If clicking on the currently selected square again, cancel/clear selection and legal moves
      if (selectedSq !== null && sq === selectedSq) {
        clearSelection();
        return;
      }

      // If we already have a square selected, check if clicked square is a legal destination
      if (selectedSq !== null) {
        const isTargetLegal = allowFreeDrag || !getLegalTargets || legalTargets.includes(sq);
        if (isTargetLegal && sq !== selectedSq) {
          const piece = activeBoard[selectedSq];
          const isPawnPromo =
            piece &&
            piece.toUpperCase() === 'P' &&
            ((piece === 'P' && rankOf(sq) === 7) || (piece === 'p' && rankOf(sq) === 0));

          if (isPawnPromo) {
            if (autoQueenEnabled) {
              if (onMove) onMove(selectedSq, sq, 'Q');
              clearSelection();
              return;
            }
            setPromoPending({
              from: selectedSq,
              to: sq,
              color: piece === 'P' ? 'w' : 'b',
            });
            clearSelection();
            return;
          }

          if (onMove) onMove(selectedSq, sq);
          clearSelection();
          return;
        }
      }

      // Check if clicked square can be selected
      if (activeBoard[sq] && (!canSelect || canSelect(sq))) {
        setSelectedSq(sq);
        const targets = getLegalTargets ? getLegalTargets(sq) : [];
        setLegalTargets(targets);
      } else {
        clearSelection();
      }
    },
    [
      interactive,
      animatingMove,
      selectedSq,
      legalTargets,
      activeBoard,
      canSelect,
      getLegalTargets,
      onMove,
      onSquareClick,
      clearSelection,
      autoQueenEnabled,
      allowFreeDrag,
    ]
  );

  // Begin Pointer/Touch Press
  const handlePointerDownPiece = (
    e: React.MouseEvent | React.TouchEvent,
    sq: Square
  ) => {
    if (!interactive) return;
    if (e.type === 'mousedown' && (e as React.MouseEvent).button !== 0) return;

    if (animTimerRef.current) {
      clearTimeout(animTimerRef.current);
      animTimerRef.current = null;
    }
    if (animatingMove !== null) {
      setAnimatingMove(null);
    }

    let clientX = 0;
    let clientY = 0;
    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    pointerStartRef.current = {
      x: clientX,
      y: clientY,
      sq,
      time: Date.now(),
    };
    isDraggingRef.current = false;
  };

  // Window global listeners for butter-smooth touch & mouse dragging
  useEffect(() => {
    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      let clientX = -1;
      let clientY = -1;
      if ('touches' in e && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if ('changedTouches' in e && e.changedTouches.length > 0) {
        clientX = e.changedTouches[0].clientX;
        clientY = e.changedTouches[0].clientY;
      } else if ('clientX' in e) {
        clientX = (e as MouseEvent).clientX;
        clientY = (e as MouseEvent).clientY;
      }

      if (clientX < 0 || clientY < 0) return;

      if (pointerStartRef.current) {
        const dist = Math.hypot(
          clientX - pointerStartRef.current.x,
          clientY - pointerStartRef.current.y
        );

        if (dist > 8 && !isDraggingRef.current && dragAndDropEnabled) {
          const sq = pointerStartRef.current.sq;
          const piece = activeBoard[sq];
          const canPick = piece && (!canSelect || canSelect(sq));

          if (canPick) {
            isDraggingRef.current = true;
            setDraggedSq(sq);
            setSelectedSq(sq);
            const targets = getLegalTargets ? getLegalTargets(sq) : [];
            setLegalTargets(targets);
            const pos = { x: clientX, y: clientY };
            dragPosRef.current = pos;
            setDragPos(pos);
          }
        }
      }

      if (isDraggingRef.current) {
        const pt = { x: clientX, y: clientY };
        dragPosRef.current = pt;
        setDragPos(pt);

        if ('touches' in e && e.cancelable) {
          e.preventDefault();
        }
      }
    };

    const handlePointerUp = (e: MouseEvent | TouchEvent) => {
      if (isDraggingRef.current && draggedSq !== null) {
        justFinishedDragRef.current = true;
        setTimeout(() => {
          justFinishedDragRef.current = false;
        }, 120);

        const destSq = getSqFromEvent(e);
        const isDestAllowed =
          destSq !== null &&
          destSq !== draggedSq &&
          (allowFreeDrag || !getLegalTargets || legalTargets.includes(destSq));

        if (isDestAllowed && destSq !== null) {
          const piece = activeBoard[draggedSq];
          const isPawnPromo =
            piece &&
            piece.toUpperCase() === 'P' &&
            ((piece === 'P' && rankOf(destSq) === 7) || (piece === 'p' && rankOf(destSq) === 0));

          skipNextAnimForRef.current = `${draggedSq}->${destSq}`;

          if (isPawnPromo) {
            if (autoQueenEnabled) {
              if (onMove) onMove(draggedSq, destSq, 'Q');
            } else {
              setPromoPending({
                from: draggedSq,
                to: destSq,
                color: piece === 'P' ? 'w' : 'b',
              });
            }
          } else {
            if (onMove) onMove(draggedSq, destSq);
          }
          clearSelection();
        }
      }

      pointerStartRef.current = null;
      isDraggingRef.current = false;
      setDraggedSq(null);
      setDragPos(null);
      dragPosRef.current = null;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: false });
    window.addEventListener('mouseup', handlePointerUp);
    window.addEventListener('touchend', handlePointerUp);
    window.addEventListener('touchcancel', handlePointerUp);

    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchend', handlePointerUp);
      window.removeEventListener('touchcancel', handlePointerUp);
    };
  }, [
    dragAndDropEnabled,
    draggedSq,
    legalTargets,
    activeBoard,
    getSqFromEvent,
    onMove,
    clearSelection,
    autoQueenEnabled,
    allowFreeDrag,
    getLegalTargets,
    canSelect,
  ]);

  // Promotion choice execution
  const executePromotion = (promoPiece: string) => {
    if (!promoPending) return;
    if (onMove) onMove(promoPending.from, promoPending.to, promoPiece);
    setPromoPending(null);
  };

  // Right-click user drawing (arrows and circles)
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 2) {
      const sq = getSqFromEvent(e);
      if (sq !== null) {
        rightClickStartRef.current = sq;
      }
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (e.button === 2 && rightClickStartRef.current !== null) {
      const startSq = rightClickStartRef.current;
      const endSq = getSqFromEvent(e);
      rightClickStartRef.current = null;

      if (endSq === null) return;

      if (startSq === endSq) {
        setUserCircles((prev) =>
          prev.includes(startSq) ? prev.filter((s) => s !== startSq) : [...prev, startSq]
        );
      } else {
        setUserArrows((prev) => {
          const exists = prev.some((a) => a.from === startSq && a.to === endSq);
          if (exists) {
            return prev.filter((a) => !(a.from === startSq && a.to === endSq));
          }
          return [...prev, { from: startSq, to: endSq, tier: 'user' }];
        });
      }
    }
  };

  const handleBoardClick = (e: React.MouseEvent) => {
    if (e.button === 0 && (userArrows.length > 0 || userCircles.length > 0)) {
      setUserArrows([]);
      setUserCircles([]);
    }
  };

  const themeColors: Record<BoardTheme, { light: string; dark: string }> = {
    walnut: { light: '#ede1cf', dark: '#b58863' },
    tournament: { light: '#ffffdd', dark: '#86a666' },
    azure: { light: '#dee3e6', dark: '#8ca2ad' },
    coral: { light: '#f0d9b5', dark: '#b58863' },
    graphite: { light: '#e2e8f0', dark: '#64748b' },
    midnight: { light: '#334155', dark: '#0f172a' },
  };

  const currentTheme = themeColors[boardTheme] || themeColors.walnut;

  // Arrow calculations
  const allArrows = [...engineArrows, ...arrows, ...userArrows];
  const centerPercent = (sq: Square) => {
    const { row, col } = rowColForSq(sq);
    return { x: (col + 0.5) * 12.5, y: (row + 0.5) * 12.5 };
  };

  const pieceBoxSize = boardRef.current ? boardRef.current.clientWidth / 8 : 64;
  const durationMs =
    animationSpeed === 'fast' ? 140 : animationSpeed === 'slow' ? 380 : 230;

  return (
    <div
      id="chessboard-container"
      className={`relative w-full aspect-square max-w-[640px] rounded-xl overflow-hidden shadow-2xl border-2 border-stone-800/40 select-none touch-none ${className}`}
      onContextMenu={handleContextMenu}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onClick={handleBoardClick}
    >
      {/* Dynamic Keyframes for smooth hardware-accelerated piece slide */}
      <style>{`
        @keyframes pieceGlideAnim {
          0% {
            transform: translate3d(var(--slide-x, 0%), var(--slide-y, 0%), 0);
          }
          100% {
            transform: translate3d(0%, 0%, 0);
          }
        }
        .piece-gliding {
          animation: pieceGlideAnim var(--anim-duration, 230ms) cubic-bezier(0.2, 0.9, 0.3, 1) both;
          will-change: transform;
        }
      `}</style>

      {/* 8x8 Grid */}
      <div
        ref={boardRef}
        className="absolute inset-0 grid grid-cols-8 grid-rows-8 touch-none"
        role="grid"
        aria-label="Chessboard"
      >
        {Array.from({ length: 64 }).map((_, idx) => {
          const row = Math.floor(idx / 8);
          const col = idx % 8;
          const sq = sqForRowCol(row, col);
          const isLight = (row + col) % 2 === 0;
          const piece = activeBoard[sq];

          const isSelected = selectedSq === sq;
          const isLastMove = normLastMove && (normLastMove.from === sq || normLastMove.to === sq);
          const isLastMoveDest = normLastMove && normLastMove.to === sq;
          const isCheck = checkSquare === sq;
          const isHint = hintSquare === sq;
          const isLegalTarget = legalTargets.includes(sq);
          const hasUserCircle = userCircles.includes(sq);

          // Classification Badge
          const activeClassification =
            isLastMoveDest && lastMoveClassification ? lastMoveClassification : null;
          const classificationCfg = activeClassification ? CLASSIFICATION_MAP[activeClassification] : null;

          const file = fileOf(sq);
          const rank = rankOf(sq);
          const showFileCoord = row === 7 && showCoordinates;
          const showRankCoord = col === 0 && showCoordinates;

          // Animation glide calculation for primary piece or castling rook
          const isPrimaryAnim =
            animationEnabled &&
            animationSpeed !== 'instant' &&
            animatingMove !== null &&
            animatingMove.to === sq &&
            draggedSq === null;

          const isCastleRookAnim =
            animationEnabled &&
            animationSpeed !== 'instant' &&
            animatingMove !== null &&
            animatingMove.isCastle &&
            animatingMove.rookTo === sq &&
            draggedSq === null;

          const isBeingDragged = draggedSq === sq;

          let animStyle: React.CSSProperties | undefined;
          if (isPrimaryAnim && animatingMove) {
            const fromRC = rowColForSq(animatingMove.from);
            const toRC = rowColForSq(animatingMove.to);
            const dx = (fromRC.col - toRC.col) * 100;
            const dy = (fromRC.row - toRC.row) * 100;
            const itemDuration = animatingMove.durationMs || durationMs;
            animStyle = {
              '--slide-x': `${dx}%`,
              '--slide-y': `${dy}%`,
              '--anim-duration': `${itemDuration}ms`,
            } as React.CSSProperties;
          } else if (isCastleRookAnim && animatingMove && animatingMove.rookFrom !== undefined) {
            const fromRC = rowColForSq(animatingMove.rookFrom);
            const toRC = rowColForSq(animatingMove.rookTo!);
            const dx = (fromRC.col - toRC.col) * 100;
            const dy = (fromRC.row - toRC.row) * 100;
            const itemDuration = animatingMove.durationMs || durationMs;
            animStyle = {
              '--slide-x': `${dx}%`,
              '--slide-y': `${dy}%`,
              '--anim-duration': `${itemDuration}ms`,
            } as React.CSSProperties;
          }

          const isGliding = isPrimaryAnim || isCastleRookAnim;

          return (
            <div
              key={`sq-${sq}`}
              id={`sq-${sqName(sq)}`}
              data-sq={sq}
              data-san={sqName(sq)}
              onClick={() => handleSquareClick(sq)}
              onMouseDown={(e) => {
                if (piece && (!canSelect || canSelect(sq))) {
                  handlePointerDownPiece(e, sq);
                }
              }}
              onTouchStart={(e) => {
                if (piece && (!canSelect || canSelect(sq))) {
                  handlePointerDownPiece(e, sq);
                }
              }}
              className="relative flex items-center justify-center cursor-pointer transition-colors duration-75 touch-none select-none"
              style={{
                backgroundColor: isLight ? currentTheme.light : currentTheme.dark,
              }}
            >
              {/* Highlight Layers */}
              {isSelected && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{ backgroundColor: 'var(--theme-square-select, rgba(245, 158, 11, 0.45))' }}
                />
              )}
              {isHint && !isSelected && (
                <div
                  className="absolute inset-0 ring-4 pointer-events-none z-10 rounded-xs animate-pulse"
                  style={{
                    backgroundColor: 'var(--theme-square-select, rgba(245, 158, 11, 0.35))',
                    borderColor: 'var(--theme-primary, #f59e0b)',
                  }}
                />
              )}
              {showLastMoveHighlight && isLastMove && !isSelected && !isHint && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{ backgroundColor: 'var(--theme-square-last, rgba(245, 158, 11, 0.22))' }}
                />
              )}
              {showCheckHighlight && isCheck && (
                <div className="absolute inset-0 bg-radial from-red-600/75 to-transparent pointer-events-none animate-pulse" />
              )}
              {hasUserCircle && (
                <div className="absolute inset-1 rounded-full border-4 border-emerald-400/80 pointer-events-none" />
              )}

              {/* Legal Move Indicators */}
              {showLegalMoves && isLegalTarget && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                  {piece ? (
                    <div className="w-[82%] h-[82%] rounded-full border-4 border-stone-900/35 dark:border-white/40" />
                  ) : (
                    <div className="w-[30%] h-[30%] rounded-full bg-stone-900/30 dark:border-white/35" />
                  )}
                </div>
              )}

              {/* Coordinates */}
              {showFileCoord && (
                <span
                  className={`absolute right-1 bottom-0.5 text-[10px] font-mono font-bold select-none pointer-events-none ${
                    isLight ? 'text-stone-700/60' : 'text-amber-100/70'
                  }`}
                >
                  {'abcdefgh'[file]}
                </span>
              )}
              {showRankCoord && (
                <span
                  className={`absolute left-1 top-0.5 text-[10px] font-mono font-bold select-none pointer-events-none ${
                    isLight ? 'text-stone-700/60' : 'text-amber-100/70'
                  }`}
                >
                  {rank + 1}
                </span>
              )}

              {/* Piece Rendering */}
              {piece && (
                <div
                  key={isGliding && animatingMove ? `sq-piece-${sq}-anim-${animatingMove.id}` : `sq-piece-${sq}`}
                  style={animStyle}
                  onAnimationEnd={() => {
                    if (isGliding && animatingMove) {
                      setAnimatingMove((curr) => (curr && curr.id === animatingMove.id ? null : curr));
                    }
                  }}
                  className={`w-full h-full p-[6%] select-none touch-none ${
                    isBeingDragged
                      ? 'opacity-20 scale-95 z-10'
                      : isGliding
                      ? 'piece-gliding pointer-events-none z-30'
                      : 'hover:scale-[1.03] active:scale-[0.98] transition-transform duration-100 z-10'
                  }`}
                >
                  <ChessPieceSvg piece={piece} styleType={pieceStyle} theme={pieceTheme} />
                </div>
              )}

              {/* Move Classification Badge */}
              {classificationCfg && (
                <div
                  className={`absolute -top-1 -right-1 sm:-top-1.5 sm:-right-1.5 z-30 flex items-center justify-center w-5 h-5 sm:w-6 sm:h-6 rounded-full shadow-md border-2 border-white dark:border-stone-900 ring-1 ${classificationCfg.ringClass} ${classificationCfg.bgClass} ${classificationCfg.textClass} select-none pointer-events-none animate-in zoom-in-75 duration-150`}
                  title={classificationCfg.label}
                >
                  {classificationCfg.iconType === 'book' ? (
                    <span className="text-[10px] sm:text-[11px] leading-none">📖</span>
                  ) : (
                    <span className="font-sans font-black text-[10px] sm:text-xs leading-none tracking-tighter">
                      {classificationCfg.badgeText}
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* SVG Vector Arrow Overlays */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none z-20"
        viewBox="0 0 100 100"
      >
        <defs>
          <marker
            id="arrowhead-best"
            markerWidth="3.2"
            markerHeight="3.2"
            refX="1.6"
            refY="1.6"
            orient="auto"
          >
            <polygon points="0,0 3.2,1.6 0,3.2" fill="var(--theme-primary, #d97706)" />
          </marker>
          <marker
            id="arrowhead-second"
            markerWidth="3.2"
            markerHeight="3.2"
            refX="1.6"
            refY="1.6"
            orient="auto"
          >
            <polygon points="0,0 3.2,1.6 0,3.2" fill="#3b82f6" />
          </marker>
          <marker
            id="arrowhead-user"
            markerWidth="3.2"
            markerHeight="3.2"
            refX="1.6"
            refY="1.6"
            orient="auto"
          >
            <polygon points="0,0 3.2,1.6 0,3.2" fill="#10b981" />
          </marker>
        </defs>

        {allArrows.map((arrow, idx) => {
          const fromPt = centerPercent(arrow.from);
          const toPt = centerPercent(arrow.to);
          const dx = toPt.x - fromPt.x;
          const dy = toPt.y - fromPt.y;
          const len = Math.hypot(dx, dy) || 1;
          const shrink = 5.2;
          const ex = toPt.x - (dx / len) * shrink;
          const ey = toPt.y - (dy / len) * shrink;

          const tier = arrow.tier || 'best';
          const strokeColor =
            tier === 'best' ? 'var(--theme-primary, #d97706)' : tier === 'second' ? '#3b82f6' : '#10b981';
          const markerId = `url(#arrowhead-${tier === 'best' ? 'best' : tier === 'second' ? 'second' : 'user'})`;

          return (
            <line
              key={`arrow-${idx}-${arrow.from}-${arrow.to}`}
              x1={fromPt.x}
              y1={fromPt.y}
              x2={ex}
              y2={ey}
              stroke={strokeColor}
              strokeWidth="2.8"
              strokeLinecap="round"
              opacity={tier === 'best' ? 0.95 : 0.75}
              markerEnd={markerId}
            />
          );
        })}
      </svg>

      {/* Floating Dragged Piece positioned directly centered under the pointer/finger */}
      {draggedSq !== null && dragPos !== null && activeBoard[draggedSq] && (
        <div
          className="fixed pointer-events-none z-[999] select-none touch-none will-change-transform"
          style={{
            transform: `translate3d(${dragPos.x - pieceBoxSize / 2}px, ${dragPos.y - pieceBoxSize / 2}px, 0) scale(1.12)`,
            top: 0,
            left: 0,
            width: `${pieceBoxSize}px`,
            height: `${pieceBoxSize}px`,
            filter: 'drop-shadow(0 12px 20px rgba(0, 0, 0, 0.45))',
          }}
        >
          <ChessPieceSvg piece={activeBoard[draggedSq]!} styleType={pieceStyle} theme={pieceTheme} />
        </div>
      )}

      {/* Promotion Choice Dialog */}
      {promoPending && (
        <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-stone-900 border border-stone-700 p-4 rounded-2xl shadow-2xl flex flex-col items-center gap-3">
            <span className="text-xs uppercase tracking-wider font-bold text-stone-300">
              Promote Pawn To
            </span>
            <div className="flex gap-2">
              {[
                { type: 'Q', label: 'Queen' },
                { type: 'R', label: 'Rook' },
                { type: 'B', label: 'Bishop' },
                { type: 'N', label: 'Knight' },
              ].map(({ type, label }) => {
                const pc = promoPending.color === 'w' ? type : type.toLowerCase();
                return (
                  <button
                    key={type}
                    id={`promo-btn-${type}`}
                    onClick={() => executePromotion(type)}
                    className="flex flex-col items-center justify-center p-2 w-16 h-16 rounded-xl bg-stone-800 hover:bg-stone-700/80 border border-stone-700 hover:border-stone-500 transition-all group cursor-pointer"
                  >
                    <div className="w-10 h-10 group-hover:scale-110 transition-transform">
                      <ChessPieceSvg piece={pc} styleType={pieceStyle} theme={pieceTheme} />
                    </div>
                    <span className="text-[10px] font-semibold text-stone-300 group-hover:text-white">
                      {label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
