import React, { useMemo } from 'react';
import { BoardTheme, PieceTheme, PieceStyle, PieceColor, Square } from '../../types/chess';
import { sqOf } from '../../engine/chessRules';
import { GameTree } from '../../engine/gameTree';
import { ChessPieceSvg } from './ChessPieceSvg';

interface MiniBoardProps {
  tokens?: string[];
  fen?: string;
  boardTheme?: BoardTheme;
  pieceTheme?: PieceTheme;
  pieceStyle?: PieceStyle;
  orientation?: PieceColor;
  className?: string;
}

const themeColors: Record<BoardTheme, { light: string; dark: string }> = {
  walnut: { light: '#f0d9b5', dark: '#b58863' },
  tournament: { light: '#eeeed2', dark: '#769656' },
  azure: { light: '#e8edf9', dark: '#6085a8' },
  coral: { light: '#f4e7dc', dark: '#b86b53' },
  graphite: { light: '#4b5563', dark: '#1f2937' },
  midnight: { light: '#2d3748', dark: '#1a202c' },
};

export const MiniBoard: React.FC<MiniBoardProps> = ({
  tokens,
  fen,
  boardTheme = 'walnut',
  pieceTheme = 'ivory',
  pieceStyle = 'svg',
  orientation = 'w',
  className = '',
}) => {
  const board = useMemo(() => {
    const tree = new GameTree(fen || undefined);
    if (tokens && tokens.length > 0) {
      for (const san of tokens) {
        try {
          tree.playSAN(san);
        } catch {
          break;
        }
      }
    }
    return tree.chess.board;
  }, [tokens, fen]);

  const currentTheme = themeColors[boardTheme] || themeColors.walnut;
  const isWhite = orientation === 'w';

  const rows = [0, 1, 2, 3, 4, 5, 6, 7];
  const cols = [0, 1, 2, 3, 4, 5, 6, 7];

  return (
    <div
      className={`aspect-square rounded-lg overflow-hidden border border-stone-300 dark:border-stone-700 select-none shadow-xs shrink-0 ${className}`}
    >
      <div className="grid grid-cols-8 grid-rows-8 w-full h-full">
        {rows.map((r) =>
          cols.map((c) => {
            const row = isWhite ? r : 7 - r;
            const col = isWhite ? c : 7 - c;
            const rank = 7 - row;
            const file = col;
            const sq: Square = sqOf(file, rank);
            const isLight = (file + rank) % 2 !== 0;
            const piece = board[sq];

            return (
              <div
                key={`${r}-${c}`}
                className="w-full h-full flex items-center justify-center relative"
                style={{ backgroundColor: isLight ? currentTheme.light : currentTheme.dark }}
              >
                {piece && (
                  <div className="w-[88%] h-[88%] flex items-center justify-center pointer-events-none">
                    <ChessPieceSvg
                      piece={piece}
                      styleType={pieceStyle}
                      theme={pieceTheme}
                    />
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
