import { OpeningVariation, OpeningChapter, PieceColor } from '../../types/chess';

export type ViewLevel = 'catalog' | 'variation_select' | 'study_workbench';
export type TabMode = 'overview' | 'study' | 'test';
export type CatalogFilter = 'all' | 'studied' | 'unstudied';

export interface OpeningMeta {
  difficulty: 'Easy' | 'Medium' | 'Hard';
  originSide: PieceColor;
  pawnStructure: string;
  keyPlans: string[];
}

export function getOpeningMetadata(opName: string, category?: string, trainColor?: PieceColor): OpeningMeta {
  const name = opName.toLowerCase();
  const isBlackStudy = trainColor === 'b';

  if (name.includes('london')) {
    return {
      difficulty: 'Easy',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Black challenges White’s d4-e3-c3 pyramid with ...c5 and ...d5'
        : 'Solid d4-e3-c3 Pawn Pyramid (The London Triangle)',
      keyPlans: isBlackStudy
        ? [
            'Challenge the center early with ...c5, targeting White’s d4 anchor.',
            'Put queenside pressure on b2 with ...Qb6 and develop knights actively.',
            'Contest White’s e5 outpost with ...Nf6, ...e6, and ...Bd6.',
          ]
        : [
            'Establish firm control over the central e5 outpost with Ne5 and Nd2.',
            'Develop dark-squared bishop outside the pawn chain to Bf4 before playing e3.',
            'Launch kingside assault with Qf3, Bd3, and kingside knight centralization.',
          ],
    };
  }
  if (name.includes('italian')) {
    return {
      difficulty: 'Easy',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Black maintains classical e5 central balance against White’s c3-d4 thrust'
        : 'Classical Open Center (e4 vs e5 with c3-d4 thrust)',
      keyPlans: isBlackStudy
        ? [
            'Neutralize White’s Bc4 attacking f7 with solid development (...Bc5 or ...Nf6).',
            'Counter-strike in the center with ...d5 or pin White’s knight with ...Bg4.',
            'Maintain dynamic symmetry and castle early for king safety.',
          ]
        : [
            'Target Black’s vulnerable f7 pawn with Bc4 and Ng5 or d3/c3 setups.',
            'Prepare the c3 and d4 central strike in the Giuoco Piano.',
            'Quick kingside castling and piece coordination for central domination.',
          ],
    };
  }
  if (name.includes('scandinavian')) {
    return {
      difficulty: 'Easy',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Asymmetrical Center after 1...d5 and exd5 Qxd5/Nf6'
        : 'White exploits rapid development against Black’s early queen excursions',
      keyPlans: isBlackStudy
        ? [
            'Eliminate White’s central e4 pawn immediately on move one.',
            'Develop light-squared bishop actively to Bf5 or Bg4 before playing ...e6.',
            'Castle queenside with ...O-O-O for rapid tactical central counterplay.',
          ]
        : [
            'Gain free tempi developing minor pieces (Nc3) attacking Black’s queen.',
            'Seize the full pawn center with d4 and active bishop placement.',
            'Launch a direct kingside or queenside attack before Black consolidates.',
          ],
    };
  }
  if (name.includes('scotch') || name.includes('four knights')) {
    return {
      difficulty: 'Easy',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Dynamic central piece play following open d-file / e-file trades'
        : 'Open Central Files (d-file and e-file opened)',
      keyPlans: isBlackStudy
        ? [
            'Develop pieces actively to Bc5 and Nf6 to punish White’s premature trades.',
            'Maintain equal central influence and castle quickly.',
            'Exploit tactical vulnerabilities in White’s extended center.',
          ]
        : [
            'Open the center immediately with early d4 strike.',
            'Rapid piece mobilization and active knight play in the center.',
            'Create active tactical lines against Black’s king.',
          ],
    };
  }
  if (name.includes('sicilian')) {
    return {
      difficulty: 'Hard',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Asymmetric d6/e7 vs e4 Pawn Center with semi-open c-file for Black'
        : 'White open center with central space advantage and kingside attacking lines',
      keyPlans: isBlackStudy
        ? [
            'Trade flank c5 pawn for White\'s central d4 pawn to secure central superiority.',
            'Apply heavy queenside pressure along the half-open c-file with rooks and queens.',
            'Execute the timely ...d5 central break or ...b5 queenside expansion.',
          ]
        : [
            'Blast the center open with 2.Nf3 and 3.d4 for fast piece development.',
            'Castle queenside and launch kingside pawn storms (f3, g4, h4 in English Attack).',
            'Dominate the d5 central outpost with pieces before Black expands.',
          ],
    };
  }
  if (name.includes('ruy lopez')) {
    return {
      difficulty: 'Hard',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Solid Black structure after ...a6, ...b5, ...d6 controlling queenside'
        : 'Closed Spanish Center with d3/d4 and c3 support',
      keyPlans: isBlackStudy
        ? [
            'Repel White’s bishop with ...a6 and ...b5, then coordinate pieces comfortably.',
            'Solidify the e5 point and develop the bishop to e7 or b7.',
            'Prepare the counter-strikes ...c5 and ...d5 in the center.',
          ]
        : [
            'Pressure Black’s e5 defender (Nc6) with the Spanish bishop on b5.',
            'Reroute the b1 knight via d2-f1-g3 toward the kingside.',
            'Execute the c3-d4 breakthrough while maintaining long-term spatial clamp.',
          ],
    };
  }
  if (name.includes('king\'s gambit')) {
    return {
      difficulty: 'Hard',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Black holds extra f4 pawn material or strikes back in center with ...d5'
        : 'Sacrificial Open f-file and dynamic central presence',
      keyPlans: isBlackStudy
        ? [
            'Accept the gambit and hold the material or strike immediately in center with ...d5 (Falkbeer).',
            'Develop quickly and exploit weaknesses along the e1-h4 diagonal against White’s king.',
            'Castle safely and trade into a winning endgame with extra pawn.',
          ]
        : [
            'Sacrifice the f-pawn (2.f4) to deflect Black’s e5 pawn and seize full center with d4.',
            'Use open f-file for kingside rook attacks against f7.',
          ],
    };
  }
  if (name.includes('grünfeld') || name.includes('grunfeld')) {
    return {
      difficulty: 'Hard',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Hypermodern Center: White broad pawn center (d4+c4) vs Black piece pressure'
        : 'White broad classical pawn center with d4, c4, and e4',
      keyPlans: isBlackStudy
        ? [
            'Allow White to build a giant pawn center, then undermine it with ...c5, ...Bg7, and ...Nc6.',
            'Dominate the long a1-h8 diagonal with the fianchettoed dark-squared bishop.',
            'Create active piece play against White’s overextended central pawns.',
          ]
        : [
            'Construct and maintain a dominant pawn center on d4 and c4.',
            'Defend the d4 pawn against Black’s heavy pieces with Be3 and Bc4.',
            'Use spatial advantage to launch a direct kingside attack.',
          ],
    };
  }
  if (name.includes('french')) {
    return {
      difficulty: 'Medium',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Interlocked Central Chain: White e5-d4 vs Black e6-d5'
        : 'White spatial wedge on e5 clamping Black’s kingside',
      keyPlans: isBlackStudy
        ? [
            'Undermine the base of White’s pawn chain with the immediate ...c5 break.',
            'Apply heavy multi-piece pressure on White\'s d4 pawn with ...Qb6, ...Nc6, and ...Nge7-f5.',
            'Solve Black’s light-squared "French bishop" problem with ...Bd7-b5 or kingside play.',
          ]
        : [
            'Lock the center with e5 and use spatial superiority to attack Black’s king.',
            'Defend the d4 pawn chain base with c3, Nf3, and Be3.',
            'Restrict Black’s bad light-squared bishop on c8 from getting active.',
          ],
    };
  }
  if (name.includes('caro-kann')) {
    return {
      difficulty: 'Medium',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Rock-Solid c6-d5 Pawn Fortress with free light-squared bishop'
        : 'White central space advantage (e5 or d4) with active piece development',
      keyPlans: isBlackStudy
        ? [
            'Develop light-squared bishop to Bf5 or Bg4 before locking the pawn chain with ...e6.',
            'Strike back at White’s center with timely ...c5 break.',
            'Transition into favorable endgames with superior pawn structure.',
          ]
        : [
            'Gain space with 3.e5 (Advance) or open lines with Nc3 (Classical).',
            'Pressure Black’s kingside pawn structure if Black exchanges on f5/g4.',
            'Prevent Black from comfortably breaking out with ...c5.',
          ],
    };
  }
  if (name.includes('queen\'s gambit')) {
    return {
      difficulty: 'Medium',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Solid d5-e6/c6 pawn foundation neutralizing White’s c4 pressure'
        : 'Classical d4-c4 Wedge controlling central territory',
      keyPlans: isBlackStudy
        ? [
            'Solidify the d5 outpost and comfortably develop pieces toward kingside safety.',
            'Solve the light-squared bishop problem via ...b6 and ...Ba6 or ...e5 break.',
            'Equalize space with timely ...c5 counter-thrust.',
          ]
        : [
            'Offer the c4 wing pawn to gain overwhelming central space and piece mobility.',
            'Pressure Black’s center with Nc3, Bg5, and e3/e4.',
            'Launch the Minority Attack (b4-b5) on the queenside to create weaknesses in Black’s structure.',
          ],
    };
  }
  if (name.includes('king\'s indian')) {
    return {
      difficulty: 'Medium',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Locked Center (e5-d5-c4 vs e5-d6-c7) with Black kingside attacking pawn wedge'
        : 'Locked Center with White queenside pawn expansion (c5, b4)',
      keyPlans: isBlackStudy
        ? [
            'Lock the center with ...e5, then launch a ferocious kingside attack with ...f5-f4 and ...g5.',
            'Reroute knights to f6 and g6 to support the assault against White’s king.',
            'Unleash devastating mating attacks before White breaches the queenside.',
          ]
        : [
            'Seize queenside space with c4, d5, and prepare the c4-c5 break.',
            'Invade along the open c-file with rooks into Black’s camp.',
            'Solidify kingside defense with f3, Bf2 to weather Black’s storm.',
          ],
    };
  }
  if (name.includes('nimzo-indian')) {
    return {
      difficulty: 'Medium',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Doubled c-pawns structure for White after ...Bxc3+ trade'
        : 'Bishop pair advantage for White with doubled c-pawns',
      keyPlans: isBlackStudy
        ? [
            'Pin and double White’s c-pawns with ...Bb4 and ...Bxc3+.',
            'Target the doubled c4/c3 pawns with ...b6, ...Ba6, ...Na5, and ...c5.',
            'Blockade the center and exploit White’s static pawn weaknesses.',
          ]
        : [
            'Utilize the powerful bishop pair in an open or semi-open position.',
            'Undouble pawns or use central pawn mass (e4) to overpower Black.',
            'Expand in center with e3-e4 or f3-e4.',
          ],
    };
  }
  if (name.includes('vienna')) {
    return {
      difficulty: 'Medium',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Black counters White’s f4 strike with active central piece development'
        : 'Dynamic King’s Pawn Center with f4 thrust',
      keyPlans: isBlackStudy
        ? [
            'Meet 2.Nc3 with 2...Nf6 and strike back in center with ...d5.',
            'Neutralize White’s Bc4 with solid piece coordination.',
            'Avoid pawn structure damage and exploit White’s weakened king diagonal.',
          ]
        : [
            'Delay Nf3 with 2.Nc3 to maintain the option of an early f2-f4 thrust.',
            'Attack Black’s kingside with Bc4, f4-f5, and open f-file tactics.',
          ],
    };
  }
  if (name.includes('english')) {
    return {
      difficulty: 'Medium',
      originSide: 'w',
      pawnStructure: isBlackStudy
        ? 'Flexible Black setups (...e5 Reversed Sicilian or ...c5 Symmetrical)'
        : 'Flank Control of d5 (c4 + g3 fianchetto)',
      keyPlans: isBlackStudy
        ? [
            'Occupy the center with 1...e5 (Reversed Sicilian) or match with 1...c5.',
            'Develop pieces actively without allowing White to dominate d5.',
            'Strike in the center with ...d5 when White prepares queenside expansion.',
          ]
        : [
            'Fianchetto the light-squared bishop on g2 to clamp down on the d5 square.',
            'Expand on the queenside with b4, a3, and Rb1.',
          ],
    };
  }
  if (name.includes('dutch')) {
    return {
      difficulty: 'Medium',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Asymmetrical f5 pawn stake with open kingside lines'
        : 'White targets weaknesses created by Black’s early f5 push',
      keyPlans: isBlackStudy
        ? [
            'Control the e4 square from move one with 1...f5.',
            'Build a Stonewall fortress (d5, e6, c6) or Leningrad fianchetto (...g6).',
            'Launch kingside attacks with ...Qe8-h5 and rook lifts.',
          ]
        : [
            'Fianchetto bishop on g2 to put pressure on Black’s central pawns.',
            'Break in the center with e4 to exploit Black’s loose king.',
            'Seize space on the queenside with c4 and b4.',
          ],
    };
  }
  if (name.includes('pirc')) {
    return {
      difficulty: 'Medium',
      originSide: 'b',
      pawnStructure: isBlackStudy
        ? 'Hypermodern d6-g6 setup with counter-strikes on e5/c5'
        : 'Broad classical center for White with e4, d4, and f4 (Austrian Attack)',
      keyPlans: isBlackStudy
        ? [
            'Allow White to occupy the center, then counter-attack with ...e5 or ...c5 and ...Bg7.',
            'Pressure White’s central pawns with ...Bg4, ...Nc6, and ...Qa5.',
            'Execute queenside counterplay against White’s castled king.',
          ]
        : [
            'Build a dominant center with d4, e4, and f4.',
            'Launch direct assault with Be3, Qd2, and Bh6 to trade Black’s defender.',
            'Castle queenside and push h4-h5 pawn storm.',
          ],
    };
  }

  const isWhitePawn = category?.includes("King's Pawn (1.e4)") && !name.includes('defense');
  return {
    difficulty: 'Medium',
    originSide: isWhitePawn ? 'w' : 'b',
    pawnStructure: isBlackStudy
      ? 'Solid theoretical structure fighting for key central squares'
      : 'Classical theoretical pawn structure with active piece play',
    keyPlans: isBlackStudy
      ? [
          'Neutralize White’s first-move advantage with precise piece development.',
          'Fight for control of the central squares (d5/e5/c5).',
          'Ensure king safety with early castling and prepare counter-breaks.',
        ]
      : [
          'Develop minor pieces rapidly toward the center.',
          'Seize central space and ensure king safety with early castling.',
          'Fight for dominant pawn breaks and initiative.',
        ],
  };
}
