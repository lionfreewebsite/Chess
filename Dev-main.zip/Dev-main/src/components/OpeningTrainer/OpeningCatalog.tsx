import React, { useMemo } from 'react';
import { BookOpen, Search, Swords, CheckCircle2, Trophy, ArrowRight } from 'lucide-react';
import { OPENINGS_DATABASE } from '../../engine/openingBook';
import { OpeningVariation, BoardTheme, PieceTheme, PieceStyle } from '../../types/chess';
import { MiniBoard } from '../Chessboard/MiniBoard';
import { CatalogFilter, getOpeningMetadata } from './types';

interface OpeningCatalogProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  categoryFilter: string;
  setCategoryFilter: (c: string) => void;
  statusFilter: CatalogFilter;
  setStatusFilter: (s: CatalogFilter) => void;
  studiedData: Record<string, string[]>;
  unlockedStages: Record<string, number>;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  onSelectOpening: (op: OpeningVariation) => void;
}

export const OpeningCatalog: React.FC<OpeningCatalogProps> = ({
  searchQuery,
  setSearchQuery,
  categoryFilter,
  setCategoryFilter,
  statusFilter,
  setStatusFilter,
  studiedData,
  unlockedStages,
  boardTheme,
  pieceTheme,
  pieceStyle,
  onSelectOpening,
}) => {
  const categories = useMemo(() => {
    const set = new Set<string>();
    OPENINGS_DATABASE.forEach((o) => set.add(o.category || 'Standard'));
    return ['All', ...Array.from(set)];
  }, []);

  // Helper to compute progress for an opening across all its variations for both White and Black
  const getOpeningProgress = useMemo(() => {
    return (op: OpeningVariation) => {
      const chapters = op.chapters && op.chapters.length > 0 ? op.chapters : [
        { id: `${op.name}-main`, title: 'Main Line', description: '', moves: op.moves, tokens: op.tokens, color: 'w' as const }
      ];
      
      const totalTracks = chapters.length * 2; // Each variation has White + Black tracks
      let masteredTracks = 0;
      let totalStageCredits = 0; // Each track has up to 3 stages (Watch, Study, Test)

      chapters.forEach((ch) => {
        const completedList = studiedData[op.name] || [];
        const isWhiteMastered = completedList.includes(`${ch.id}:w`) || completedList.includes(ch.id);
        const isBlackMastered = completedList.includes(`${ch.id}:b`);

        if (isWhiteMastered) masteredTracks++;
        if (isBlackMastered) masteredTracks++;

        const whiteUnlocked = isWhiteMastered ? 3 : (unlockedStages[`${op.name}:${ch.id}:w`] || 1);
        const blackUnlocked = isBlackMastered ? 3 : (unlockedStages[`${op.name}:${ch.id}:b`] || 1);

        totalStageCredits += isWhiteMastered ? 3 : (whiteUnlocked - 1);
        totalStageCredits += isBlackMastered ? 3 : (blackUnlocked - 1);
      });

      const isStudied = masteredTracks === totalTracks;
      const isStarted = totalStageCredits > 0;
      const percentage = Math.round((totalStageCredits / (totalTracks * 3)) * 100);

      return {
        masteredTracks,
        totalTracks,
        totalChapters: chapters.length,
        isStudied,
        isStarted,
        percentage,
      };
    };
  }, [studiedData, unlockedStages]);

  const filteredOpenings = useMemo(() => {
    return OPENINGS_DATABASE.filter((op) => {
      const matchSearch =
        op.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        op.eco.toLowerCase().includes(searchQuery.toLowerCase()) ||
        op.moves.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = categoryFilter === 'All' || op.category === categoryFilter;

      const progress = getOpeningProgress(op);
      let matchStatus = true;
      if (statusFilter === 'studied') matchStatus = progress.isStudied;
      if (statusFilter === 'unstudied') matchStatus = !progress.isStudied;

      return matchSearch && matchCat && matchStatus;
    });
  }, [searchQuery, categoryFilter, statusFilter, getOpeningProgress]);

  const totalOpeningsCount = OPENINGS_DATABASE.length;
  const studiedOpeningsCount = useMemo(() => {
    return OPENINGS_DATABASE.filter((op) => getOpeningProgress(op).isStudied).length;
  }, [getOpeningProgress]);

  const totalOverallPercentage = useMemo(() => {
    if (totalOpeningsCount === 0) return 0;
    const sum = OPENINGS_DATABASE.reduce((acc, op) => acc + getOpeningProgress(op).percentage, 0);
    return Math.round(sum / totalOpeningsCount);
  }, [getOpeningProgress, totalOpeningsCount]);

  const renderDifficultyBadge = (diff: 'Easy' | 'Medium' | 'Hard') => {
    if (diff === 'Easy') {
      return (
        <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 font-mono text-[11px] font-bold border border-emerald-500/30">
          Easy
        </span>
      );
    }
    if (diff === 'Hard') {
      return (
        <span className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-700 dark:text-rose-400 font-mono text-[11px] font-bold border border-rose-500/30">
          Hard
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-400 font-mono text-[11px] font-bold border border-amber-500/30">
        Medium
      </span>
    );
  };

  return (
    <div className="w-full flex-1 max-w-7xl mx-auto p-3 sm:p-6 flex flex-col gap-6">
      {/* Header with Stats & Progress */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-amber-500" />
            <h1 className="text-xl sm:text-2xl font-black text-stone-900 dark:text-stone-100 tracking-tight">
              Chess Openings Academy
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 max-w-2xl">
            Master grandmaster opening theory with step-by-step 3-stage lessons for both White and Black: 1. Overview & Watch, 2. Guided Study, and 3. Board Mastery Testing.
          </p>
        </div>

        {/* Mastery Progress Card */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl px-4 py-3 flex items-center gap-4 shadow-xs shrink-0">
          <div className="flex flex-col items-center">
            <span className="text-2xl font-mono font-black text-amber-600 dark:text-amber-400">
              {studiedOpeningsCount}/{totalOpeningsCount}
            </span>
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
              Mastered
            </span>
          </div>
          <div className="w-px h-8 bg-stone-200 dark:bg-stone-800" />
          <div className="flex flex-col">
            <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
              {totalOverallPercentage}% Academy Complete
            </span>
            <div className="w-32 h-2 rounded-full bg-stone-100 dark:bg-stone-800 overflow-hidden mt-1">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${totalOverallPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            type="text"
            placeholder="Search opening by name, ECO, or move..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 focus:outline-none focus:border-amber-500 text-stone-800 dark:text-stone-200 placeholder-stone-400"
          />
        </div>

        {/* Category Pills & Status Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 text-stone-800 dark:text-stone-200 focus:outline-none focus:border-amber-500"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <div className="flex items-center p-1 bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setStatusFilter('studied')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                statusFilter === 'studied'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
            >
              Mastered
            </button>
            <button
              onClick={() => setStatusFilter('unstudied')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                statusFilter === 'unstudied'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
            >
              Pending
            </button>
          </div>
        </div>
      </div>

      {/* Opening Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredOpenings.map((op) => {
          const progress = getOpeningProgress(op);
          const meta = getOpeningMetadata(op.name, op.category);

          return (
            <div
              key={op.name}
              onClick={() => onSelectOpening(op)}
              className={`group bg-white dark:bg-stone-900 border rounded-2xl p-4.5 flex flex-col justify-between gap-4 transition-all duration-200 hover:shadow-lg cursor-pointer ${
                progress.isStudied
                  ? 'border-emerald-500/40 hover:border-emerald-500 dark:border-emerald-500/30'
                  : 'border-stone-200 dark:border-stone-800 hover:border-amber-400 dark:hover:border-amber-500/60'
              }`}
            >
              <div className="space-y-3">
                {/* Top Row: ECO + Category + Difficulty + Mastered Badge */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                      {op.eco}
                    </span>
                    {renderDifficultyBadge(meta.difficulty)}
                    <span className="text-[11px] font-medium text-stone-500 dark:text-stone-400">
                      {op.category || 'General'}
                    </span>
                  </div>

                  {progress.isStudied ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      <Trophy className="w-3.5 h-3.5" />
                      100%
                    </span>
                  ) : progress.isStarted ? (
                    <span className="text-[11px] font-mono font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md">
                      {progress.percentage}%
                    </span>
                  ) : null}
                </div>

                {/* Opening Card Body: Mini Board on Left & Title/Description on Right */}
                <div className="flex items-start gap-3.5">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 shrink-0">
                    <MiniBoard
                      tokens={op.tokens}
                      boardTheme={boardTheme}
                      pieceTheme={pieceTheme}
                      pieceStyle={pieceStyle}
                      orientation={meta.originSide}
                      className="w-full h-full"
                    />
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                      {op.name}
                    </h3>
                    <p className="text-xs text-stone-600 dark:text-stone-400 line-clamp-2 leading-relaxed">
                      {op.description || 'Master key variations, moves, and master strategies.'}
                    </p>
                  </div>
                </div>

                {/* Pawn Structure / Strategy Pill */}
                <div className="text-[11px] text-stone-500 dark:text-stone-400 bg-stone-50 dark:bg-stone-800/50 p-2 rounded-xl border border-stone-100 dark:border-stone-800/80 truncate">
                  <span className="font-bold text-stone-700 dark:text-stone-300">Structure: </span>
                  {meta.pawnStructure}
                </div>
              </div>

              {/* Bottom Progress & Action Row */}
              <div className="space-y-2 pt-3 border-t border-stone-100 dark:border-stone-800/60">
                <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400">
                  <span>
                    {progress.totalChapters} Variations ({progress.masteredTracks}/{progress.totalTracks} sides mastered)
                  </span>
                  <span className="font-bold text-stone-700 dark:text-stone-300">
                    {progress.percentage}%
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="w-full h-1.5 rounded-full bg-stone-100 dark:bg-stone-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      progress.isStudied ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${progress.percentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    <span>Train Variations</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                  {progress.isStudied && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
