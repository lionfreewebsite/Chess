import React, { useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Compass,
  GraduationCap,
  Lock,
  CheckCircle2,
  Trophy,
  Swords,
  Sparkles,
} from 'lucide-react';
import { OpeningVariation, OpeningChapter, PieceColor, BoardTheme, PieceTheme, PieceStyle } from '../../types/chess';
import { MiniBoard } from '../Chessboard/MiniBoard';
import { TabMode, getOpeningMetadata } from './types';

interface VariationListProps {
  opening: OpeningVariation;
  studiedData: Record<string, string[]>;
  unlockedStages: Record<string, number>;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  completionNotice: string | null;
  setCompletionNotice: (msg: string | null) => void;
  onBackToCatalog: () => void;
  onSelectStage: (chapterIndex: number, color: PieceColor, tab: TabMode) => void;
}

export const VariationList: React.FC<VariationListProps> = ({
  opening,
  studiedData,
  unlockedStages,
  boardTheme,
  pieceTheme,
  pieceStyle,
  completionNotice,
  setCompletionNotice,
  onBackToCatalog,
  onSelectStage,
}) => {
  const meta撇 = getOpeningMetadata(opening.name, opening.category);

  const chapters: OpeningChapter[] = opening.chapters && opening.chapters.length > 0
    ? opening.chapters
    : [
        {
          id: `${opening.name}-main`,
          title: 'Main Theoretical Line',
          description: opening.description || 'Core theoretical moves and primary ideas.',
          moves: opening.moves,
          tokens: opening.tokens,
          color: 'w' as PieceColor,
        },
      ];

  // Store selected color perspective per variation card in state
  const [variationColors, setVariationColors] = useState<Record<string, PieceColor>>(() => {
    const initial: Record<string, PieceColor> = {};
    chapters.forEach((ch) => {
      initial[ch.id] = ch.color || meta撇.originSide || 'w';
    });
    return initial;
  });

  const setVariationColor = (chapterId: string, color: PieceColor) => {
    setVariationColors((prev) => ({ ...prev, [chapterId]: color }));
  };

  const renderDifficultyBadge = (diff: 'Easy' | 'Medium' | 'Hard') => {
    if (diff === 'Easy') {
      return (
        <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 font-mono text-[11px] font-bold border border-emerald-500/30">
          Easy
        </span>
      );
    }
    if (diff === 'Hard') {
      return (
        <span className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-700 dark:text-rose-400 font-mono text-[11px] font-bold border border-rose-500/30">
          Hard
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-400 font-mono text-[11px] font-bold border border-amber-500/30">
        Medium
      </span>
    );
  };

  return (
    <div className="w-full flex-1 max-w-7xl mx-auto p-3 sm:p-6 flex flex-col gap-6">
      {/* Toast Notice */}
      {completionNotice && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-900 dark:text-emerald-200 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{completionNotice}</span>
          </div>
          <button
            onClick={() => setCompletionNotice(null)}
            className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Header with Back Button and Opening Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToCatalog}
            className="p-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors border border-stone-200 dark:border-stone-700 flex items-center gap-1 text-xs font-bold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">All Openings</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black text-stone-900 dark:text-stone-100">
                {opening.name}
              </h1>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-300">
                {opening.eco}
              </span>
              {renderDifficultyBadge(meta撇.difficulty)}
            </div>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
              Select a variation and side below. Master both White and Black to complete 100%!
            </p>
          </div>
        </div>
      </div>

      {/* Variation Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {chapters.map((ch, idx) => {
          const completedList = studiedData[opening.name] || [];
          const isWhiteMastered = completedList.includes(`${ch.id}:w`) || completedList.includes(ch.id);
          const isBlackMastered = completedList.includes(`${ch.id}:b`);

          const whiteUnlocked = isWhiteMastered ? 3 : (unlockedStages[`${opening.name}:${ch.id}:w`] || 1);
          const blackUnlocked = isBlackMastered ? 3 : (unlockedStages[`${opening.name}:${ch.id}:b`] || 1);

          // 100% calculation requires completing both White and Black!
          // Total stages across both colors = 6 (3 for White + 3 for Black)
          const whiteCredits = isWhiteMastered ? 3 : (whiteUnlocked - 1);
          const blackCredits = isBlackMastered ? 3 : (blackUnlocked - 1);
          const totalCredits = whiteCredits + blackCredits;
          const variationPercentage不易 = Math.round((totalCredits / 6) * 100);
          const isFullyMastered = isWhiteMastered && isBlackMastered;

          const activeColor = variationColors[ch.id] || ch.color || 'w';
          const activeUnlocked = activeColor === 'w' ? whiteUnlocked : blackUnlocked;

          return (
            <div
              key={ch.id}
              className={`bg-white dark:bg-stone-900 border rounded-2xl p-4.5 flex flex-col justify-between gap-4 transition-all duration-200 shadow-xs ${
                isFullyMastered
                  ? 'border-emerald-500/40 dark:border-emerald-500/30'
                  : 'border-stone-200 dark:border-stone-800'
              }`}
            >
              <div className="space-y-3.5">
                {/* Variation Top Badges */}
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400">
                    Variation {idx + 1}
                  </span>
                  {isFullyMastered ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      <Trophy className="w-3.5 h-3.5" />
                      100% Mastered
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md">
                      {variationPercentage不易}% Completed
                    </span>
                  )}
                </div>

                {/* Variation Card Body: Mini Board & Details */}
                <div className="flex items-start gap-3.5">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 shrink-0">
                    <MiniBoard
                      tokens={ch.tokens}
                      boardTheme={boardTheme}
                      pieceTheme={pieceTheme}
                      pieceStyle={pieceStyle}
                      orientation={activeColor}
                      className="w-full h-full"
                    />
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <h3 className="text-sm sm:text-base font-bold text-stone-900 dark:text-stone-100">
                      {ch.title}
                    </h3>
                    <p className="text-xs text-stone-600 dark:text-stone-400 line-clamp-2 leading-relaxed">
                      {ch.description}
                    </p>
                  </div>
                </div>

                {/* Training Side Switch ON TOP OF PROGRESS BAR */}
                <div className="space-y-2 pt-1 border-t border-stone-100 dark:border-stone-800/60">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-stone-700 dark:text-stone-300">
                      Select Training Side:
                    </span>
                    <span className="text-[10px] font-mono text-stone-500 dark:text-stone-400">
                      Must master both for 100%
                    </span>
                  </div>

                  {/* Segmented Color Switch */}
                  <div className="grid grid-cols-2 p-1 bg-stone-100 dark:bg-stone-950/70 border border-stone-200 dark:border-stone-800 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setVariationColor(ch.id, 'w')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        activeColor === 'w'
                          ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs border border-stone-200/80 dark:border-stone-700'
                          : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full bg-stone-100 border border-stone-500 inline-block shadow-2xs shrink-0" />
                      <span>White</span>
                      {isWhiteMastered && (
                        <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setVariationColor(ch.id, 'b')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        activeColor === 'b'
                          ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs border border-stone-200/80 dark:border-stone-700'
                          : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full bg-stone-900 border border-stone-400 inline-block shadow-2xs shrink-0" />
                      <span>Black</span>
                      {isBlackMastered && (
                        <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                      )}
                    </button>
                  </div>

                  {/* Variation Overall Progress Bar (White + Black = 100%) */}
                  <div className="space-y-1 pt-1">
                    <div className="flex items-center justify-between text-[11px] font-medium text-stone-500 dark:text-stone-400">
                      <span>Variation Progress</span>
                      <span className="font-bold text-stone-700 dark:text-stone-300">
                        {variationPercentage不易}%
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-stone-100 dark:bg-stone-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isFullyMastered
                            ? 'bg-emerald-500'
                            : variationPercentage不易 >= 50
                            ? 'bg-amber-500'
                            : 'bg-amber-400'
                        }`}
                        style={{ width: `${variationPercentage不易}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-stone-400 pt-0.5">
                      <span>White: {isWhiteMastered ? 'Mastered ✓' : `${Math.round((whiteCredits / 3) * 100)}%`}</span>
                      <span>Black: {isBlackMastered ? 'Mastered ✓' : `${Math.round((blackCredits / 3) * 100)}%`}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stage Jump Buttons for the Active Color */}
              <div className="space-y-2 pt-2 border-t border-stone-100 dark:border-stone-800/60">
                <div className="flex items-center justify-between text-[10px] font-mono uppercase tracking-wider text-stone-400 font-bold">
                  <span>Train as {activeColor === 'w' ? 'White' : 'Black'}</span>
                  <span>Stage Selection</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {/* Stage 1: Overview */}
                  <button
                    onClick={() => onSelectStage(idx, activeColor, 'overview')}
                    className="py-2 px-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-bold text-[11px] transition-colors border border-stone-200 dark:border-stone-700 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <BookOpen className="w-3 h-3 text-amber-500 shrink-0" />
                    <span className="truncate">1. Watch</span>
                  </button>

                  {/* Stage 2: Guided Study */}
                  <button
                    onClick={() => {
                      if (activeUnlocked >= 2) {
                        onSelectStage(idx, activeColor, 'study');
                      }
                    }}
                    disabled={activeUnlocked < 2}
                    className={`py-2 px-1.5 rounded-xl font-bold text-[11px] transition-colors border flex items-center justify-center gap-1 ${
                      activeUnlocked < 2
                        ? 'opacity-40 cursor-not-allowed bg-stone-100 dark:bg-stone-900 border-stone-200 dark:border-stone-800 text-stone-400'
                        : 'bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 border-stone-200 dark:border-stone-700 cursor-pointer'
                    }`}
                    title={activeUnlocked < 2 ? 'Complete Stage 1 to unlock Guided Study' : 'Stage 2: Guided Study'}
                  >
                    {activeUnlocked < 2 ? (
                      <Lock className="w-3 h-3 text-stone-400 shrink-0" />
                    ) : (
                      <Compass className="w-3 h-3 text-amber-500 shrink-0" />
                    )}
                    <span className="truncate">2. Study</span>
                  </button>

                  {/* Stage 3: Mastery Test */}
                  <button
                    onClick={() => {
                      if (activeUnlocked >= 3) {
                        onSelectStage(idx, activeColor, 'test');
                      }
                    }}
                    disabled={activeUnlocked < 3}
                    className={`py-2 px-1.5 rounded-xl font-bold text-[11px] transition-colors border flex items-center justify-center gap-1 ${
                      activeUnlocked < 3
                        ? 'opacity-40 cursor-not-allowed bg-stone-100 dark:bg-stone-900 border-stone-200 dark:border-stone-800 text-stone-400'
                        : 'bg-amber-400 hover:bg-amber-500 text-stone-950 border-amber-400 shadow-xs cursor-pointer'
                    }`}
                    title={activeUnlocked < 3 ? 'Complete Stage 2 to unlock Mastery Test' : 'Stage 3: Mastery Test'}
                  >
                    {activeUnlocked < 3 ? (
                      <Lock className="w-3 h-3 text-stone-400 shrink-0" />
                    ) : (
                      <GraduationCap className="w-3 h-3 text-stone-950 shrink-0" />
                    )}
                    <span className="truncate">3. Test</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
