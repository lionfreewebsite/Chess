import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Compass,
  GraduationCap,
  Lock,
  RotateCcw,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  ChevronsLeft,
  ChevronsRight,
  Play,
  Pause,
  Swords,
  CheckCircle2,
  Zap,
  Target,
  Shield,
  ArrowRight,
  BrainCircuit,
  EyeOff,
} from 'lucide-react';
import {
  OpeningVariation,
  OpeningChapter,
  OpeningExplanation,
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  Square,
  AnimationSpeed,
  UIThemeColor,
} from '../../types/chess';
import { Chessboard, ArrowData } from '../Chessboard/Chessboard';
import { GameTree } from '../../engine/gameTree';
import { sqName, nameToSq, colorOf } from '../../engine/chessRules';
import { globalAudio } from '../../utils/audio';
import { getThemeConfig } from '../../utils/themeColors';
import { TabMode, getOpeningMetadata } from './types';

interface StudyWorkbenchProps {
  selectedOpening: OpeningVariation;
  selectedChapterIndex: number;
  trainColor: PieceColor;
  activeTab: TabMode;
  setActiveTab: (tab: TabMode) => void;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  soundEnabled: boolean;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  unlockedStages: Record<string, number>;
  studiedData: Record<string, string[]>;
  uiTheme?: UIThemeColor;
  onBackToVariations: () => void;
  onAnalyzeOpening: (tree: GameTree) => void;
  onUnlockStage: (openingName: string, chapterId: string, color: PieceColor, stage: number) => void;
  onMarkMastered: (openingName: string, chapterId: string, color: PieceColor) => void;
  setCompletionNotice: (msg: string | null) => void;
}

/**
 * Generates dedicated color-perspective aware move explanations
 * (White training sees user moves vs opponent replies;
 *  Black training sees opponent moves vs user counterplay).
 */
function getPerspectiveExplanation(
  rawExplanation: OpeningExplanation | undefined,
  ply: number,
  san: string | null,
  trainColor: PieceColor
): { title: string; why: string; plans: string } {
  if (ply === 0 || !san) {
    return {
      title: 'Starting Position',
      why: 'Starting position of the board. Follow the theoretical line move-by-move.',
      plans: trainColor === 'w' ? 'Establish central control with 1.e4 or 1.d4.' : 'Prepare to challenge White’s first-move advantage.',
    };
  }

  const isWhiteMove = ply % 2 !== 0;
  const isUserMove = (trainColor === 'w' && isWhiteMove) || (trainColor === 'b' && !isWhiteMove);
  const moveNumber = Math.ceil(ply / 2);
  const moveNotation = isWhiteMove ? `${moveNumber}. ${san}` : `${moveNumber}... ${san}`;

  if (rawExplanation) {
    if (trainColor === 'b') {
      if (isWhiteMove) {
        // Opponent (White) played a move
        return {
          title: `Opponent Plays: ${moveNotation}`,
          why: rawExplanation.why
            ? `Opponent plays ${san} (${rawExplanation.why.replace(/White /g, 'Opponent ').replace(/White\'s /g, "Opponent's ")})`
            : `Opponent plays ${san} fighting for central space and development.`,
          plans: rawExplanation.plans
            ? `Your counter-plan: ${rawExplanation.plans.replace(/Black /g, 'You ').replace(/Black\'s /g, 'Your ')}`
            : 'Counter White’s setup with active piece development and central counter-strikes.',
        };
      } else {
        // User (Black) plays a move
        return {
          title: `Your Move (Black): ${moveNotation}`,
          why: rawExplanation.why
            ? rawExplanation.why
                .replace(/Black /g, 'You ')
                .replace(/Black\'s /g, 'Your ')
                .replace(/White /g, 'Opponent ')
                .replace(/White\'s /g, "Opponent's ")
            : `You play ${moveNotation} to contest the center and develop active counterplay.`,
          plans: rawExplanation.plans
            ? rawExplanation.plans
                .replace(/Black /g, 'You ')
                .replace(/Black\'s /g, 'Your ')
                .replace(/White /g, 'Opponent ')
                .replace(/White\'s /g, "Opponent's ")
            : 'Coordinate your pieces, secure king safety, and prepare strategic pawn breaks.',
        };
      }
    } else {
      // trainColor === 'w'
      if (isWhiteMove) {
        // User (White) plays a move
        return {
          title: `Your Move (White): ${moveNotation}`,
          why: rawExplanation.why
            ? rawExplanation.why
                .replace(/White /g, 'You ')
                .replace(/White\'s /g, 'Your ')
                .replace(/Black /g, 'Opponent ')
                .replace(/Black\'s /g, "Opponent's ")
            : `You play ${moveNotation} seizing space, developing pieces, and building the initiative.`,
          plans: rawExplanation.plans
            ? rawExplanation.plans
                .replace(/White /g, 'You ')
                .replace(/White\'s /g, 'Your ')
            : 'Mobilize pieces quickly and target enemy weaknesses.',
        };
      } else {
        // Opponent (Black) played a move
        return {
          title: `Opponent's Response: ${moveNotation}`,
          why: rawExplanation.why
            ? `Opponent replies with ${san} (${rawExplanation.why.replace(/Black /g, 'Opponent ').replace(/Black\'s /g, "Opponent's ")})`
            : `Opponent responds with ${san} seeking solid piece placement and counterplay.`,
          plans: rawExplanation.plans
            ? `Your continuation plan: ${rawExplanation.plans.replace(/White /g, 'You ').replace(/White\'s /g, 'Your ')}`
            : 'Maintain your central presence and press the opening advantage.',
        };
      }
    }
  }

  // Fallback if no specific rawExplanation in database
  if (isUserMove) {
    return {
      title: `Your Move (${trainColor === 'w' ? 'White' : 'Black'}): ${moveNotation}`,
      why: `You play ${moveNotation} according to master theory for maximum activity, central pressure, and piece harmony.`,
      plans: `Continue theoretical development and safeguard your king.`,
    };
  } else {
    return {
      title: `Opponent Plays: ${moveNotation}`,
      why: `Opponent plays ${moveNotation} contesting the board.`,
      plans: `Execute your prepared theoretical response.`,
    };
  }
}

export const StudyWorkbench: React.FC<StudyWorkbenchProps> = ({
  selectedOpening,
  selectedChapterIndex,
  trainColor,
  activeTab,
  setActiveTab,
  boardTheme,
  pieceTheme,
  pieceStyle,
  soundEnabled,
  animationEnabled = true,
  animationSpeed = 'normal',
  unlockedStages,
  studiedData,
  uiTheme,
  onBackToVariations,
  onAnalyzeOpening,
  onUnlockStage,
  onMarkMastered,
  setCompletionNotice,
}) => {
  const themeCfg = getThemeConfig(uiTheme);
  const chaptersList = useMemo(() => {
    return (
      selectedOpening.chapters || [
        {
          id: `${selectedOpening.name}-main`,
          title: 'Main Theoretical Line',
          description: selectedOpening.description || 'Core theoretical moves and primary ideas.',
          moves: selectedOpening.moves,
          tokens: selectedOpening.tokens,
          color: 'w' as PieceColor,
        },
      ]
    );
  }, [selectedOpening]);

  const activeChapter: OpeningChapter = useMemo(() => {
    return chaptersList[selectedChapterIndex] || chaptersList[0];
  }, [chaptersList, selectedChapterIndex]);

  const openingMeta = useMemo(() => {
    return getOpeningMetadata(selectedOpening.name, selectedOpening.category, trainColor);
  }, [selectedOpening, trainColor]);

  const tokens = useMemo(() => {
    return activeChapter.tokens && activeChapter.tokens.length > 0
      ? activeChapter.tokens
      : selectedOpening.tokens;
  }, [activeChapter, selectedOpening]);

  // Stage unlocks and mastery tracking for this specific chapter and side
  const chapterSideKey = `${selectedOpening.name}:${activeChapter.id}:${trainColor}`;
  const isMasteredThisSide = (studiedData[selectedOpening.name] || []).includes(
    `${activeChapter.id}:${trainColor}`
  );
  const maxUnlockedStage = isMasteredThisSide ? 3 : unlockedStages[chapterSideKey] || 1;

  // Board orientation matches trainColor by default
  const [boardOrientation, setBoardOrientation] = useState<PieceColor>(trainColor);
  useEffect(() => {
    setBoardOrientation(trainColor);
  }, [trainColor]);

  // Guard flags to prevent frozen pieces or race conditions
  const isOpponentThinkingRef = useRef<boolean>(false);
  const isProcessingMoveRef = useRef<boolean>(false);

  // ==========================================
  // 1. OVERVIEW / WATCH MODE
  // ==========================================
  const [overviewPly, setOverviewPly] = useState<number>(0);
  const [isAutoplaying, setIsAutoplaying] = useState<boolean>(false);
  const [overviewTree, setOverviewTree] = useState<GameTree>(() => new GameTree());

  const resetOverview = useCallback(() => {
    const tree = new GameTree();
    setOverviewTree(tree);
    setOverviewPly(0);
    setIsAutoplaying(false);
  }, []);

  useEffect(() => {
    resetOverview();
  }, [activeChapter, selectedOpening, trainColor, resetOverview]);

  const stepOverviewTo = useCallback(
    (targetPly: number) => {
      const clamped = Math.max(0, Math.min(tokens.length, targetPly));
      const tree = new GameTree();
      for (let i = 0; i < clamped; i++) {
        tree.playSAN(tokens[i]);
      }
      if (soundEnabled && clamped > 0) globalAudio.move();
      setOverviewTree(tree);
      setOverviewPly(clamped);

      if (clamped >= tokens.length) {
        onUnlockStage(selectedOpening.name, activeChapter.id, trainColor, 2);
      }
    },
    [tokens, soundEnabled, onUnlockStage, selectedOpening.name, activeChapter.id, trainColor]
  );

  // Autoplay timer
  useEffect(() => {
    if (!isAutoplaying) return;
    if (overviewPly >= tokens.length) {
      setIsAutoplaying(false);
      onUnlockStage(selectedOpening.name, activeChapter.id, trainColor, 2);
      return;
    }

    const timer = setTimeout(() => {
      stepOverviewTo(overviewPly + 1);
    }, 1400);

    return () => clearTimeout(timer);
  }, [isAutoplaying, overviewPly, tokens.length, stepOverviewTo, onUnlockStage, selectedOpening.name, activeChapter.id, trainColor]);

  // ==========================================
  // 2. GUIDED STUDY STATE (Assisted)
  // ==========================================
  const [studyTree, setStudyTree] = useState<GameTree>(() => new GameTree());
  const [studyCompleted, setStudyCompleted] = useState<boolean>(false);
  const [studyFeedback, setStudyFeedback] = useState<{
    type: 'idle' | 'success' | 'warning' | 'error' | 'info';
    message: string;
  }>({
    type: 'idle',
    message: 'Follow the green arrow on the board to play the theoretical move.',
  });

  const resetStudy = useCallback(() => {
    isOpponentThinkingRef.current = false;
    isProcessingMoveRef.current = false;
    setStudyCompleted(false);

    const tree = new GameTree();
    if (trainColor === 'w') {
      // User starts as White
      setStudyTree(tree);
      setStudyFeedback({
        type: 'idle',
        message: `Your turn! Follow the green arrow to play 1. ${tokens[0] || ''} for White.`,
      });
    } else {
      // User is training as Black: Engine immediately plays White's move
      if (tokens.length > 0) {
        tree.playSAN(tokens[0]);
        setStudyTree(tree.clone());
        setStudyFeedback({
          type: 'info',
          message: `White opened with 1. ${tokens[0]}. Follow the green arrow to play Black's reply (${tokens[1] || ''}).`,
        });
      } else {
        setStudyTree(tree);
        setStudyFeedback({
          type: 'idle',
          message: 'Your turn to play for Black.',
        });
      }
    }
  }, [trainColor, tokens]);

  useEffect(() => {
    if (activeTab === 'study') {
      resetStudy();
    }
  }, [activeTab, activeChapter, trainColor, resetStudy]);

  // Guided Study Move Handler
  const handleStudyMove = (from: Square | string, to: Square | string, promo?: string) => {
    if (studyCompleted) return;
    if (isOpponentThinkingRef.current || isProcessingMoveRef.current) return;
    if (studyTree.chess.turn !== trainColor) return;

    const currentPly = studyTree.mainline().length;
    const expectedMove = tokens[currentPly];
    if (!expectedMove) return;

    const fromNum = typeof from === 'string' ? nameToSq(from) : from;
    const toNum = typeof to === 'string' ? nameToSq(to) : to;
    const fromStr = typeof from === 'number' ? sqName(from) : from;
    const toStr = typeof to === 'number' ? sqName(to) : to;

    const legalMoves = studyTree.chess.legalMoves({ from: fromNum });
    const matchedMove = legalMoves.find((m) => m.to === toNum && (!promo || m.promo === promo));
    if (!matchedMove) return;

    const allLegal = studyTree.chess.legalMoves();
    const attemptedSan = studyTree.chess.moveToSAN(matchedMove, allLegal);
    const normalize = (s: string) => s.replace(/[+#x!?-]/g, '').trim().toLowerCase();

    const expectedLegalObj = studyTree.chess._matchSAN(expectedMove, allLegal);
    const isCoordinateMatch =
      expectedLegalObj &&
      matchedMove.from === expectedLegalObj.from &&
      matchedMove.to === expectedLegalObj.to;
    const isSanMatch = normalize(attemptedSan) === normalize(expectedMove);

    if (isCoordinateMatch || isSanMatch) {
      // Valid book move
      isProcessingMoveRef.current = true;
      const nextTree = studyTree.clone();
      const addRes = nextTree.addMove(fromStr, toStr, promo);
      if (!addRes) {
        nextTree.playSAN(expectedMove);
      }
      setStudyTree(nextTree);
      if (soundEnabled) globalAudio.move();
      isProcessingMoveRef.current = false;

      const nextPly = currentPly + 1;
      if (nextPly >= tokens.length) {
        if (soundEnabled) globalAudio.victory();
        setStudyCompleted(true);
        onUnlockStage(selectedOpening.name, activeChapter.id, trainColor, 3);
        setStudyFeedback({
          type: 'success',
          message: `🎉 Great job! Guided study for "${activeChapter.title}" as ${trainColor === 'w' ? 'White' : 'Black'} is complete. Stage 3 (Mastery Test) is now unlocked!`,
        });
        return;
      }

      setStudyFeedback({
        type: 'success',
        message: `✓ Correct! ${attemptedSan} is the theoretical book move.`,
      });

      // Opponent auto-reply
      isOpponentThinkingRef.current = true;
      setTimeout(() => {
        try {
          const opponentReply = tokens[nextPly];
          if (opponentReply) {
            const oppTree = nextTree.clone();
            const res = oppTree.playSAN(opponentReply);
            if (!res) {
              const oppLegal = oppTree.chess.legalMoves();
              const oppMv = oppTree.chess._matchSAN(opponentReply, oppLegal);
              if (oppMv) {
                oppTree.addMove(sqName(oppMv.from), sqName(oppMv.to), oppMv.promotion || null);
              }
            }
            if (soundEnabled) globalAudio.move();
            setStudyTree(oppTree);

            const plyAfterOpponent = nextPly + 1;
            if (plyAfterOpponent >= tokens.length) {
              if (soundEnabled) globalAudio.victory();
              setStudyCompleted(true);
              onUnlockStage(selectedOpening.name, activeChapter.id, trainColor, 3);
              setStudyFeedback({
                type: 'success',
                message: `🎉 Great job! Guided study for "${activeChapter.title}" as ${trainColor === 'w' ? 'White' : 'Black'} is complete. Stage 3 (Mastery Test) is now unlocked!`,
              });
            } else {
              setStudyFeedback({
                type: 'info',
                message: `Opponent answered ${opponentReply}. Follow the green arrow to continue.`,
              });
            }
          }
        } finally {
          isOpponentThinkingRef.current = false;
        }
      }, 350);
    } else {
      // Wrong move
      if (soundEnabled) globalAudio.error();
      setStudyFeedback({
        type: 'error',
        message: `⚠️ "${attemptedSan}" is not the book move. Follow the green arrow to play "${expectedMove}".`,
      });
    }
  };

  // ==========================================
  // 3. MASTERY TEST STATE (Testing from memory)
  // ==========================================
  const [testTree, setTestTree] = useState<GameTree>(() => new GameTree());
  const [testCompleted, setTestCompleted] = useState<boolean>(false);
  const [testFailed, setTestFailed] = useState<boolean>(false);
  const [testFailedArrow, setTestFailedArrow] = useState<ArrowData[]>([]);
  const [testFeedback, setTestFeedback] = useState<{
    type: 'idle' | 'success' | 'warning' | 'error' | 'info';
    message: string;
  }>({
    type: 'idle',
    message: 'Play the theoretical moves from memory without assistance.',
  });

  const resetTest = useCallback(() => {
    isOpponentThinkingRef.current = false;
    isProcessingMoveRef.current = false;
    setTestCompleted(false);
    setTestFailed(false);
    setTestFailedArrow([]);

    const tree = new GameTree();
    if (trainColor === 'w') {
      setTestTree(tree);
      setTestFeedback({
        type: 'idle',
        message: 'Play from memory for White. All hints and move lists are hidden!',
      });
    } else {
      if (tokens.length > 0) {
        tree.playSAN(tokens[0]);
        setTestTree(tree.clone());
        setTestFeedback({
          type: 'info',
          message: `White opened with 1. ${tokens[0]}. What is Black's theoretical response?`,
        });
      } else {
        setTestTree(tree);
        setTestFeedback({
          type: 'idle',
          message: 'Play from memory for Black.',
        });
      }
    }
  }, [trainColor, tokens]);

  useEffect(() => {
    if (activeTab === 'test') {
      resetTest();
    }
  }, [activeTab, activeChapter, trainColor, resetTest]);

  // Master Test Move Handler - completely glitch-free & multi-move enabled
  const handleTestMove = (from: Square | string, to: Square | string, promo?: string) => {
    if (testCompleted || testFailed) return;
    if (isOpponentThinkingRef.current || isProcessingMoveRef.current) return;
    if (testTree.chess.turn !== trainColor) return;

    const currentPly = testTree.mainline().length;
    const expectedMove = tokens[currentPly];
    if (!expectedMove) return;

    const fromNum = typeof from === 'string' ? nameToSq(from) : from;
    const toNum = typeof to === 'string' ? nameToSq(to) : to;
    const fromStr = typeof from === 'number' ? sqName(from) : from;
    const toStr = typeof to === 'number' ? sqName(to) : to;

    const legalMoves = testTree.chess.legalMoves({ from: fromNum });
    const matchedMove = legalMoves.find((m) => m.to === toNum && (!promo || m.promo === promo));
    if (!matchedMove) return;

    const allLegal = testTree.chess.legalMoves();
    const attemptedSan = testTree.chess.moveToSAN(matchedMove, allLegal);
    const normalize = (s: string) => s.replace(/[+#x!?-]/g, '').trim().toLowerCase();

    const expectedLegalObj = testTree.chess._matchSAN(expectedMove, allLegal);
    const isCoordinateMatch =
      expectedLegalObj &&
      matchedMove.from === expectedLegalObj.from &&
      matchedMove.to === expectedLegalObj.to;
    const isSanMatch = normalize(attemptedSan) === normalize(expectedMove);

    if (isCoordinateMatch || isSanMatch) {
      isProcessingMoveRef.current = true;
      const nextTree = testTree.clone();
      const addRes = nextTree.addMove(fromStr, toStr, promo);
      if (!addRes) {
        nextTree.playSAN(expectedMove);
      }
      setTestTree(nextTree);
      if (soundEnabled) globalAudio.move();
      isProcessingMoveRef.current = false;

      const nextPly = currentPly + 1;
      if (nextPly >= tokens.length) {
        if (soundEnabled) globalAudio.victory();
        setTestCompleted(true);
        onMarkMastered(selectedOpening.name, activeChapter.id, trainColor);
        setTestFeedback({
          type: 'success',
          message: `🏆 Flawless! You have mastered "${activeChapter.title}" as ${trainColor === 'w' ? 'White' : 'Black'}. Returning to variations...`,
        });

        setTimeout(() => {
          setCompletionNotice(
            `✓ Variation "${activeChapter.title}" mastered as ${trainColor === 'w' ? 'White' : 'Black'}!`
          );
          onBackToVariations();
        }, 1400);
        return;
      }

      setTestFeedback({
        type: 'success',
        message: `✓ Correct! Opponent replying...`,
      });

      // Opponent auto-reply
      isOpponentThinkingRef.current = true;
      setTimeout(() => {
        try {
          const opponentReply = tokens[nextPly];
          if (opponentReply) {
            const oppTree = nextTree.clone();
            const res = oppTree.playSAN(opponentReply);
            if (!res) {
              const oppLegal = oppTree.chess.legalMoves();
              const oppMv = oppTree.chess._matchSAN(opponentReply, oppLegal);
              if (oppMv) {
                oppTree.addMove(sqName(oppMv.from), sqName(oppMv.to), oppMv.promotion || null);
              }
            }
            if (soundEnabled) globalAudio.move();
            setTestTree(oppTree);

            const plyAfterOpponent = nextPly + 1;
            if (plyAfterOpponent >= tokens.length) {
              if (soundEnabled) globalAudio.victory();
              setTestCompleted(true);
              onMarkMastered(selectedOpening.name, activeChapter.id, trainColor);
              setTestFeedback({
                type: 'success',
                message: `🏆 Flawless! You have mastered "${activeChapter.title}" as ${trainColor === 'w' ? 'White' : 'Black'}. Returning to variations...`,
              });
              setTimeout(() => {
                setCompletionNotice(
                  `✓ Variation "${activeChapter.title}" mastered as ${trainColor === 'w' ? 'White' : 'Black'}!`
                );
                onBackToVariations();
              }, 1400);
            } else {
              setTestFeedback({
                type: 'info',
                message: `Opponent answered ${opponentReply}. Find your next move from memory.`,
              });
            }
          }
        } finally {
          isOpponentThinkingRef.current = false;
        }
      }, 350);
    } else {
      // Wrong move in test
      if (soundEnabled) globalAudio.error();
      setTestFailed(true);

      const correctLegalMove = allLegal.find((m) => {
        const san = testTree.chess.moveToSAN(m, allLegal);
        return normalize(san) === normalize(expectedMove);
      });

      if (correctLegalMove) {
        setTestFailedArrow([
          {
            from: correctLegalMove.from,
            to: correctLegalMove.to,
            tier: 'best',
          },
        ]);
      }

      setTestFeedback({
        type: 'error',
        message: `❌ Incorrect move (${attemptedSan})! The right theoretical move was "${expectedMove}".`,
      });
    }
  };

  // ==========================================
  // COMPUTED ACTIVE DISPLAY TREE & EXPLANATIONS
  // ==========================================
  const activeDisplayTree =
    activeTab === 'study' ? studyTree : activeTab === 'test' ? testTree : overviewTree;

  const currentDisplayPly =
    activeTab === 'overview'
      ? overviewPly
      : activeTab === 'study'
      ? studyTree.mainline().length
      : testTree.mainline().length;

  const currentToken =
    currentDisplayPly > 0 && currentDisplayPly <= tokens.length
      ? tokens[currentDisplayPly - 1]
      : null;

  // Raw explanation from opening book
  const rawExplanation: OpeningExplanation | undefined = useMemo(() => {
    if (!activeChapter.explanations) return undefined;
    const ply =
      activeTab === 'overview'
        ? overviewPly
        : activeTab === 'study'
        ? studyTree.mainline().length + (studyTree.chess.turn === trainColor ? 1 : 0)
        : testTree.mainline().length;

    return activeChapter.explanations.find(
      (e) => e.ply === ply || (currentToken && e.move === currentToken)
    );
  }, [activeChapter, activeTab, overviewPly, studyTree, testTree, currentToken, trainColor]);

  // Color-specific tailored explanation
  const perspectiveExplanation = useMemo(() => {
    return getPerspectiveExplanation(
      rawExplanation,
      currentDisplayPly,
      currentToken,
      trainColor
    );
  }, [rawExplanation, currentDisplayPly, currentToken, trainColor]);

  // Pedagogical Arrows on the board
  const activeArrows: ArrowData[] = useMemo(() => {
    if (activeTab === 'overview') {
      if (rawExplanation?.arrows && rawExplanation.arrows.length > 0) {
        return rawExplanation.arrows;
      }
      if (overviewPly > 0 && overviewPly <= tokens.length) {
        const lastNode = overviewTree.current;
        if (lastNode && lastNode.uci) {
          return [
            {
              from: nameToSq(lastNode.uci.from),
              to: nameToSq(lastNode.uci.to),
              tier: 'best',
            },
          ];
        }
      }
      return [];
    }

    if (activeTab === 'study' && !studyCompleted) {
      if (studyTree.chess.turn !== trainColor) return [];

      const currentPly = studyTree.mainline().length;
      const expectedMove = tokens[currentPly];
      if (!expectedMove) return [];

      if (rawExplanation?.arrows && rawExplanation.arrows.length > 0) {
        return rawExplanation.arrows;
      }

      const legal = studyTree.chess.legalMoves();
      const normalize = (s: string) => s.replace(/[+#x!?-]/g, '').trim().toLowerCase();
      const matched = legal.find((m) => {
        const san = studyTree.chess.moveToSAN(m, legal);
        return normalize(san) === normalize(expectedMove);
      });

      if (matched) {
        const arrows: ArrowData[] = [{ from: matched.from, to: matched.to, tier: 'best' }];
        if (rawExplanation?.keySquare !== undefined) {
          arrows.push({ from: matched.to, to: rawExplanation.keySquare, tier: 'second' });
        }
        return arrows;
      }
    }

    if (activeTab === 'test' && testFailed) {
      return testFailedArrow;
    }

    return [];
  }, [
    activeTab,
    rawExplanation,
    studyCompleted,
    testFailed,
    testFailedArrow,
    studyTree,
    tokens,
    trainColor,
    overviewPly,
    overviewTree,
  ]);

  const renderDifficultyBadge = (diff: 'Easy' | 'Medium' | 'Hard') => {
    if (diff === 'Easy') {
      return (
        <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 font-mono text-[11px] font-bold border border-emerald-500/30">
          Easy
        </span>
      );
    }
    if (diff === 'Hard') {
      return (
        <span className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-700 dark:text-rose-400 font-mono text-[11px] font-bold border border-rose-500/30">
          Hard
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-400 font-mono text-[11px] font-bold border border-amber-500/30">
        Medium
      </span>
    );
  };

  return (
    <div className="w-full flex-1 max-w-7xl mx-auto p-3 sm:p-6 flex flex-col gap-4">
      {/* Top Header: Breadcrumb & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-200 dark:border-stone-800 pb-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToVariations}
            className="p-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors border border-stone-200 dark:border-stone-700 flex items-center gap-1 text-xs font-bold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Variations</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100">
                {selectedOpening.name}
              </h2>
              <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold">
                {selectedOpening.eco}
              </span>
              {renderDifficultyBadge(openingMeta.difficulty)}
              <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 flex items-center gap-1">
                <span
                  className={`w-2 h-2 rounded-full ${
                    trainColor === 'w'
                      ? 'bg-stone-200 border border-stone-600'
                      : 'bg-stone-900 border border-stone-400'
                  }`}
                />
                Training as {trainColor === 'w' ? 'White' : 'Black'}
              </span>
            </div>
            <span className="text-xs text-stone-500 dark:text-stone-400">
              {activeChapter.title}
            </span>
          </div>
        </div>
      </div>

      {/* Main 2-Column Study Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(340px,500px)_1fr] gap-6 items-start">
        {/* Left Column: Board Header (Explanations for Stages 1 & 2; Test Status for Stage 3), Board, Controls */}
        <div className="flex flex-col items-center gap-3">
          {/* ========================================================= */}
          {/* MOVE EXPLANATION (STAGE 1 & 2 ONLY) / TEST BANNER (STAGE 3) */}
          {/* ========================================================= */}
          {activeTab !== 'test' ? (
            <div className="w-full max-w-[500px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-xs space-y-1.5">
              <div className="flex items-center justify-between gap-2 border-b border-stone-100 dark:border-stone-800/80 pb-2">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-300 font-mono text-xs font-bold">
                    {currentToken
                      ? `Move ${currentDisplayPly}: ${currentToken}`
                      : activeTab === 'study' && studyTree.mainline().length < tokens.length
                      ? `Next Move: ${tokens[studyTree.mainline().length] || '...'}`
                      : 'Starting Position'}
                  </span>
                  <span className="text-xs font-bold text-stone-800 dark:text-stone-200 truncate">
                    {perspectiveExplanation.title}
                  </span>
                </div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 font-bold shrink-0">
                  {activeTab === 'overview'
                    ? `Ply ${overviewPly}/${tokens.length}`
                    : `Ply ${studyTree.mainline().length}/${tokens.length}`}
                </span>
              </div>

              {/* Color-aware Move Rationale */}
              <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed font-medium">
                {activeTab === 'overview'
                  ? overviewPly === 0
                    ? 'Starting position. Click "Next Move →" or "Autoplay" to observe the move-by-move ideas.'
                    : perspectiveExplanation.why
                  : studyCompleted
                  ? '🎉 Guided study completed for this line! Proceed to Stage 3 to test your memory.'
                  : studyTree.chess.turn === trainColor
                  ? perspectiveExplanation.why
                  : `Opponent is playing the theoretical continuation...`}
              </p>

              {/* Color-aware Strategic Plan */}
              {perspectiveExplanation.plans && (
                <div className="flex items-center gap-1.5 text-[11px] text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-200/60 dark:border-amber-900/60 font-medium">
                  <Target className="w-3 h-3 text-amber-500 shrink-0" />
                  <span className="truncate">Plan: {perspectiveExplanation.plans}</span>
                </div>
              )}
            </div>
          ) : (
            /* Stage 3 Mastery Test Mode Header - No hints, no sequence, no answer spoilers */
            <div className="w-full max-w-[500px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-xs flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-400/20 flex items-center justify-center text-amber-600 dark:text-amber-400">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-stone-900 dark:text-stone-100">
                      Stage 3: Mastery Test
                    </span>
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-400">
                      Memory Mode
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400 font-medium">
                    {testCompleted
                      ? 'Test completed successfully!'
                      : testFailed
                      ? 'Wrong move. Red arrow indicates the correct theoretical move.'
                      : testTree.chess.turn === trainColor
                      ? `Your turn (${trainColor === 'w' ? 'White' : 'Black'}). Play from memory.`
                      : 'Opponent is playing the continuation...'}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-mono font-black text-amber-600 dark:text-amber-400">
                  Ply {Math.min(testTree.mainline().length, tokens.length)}/{tokens.length}
                </span>
              </div>
            </div>
          )}

          {/* Chessboard Container */}
          <div className="w-full max-w-[500px] aspect-square">
            <Chessboard
              board={activeDisplayTree.chess.board}
              turn={activeDisplayTree.chess.turn}
              interactive={activeTab === 'study' || activeTab === 'test'}
              canSelect={(sq) => {
                if (activeTab === 'overview') return false;
                if (activeTab === 'study' && studyCompleted) return false;
                if (activeTab === 'test' && (testCompleted || testFailed)) return false;
                if (isOpponentThinkingRef.current) return false;
                if (activeDisplayTree.chess.turn !== trainColor) return false;
                const p = activeDisplayTree.chess.board[sq];
                return !!p && colorOf(p) === trainColor;
              }}
              getLegalTargets={(sq) =>
                activeDisplayTree.chess.getLegalTargetsForSquare(sq)
              }
              orientation={boardOrientation}
              boardTheme={boardTheme}
              pieceTheme={pieceTheme}
              pieceStyle={pieceStyle}
              animationEnabled={animationEnabled}
              animationSpeed={animationSpeed}
              engineArrows={activeArrows}
              arrows={activeArrows}
              onMove={(from, to, promo) => {
                if (activeTab === 'study') {
                  handleStudyMove(from, to, promo);
                } else if (activeTab === 'test') {
                  handleTestMove(from, to, promo);
                }
              }}
            />
          </div>

          {/* Stepper Controls in Overview Mode */}
          {activeTab === 'overview' && (
            <div className="w-full max-w-[500px] flex flex-col gap-2">
              <div className="flex items-center justify-between p-2 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xs">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => stepOverviewTo(0)}
                    disabled={overviewPly === 0}
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-700 dark:text-stone-200 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
                    title="Start Position"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => stepOverviewTo(overviewPly - 1)}
                    disabled={overviewPly === 0}
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-700 dark:text-stone-200 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
                    title="Previous Move"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => stepOverviewTo(tokens.length)}
                    disabled={overviewPly >= tokens.length}
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-700 dark:text-stone-200 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
                    title="End of Line"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsAutoplaying(!isAutoplaying)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors border cursor-pointer ${
                      isAutoplaying
                        ? 'bg-amber-400 text-stone-950 border-amber-500'
                        : 'bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 border-stone-200 dark:border-stone-700'
                    }`}
                  >
                    {isAutoplaying ? (
                      <Pause className="w-3.5 h-3.5" />
                    ) : (
                      <Play className="w-3.5 h-3.5" />
                    )}
                    <span>{isAutoplaying ? 'Pause' : 'Autoplay'}</span>
                  </button>

                  <button
                    onClick={() => setBoardOrientation(boardOrientation === 'w' ? 'b' : 'w')}
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
                    title="Flip Board"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Next Move / Stage Button */}
              <button
                onClick={() => stepOverviewTo(overviewPly + 1)}
                disabled={overviewPly >= tokens.length}
                className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-500 disabled:opacity-50 text-stone-950 font-black text-sm transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <span>
                  {overviewPly >= tokens.length ? 'Line Overview Completed' : 'Next Move →'}
                </span>
                {overviewPly < tokens.length && <ChevronRight className="w-5 h-5" />}
              </button>

              {overviewPly >= tokens.length && (
                <button
                  onClick={() => {
                    onUnlockStage(selectedOpening.name, activeChapter.id, trainColor, 2);
                    setActiveTab('study');
                    resetStudy();
                  }}
                  className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer"
                >
                  <span>Proceed to Stage 2: Guided Study</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {/* Stepper / Controls in Guided Study Mode */}
          {activeTab === 'study' && (
            <div className="w-full max-w-[500px] flex flex-col gap-2">
              <div className="flex items-center justify-between p-2 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xs">
                <button
                  onClick={resetStudy}
                  className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-bold border border-stone-200 dark:border-stone-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-500" />
                  <span>Restart Study</span>
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    Green Hint Active
                  </span>
                  <button
                    onClick={() => setBoardOrientation(boardOrientation === 'w' ? 'b' : 'w')}
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
                    title="Flip Board"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {studyCompleted && (
                <button
                  onClick={() => {
                    onUnlockStage(selectedOpening.name, activeChapter.id, trainColor, 3);
                    setActiveTab('test');
                    resetTest();
                  }}
                  className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer"
                >
                  <span>Proceed to Stage 3: Mastery Test</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {/* Stepper / Controls in Mastery Test Mode */}
          {activeTab === 'test' && (
            <div className="w-full max-w-[500px] flex flex-col gap-2">
              <div className="flex items-center justify-between p-2 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xs">
                <button
                  onClick={resetTest}
                  className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-bold border border-stone-200 dark:border-stone-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-500" />
                  <span>Restart Test</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setActiveTab('study');
                      resetStudy();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
                  >
                    ← Back to Stage 2
                  </button>

                  <button
                    onClick={() => setBoardOrientation(boardOrientation === 'w' ? 'b' : 'w')}
                    className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
                    title="Flip Board"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {testFailed && (
                <button
                  onClick={resetTest}
                  className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-500 text-stone-950 font-black text-sm transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Try Again (Restart Test)</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Pedagogical Panel with Stage Tabs, Feedback & Moves (Hidden in Stage 3) */}
        <div className="flex flex-col gap-4 w-full">
          {/* 1. STAGES TAB SELECTOR */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-2.5 shadow-xs">
            <div className="flex items-center gap-2">
              {/* Stage 1: Overview & Watch */}
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'overview'
                    ? 'bg-amber-400 text-stone-950 shadow-xs'
                    : 'bg-stone-50 dark:bg-stone-800/60 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">1. Watch</span>
              </button>

              {/* Stage 2: Guided Study */}
              <button
                onClick={() => {
                  if (maxUnlockedStage >= 2) {
                    setActiveTab('study');
                    resetStudy();
                  }
                }}
                disabled={maxUnlockedStage < 2}
                className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  maxUnlockedStage < 2
                    ? 'opacity-40 cursor-not-allowed bg-stone-50 dark:bg-stone-800/40 text-stone-400'
                    : activeTab === 'study'
                    ? 'bg-amber-400 text-stone-950 shadow-xs cursor-pointer'
                    : 'bg-stone-50 dark:bg-stone-800/60 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 cursor-pointer'
                }`}
                title={
                  maxUnlockedStage < 2
                    ? 'Complete Stage 1 to unlock Guided Study'
                    : 'Stage 2: Guided Study'
                }
              >
                {maxUnlockedStage < 2 ? (
                  <Lock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                ) : (
                  <Compass className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="truncate">2. Study</span>
              </button>

              {/* Stage 3: Mastery Test */}
              <button
                onClick={() => {
                  if (maxUnlockedStage >= 3) {
                    setActiveTab('test');
                    resetTest();
                  }
                }}
                disabled={maxUnlockedStage < 3}
                className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  maxUnlockedStage < 3
                    ? 'opacity-40 cursor-not-allowed bg-stone-50 dark:bg-stone-800/40 text-stone-400'
                    : activeTab === 'test'
                    ? 'bg-amber-400 text-stone-950 shadow-xs cursor-pointer'
                    : 'bg-stone-50 dark:bg-stone-800/60 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 cursor-pointer'
                }`}
                title={
                  maxUnlockedStage < 3
                    ? 'Complete Stage 2 to unlock Mastery Test'
                    : 'Stage 3: Mastery Test'
                }
              >
                {maxUnlockedStage < 3 ? (
                  <Lock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                ) : (
                  <GraduationCap className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="truncate">3. Test</span>
              </button>
            </div>
          </div>

          {/* 2. REAL-TIME FEEDBACK BANNER */}
          {(activeTab === 'study' || activeTab === 'test') && (
            <div
              className={`p-4 rounded-2xl border flex items-start gap-3 shadow-xs transition-all ${
                (activeTab === 'study' ? studyFeedback.type : testFeedback.type) === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-200'
                  : (activeTab === 'study' ? studyFeedback.type : testFeedback.type) === 'error'
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-900 dark:text-rose-200'
                  : (activeTab === 'study' ? studyFeedback.type : testFeedback.type) === 'info'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-200'
                  : 'bg-stone-100 dark:bg-stone-900 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
              }`}
            >
              <div className="mt-0.5 shrink-0">
                {(activeTab === 'study' ? studyFeedback.type : testFeedback.type) === 'success' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                ) : (activeTab === 'study' ? studyFeedback.type : testFeedback.type) === 'error' ? (
                  <Zap className="w-5 h-5 text-rose-500" />
                ) : (
                  <Sparkles className="w-5 h-5 text-amber-500" />
                )}
              </div>
              <div className="space-y-0.5 flex-1">
                <span className="text-xs font-bold block">
                  {activeTab === 'study' ? 'Guided Study Feedback' : 'Mastery Test Feedback'}
                </span>
                <p className="text-xs leading-relaxed">
                  {activeTab === 'study' ? studyFeedback.message : testFeedback.message}
                </p>
              </div>
            </div>
          )}

          {/* 3. INTERACTIVE MOVE STRIP (STAGES 1 & 2 ONLY - COMPLETELY HIDDEN IN STAGE 3) */}
          {activeTab !== 'test' ? (
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold uppercase text-stone-500 dark:text-stone-400">
                  Theoretical Move Sequence
                </span>
                <span className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-bold">
                  {activeTab === 'overview'
                    ? `Move ${overviewPly}/${tokens.length}`
                    : `Move ${studyTree.mainline().length}/${tokens.length}`}
                </span>
              </div>

              {/* Move tokens strip */}
              <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                {tokens.map((san, idx) => {
                  const plyNum = idx + 1;
                  const isWhiteMove = plyNum % 2 !== 0;
                  const moveNumber = Math.ceil(plyNum / 2);

                  const isCurrent =
                    activeTab === 'overview'
                      ? overviewPly === plyNum
                      : studyTree.mainline().length === plyNum;

                  const isPast =
                    activeTab === 'overview'
                      ? overviewPly >= plyNum
                      : studyTree.mainline().length >= plyNum;

                  return (
                    <button
                      key={`${san}-${idx}`}
                      disabled={activeTab !== 'overview'}
                      onClick={() => {
                        if (activeTab === 'overview') {
                          stepOverviewTo(plyNum);
                        }
                      }}
                      className={`px-2 py-1 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1 ${
                        isCurrent
                          ? 'bg-amber-400 text-stone-950 font-bold shadow-xs scale-105'
                          : isPast
                          ? 'bg-stone-200 dark:bg-stone-800 text-stone-800 dark:text-stone-200'
                          : 'bg-stone-100 dark:bg-stone-900/60 text-stone-400 dark:text-stone-600'
                      } ${activeTab === 'overview' ? 'cursor-pointer hover:border-amber-400' : ''}`}
                    >
                      {isWhiteMove && <span className="opacity-60">{moveNumber}.</span>}
                      <span>{san}</span>
                    </button>
                  );
                })}
              </div>

              {/* Action button: Analyze in Board (Placed neatly with move sequence, omitted in Stage 3) */}
              <div className="pt-2 border-t border-stone-100 dark:border-stone-800 flex justify-end">
                <button
                  onClick={() => {
                    const tree = activeDisplayTree.clone();
                    onAnalyzeOpening(tree);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-bold transition-colors border border-stone-200 dark:border-stone-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <Swords className="w-3.5 h-3.5 text-amber-500" />
                  <span>Analyze in Board</span>
                </button>
              </div>
            </div>
          ) : (
            /* Stage 3 Memory Progress Card (Replaces Move Sequence strip) */
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <EyeOff className="w-4 h-4 text-amber-500" />
                  <span className="text-xs font-bold text-stone-900 dark:text-stone-100">
                    Blind Recall Challenge
                  </span>
                </div>
                <span className="text-xs font-mono font-bold text-stone-500 dark:text-stone-400">
                  {Math.min(testTree.mainline().length, tokens.length)} / {tokens.length} Plies
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-stone-100 dark:bg-stone-800 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-300 rounded-full"
                  style={{
                    width: `${Math.min(
                      100,
                      Math.round((testTree.mainline().length / tokens.length) * 100)
                    )}%`,
                  }}
                />
              </div>

              <p className="text-xs text-stone-500 dark:text-stone-400 leading-relaxed">
                All move sequences and visual hint arrows are strictly disabled to test your active
                memory recall. Play each theoretical move for{' '}
                <strong className="text-stone-800 dark:text-stone-200">
                  {trainColor === 'w' ? 'White' : 'Black'}
                </strong>{' '}
                without assistance.
              </p>
            </div>
          )}

          {/* 4. MASTER THEORETICAL PLANS & PAWN STRUCTURE CARD */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 shadow-xs space-y-3.5">
            <div className="space-y-1 border-b border-stone-100 dark:border-stone-800 pb-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-stone-900 dark:text-stone-100">
                <Target className="w-4 h-4 text-amber-500" />
                <span>Key Theoretical Plans for {trainColor === 'w' ? 'White' : 'Black'}</span>
              </div>
              <ul className="space-y-1 text-xs text-stone-600 dark:text-stone-400 pl-4 list-disc">
                {openingMeta.keyPlans.map((plan, i) => (
                  <li key={i}>{plan}</li>
                ))}
              </ul>
            </div>

            {/* Pawn Structure & Center Dynamics */}
            <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-950/60 border border-stone-200/80 dark:border-stone-800/80 space-y-1">
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-stone-800 dark:text-stone-200">
                <Shield className="w-3.5 h-3.5 text-emerald-500" />
                <span>Pawn Structure Dynamics</span>
              </div>
              <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
                {openingMeta.pawnStructure}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
