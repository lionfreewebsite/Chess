import React, { useState, useEffect } from 'react';
import {
  Puzzle as PuzzleIcon,
  Sparkles,
  Lightbulb,
  RotateCcw,
  Play,
  CheckCircle2,
  AlertCircle,
  Trophy,
  Flame,
  Zap,
  Sliders,
  ChevronRight,
  Search,
  ExternalLink,
  Target,
  Crown,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chessboard } from '../components/Chessboard/Chessboard';
import { GameTree } from '../engine/gameTree';
import {
  generateEnginePuzzle,
} from '../engine/puzzleGenerator';
import { globalAudio } from '../utils/audio';
import {
  Puzzle,
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  AnimationSpeed,
  UIThemeColor,
} from '../types/chess';
import { sqName, nameToSq, Chess, colorOf } from '../engine/chessRules';
import { getThemeConfig } from '../utils/themeColors';

interface PuzzlesViewProps {
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  soundEnabled: boolean;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  uiTheme?: UIThemeColor;
  onAnalyzePosition?: (tree: GameTree) => void;
}

type PuzzleFilterCategory =
  | 'all'
  | 'mate'
  | 'sacrifice'
  | 'fork'
  | 'pin'
  | 'skewer'
  | 'discovered'
  | 'trapped'
  | 'endgame';

export const PuzzlesView: React.FC<PuzzlesViewProps> = ({
  boardTheme,
  pieceTheme,
  pieceStyle,
  soundEnabled,
  animationEnabled = true,
  animationSpeed = 'normal',
  uiTheme = 'orange',
  onAnalyzePosition,
}) => {
  const themeCfg = getThemeConfig(uiTheme);
  const [rating, setRating] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('aperture_puzzle_rating') || '1200', 10);
    } catch {
      return 1200;
    }
  });

  const [initialPuzzle] = useState<Puzzle>(() =>
    generateEnginePuzzle({ targetRating: 1200 })
  );
  const [puzzlesList, setPuzzlesList] = useState<Puzzle[]>(() => [initialPuzzle]);
  const [currentPuzzle, setCurrentPuzzle] = useState<Puzzle>(() => initialPuzzle);
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  const [selectedCategory, setSelectedCategory] = useState<PuzzleFilterCategory>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const [tree, setTree] = useState<GameTree>(() => new GameTree(initialPuzzle.fen));
  const [solPlyIdx, setSolPlyIdx] = useState<number>(0);
  const [isSolved, setIsSolved] = useState<boolean>(false);
  const [isFailed, setIsFailed] = useState<boolean>(false);

  const [streak, setStreak] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string>('Find the winning continuation!');
  const [activeHintSq, setActiveHintSq] = useState<number | null>(null);

  // Filtered puzzle list
  const filteredPuzzles = puzzlesList.filter((p) => {
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'pin' && p.category !== 'pin' && p.category !== 'skewer') return false;
      if (selectedCategory !== 'pin' && p.category !== selectedCategory) return false;
    }
    if (selectedDifficulty !== 'all') {
      if (selectedDifficulty === 'beginner' && (p.rating < 800 || p.rating > 1199)) return false;
      if (selectedDifficulty === 'intermediate' && (p.rating < 1200 || p.rating > 1599)) return false;
      if (selectedDifficulty === 'advanced' && (p.rating < 1600 || p.rating > 1899)) return false;
      if (selectedDifficulty === 'master' && p.rating < 1900) return false;
    }
    return true;
  });

  // Load a puzzle
  const loadPuzzle = (puzzle: Puzzle, idx?: number) => {
    setCurrentPuzzle(puzzle);
    if (idx !== undefined) setCurrentIndex(idx);
    setTree(new GameTree(puzzle.fen));
    setSolPlyIdx(0);
    setIsSolved(false);
    setIsFailed(false);
    setActiveHintSq(null);
    setStatusMessage(`${puzzle.toMove === 'w' ? 'White' : 'Black'} to move.`);
  };

  const handleNextPuzzle = () => {
    // Generate a fresh dynamic puzzle matching active category/difficulty
    handleGenerateEnginePuzzle();
  };

  const handleGenerateEnginePuzzle = (cat?: PuzzleFilterCategory) => {
    setIsGenerating(true);
    setStatusMessage('⚡ Generating and verifying tactical puzzle with engine...');

    setTimeout(() => {
      const categoryToUse = cat || (selectedCategory === 'all' ? undefined : selectedCategory);
      let targetRating = rating;
      if (selectedDifficulty === 'beginner') targetRating = 1000;
      if (selectedDifficulty === 'intermediate') targetRating = 1400;
      if (selectedDifficulty === 'advanced') targetRating = 1750;
      if (selectedDifficulty === 'master') targetRating = 2100;

      const dynPuzzle = generateEnginePuzzle({
        category: categoryToUse,
        targetRating,
      });

      setPuzzlesList((prev) => [dynPuzzle, ...prev.slice(0, 19)]);
      loadPuzzle(dynPuzzle, 0);
      setIsGenerating(false);
      setStatusMessage(`✨ New Tactics: ${dynPuzzle.theme} (${dynPuzzle.rating} Elo)`);
    }, 120);
  };

  // Attempt move by user
  const handleAttemptMove = (from: number, to: number, promo?: string) => {
    if (isSolved || solPlyIdx >= currentPuzzle.solution.length) return;

    const fromName = sqName(from);
    const toName = sqName(to);
    const expected = currentPuzzle.solution[solPlyIdx];
    if (!expected) return;

    const expFrom = expected.slice(0, 2);
    const expTo = expected.slice(2, 4);
    const expPromo = expected.length > 4 ? expected[4].toUpperCase() : undefined;

    const isMatch =
      fromName === expFrom &&
      toName === expTo &&
      (!expPromo || (promo || 'Q').toUpperCase() === expPromo);

    if (isMatch) {
      // Correct user move
      tree.addMove(fromName, toName, promo || expPromo);
      if (soundEnabled) globalAudio.move();
      setTree(tree.clone());
      setActiveHintSq(null);

      const nextPly = solPlyIdx + 1;
      setSolPlyIdx(nextPly);

      if (nextPly >= currentPuzzle.solution.length) {
        handlePuzzleSolved();
      } else {
        setStatusMessage('✓ Good move! Calculating opponent response...');
        // Opponent plays automatic response
        setTimeout(() => {
          const opponentMove = currentPuzzle.solution[nextPly];
          if (opponentMove) {
            const oFrom = opponentMove.slice(0, 2);
            const oTo = opponentMove.slice(2, 4);
            const oPromo = opponentMove.length > 4 ? opponentMove[4].toUpperCase() : undefined;
            tree.addMove(oFrom, oTo, oPromo);
            if (soundEnabled) globalAudio.move();
            setTree(tree.clone());

            const afterOpponentPly = nextPly + 1;
            setSolPlyIdx(afterOpponentPly);
            if (afterOpponentPly >= currentPuzzle.solution.length) {
              handlePuzzleSolved();
            } else {
              setStatusMessage('Your turn: deliver the finishing tactical strike!');
            }
          }
        }, 400);
      }
    } else {
      // Incorrect move
      setIsFailed(true);
      if (soundEnabled) globalAudio.error();
      setStatusMessage('❌ Not the winning move. Try again or check the hint!');
    }
  };

  const handlePuzzleSolved = () => {
    setIsSolved(true);
    const gain = isFailed ? 5 : 15;
    const newRating = rating + gain;
    setRating(newRating);
    setStreak((prev) => (isFailed ? prev : prev + 1));
    try {
      localStorage.setItem('aperture_puzzle_rating', String(newRating));
    } catch {}

    if (soundEnabled) globalAudio.victory();
    confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 } });
    setStatusMessage(`🎉 Puzzle Solved! +${gain} Rating (${currentPuzzle.theme})`);
  };

  const handleHint = () => {
    const expected = currentPuzzle.solution[solPlyIdx];
    if (expected) {
      const fromSq = nameToSq(expected.slice(0, 2));
      setActiveHintSq(fromSq);
      setStatusMessage(`💡 Hint: Focus on the piece on square ${expected.slice(0, 2).toUpperCase()}.`);
    }
  };

  const handleShowSolution = () => {
    setIsFailed(true);
    setStreak(0);
    const replayTree = new GameTree(currentPuzzle.fen);

    let step = 0;
    const interval = setInterval(() => {
      if (step >= currentPuzzle.solution.length) {
        clearInterval(interval);
        setIsSolved(true);
        setStatusMessage(`Solution revealed: ${currentPuzzle.theme}.`);
        return;
      }
      const uci = currentPuzzle.solution[step];
      replayTree.addMove(uci.slice(0, 2), uci.slice(2, 4), uci.length > 4 ? uci[4].toUpperCase() : undefined);
      if (soundEnabled) globalAudio.move();
      setTree(replayTree.clone());
      step++;
    }, 600);
  };

  const lastMoveData = tree.current.uci
    ? { from: nameToSq(tree.current.uci.from), to: nameToSq(tree.current.uci.to) }
    : null;

  return (
    <div className="w-full flex-1 flex flex-col lg:grid lg:grid-cols-[310px_minmax(360px,1fr)_310px] gap-4 p-2 sm:p-4 max-w-7xl mx-auto">
      {/* Left Column: Tactical Categories & Generator */}
      <div className="flex flex-col gap-3 order-2 lg:order-1">
        {/* Rating & Streak Card */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-500">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono uppercase text-stone-500 dark:text-stone-400 tracking-wider">
                  Tactical Rating
                </span>
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 text-[9px] font-mono font-bold uppercase tracking-wider">
                  Beta
                </span>
              </div>
              <div className="text-xl font-mono font-black text-amber-500 dark:text-amber-400">{rating}</div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
            <Flame className="w-4 h-4 text-orange-500" />
            <span className="text-xs font-mono font-bold text-stone-800 dark:text-stone-200">Streak: {streak}</span>
          </div>
        </div>

        {/* Dynamic Procedural Generator Card */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-3.5 flex flex-col gap-2.5 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-stone-800 dark:text-stone-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Procedural Generator</span>
            </div>
            <span className="text-[10px] font-mono text-amber-600 dark:text-amber-400 font-semibold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
              Negamax
            </span>
          </div>

          <p className="text-[11px] text-stone-600 dark:text-stone-400">
            Generate unlimited unique positions verified by the engine.
          </p>

          <button
            id="generate-puzzle-btn"
            onClick={() => handleGenerateEnginePuzzle()}
            disabled={isGenerating}
            className={`w-full py-2.5 rounded-xl disabled:opacity-50 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99] ${themeCfg.primaryClass}`}
          >
            <Zap className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Synthesizing...' : 'Generate New Tactical Puzzle'}</span>
          </button>

          {/* Quick Generator Themes */}
          <div className="grid grid-cols-2 gap-1.5 pt-1">
            <button
              onClick={() => handleGenerateEnginePuzzle('mate')}
              className="px-2 py-1.5 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 text-[11px] font-mono text-stone-700 dark:text-stone-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Crown className="w-3 h-3 text-red-500" />
              <span>Checkmates</span>
            </button>
            <button
              onClick={() => handleGenerateEnginePuzzle('sacrifice')}
              className="px-2 py-1.5 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 text-[11px] font-mono text-stone-700 dark:text-stone-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Sparkles className={`w-3 h-3 ${themeCfg.textClass}`} />
              <span>Sacrifices</span>
            </button>
            <button
              onClick={() => handleGenerateEnginePuzzle('fork')}
              className="px-2 py-1.5 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 text-[11px] font-mono text-stone-700 dark:text-stone-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Target className="w-3 h-3 text-blue-500" />
              <span>Forks</span>
            </button>
            <button
              onClick={() => handleGenerateEnginePuzzle('endgame')}
              className="px-2 py-1.5 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 text-[11px] font-mono text-stone-700 dark:text-stone-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Play className="w-3 h-3 text-emerald-500" />
              <span>Endgames</span>
            </button>
          </div>
        </div>

        {/* Categories & Filter Bar */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-3.5 flex flex-col gap-2.5 shadow-xs">
          <div className="flex items-center justify-between pb-1.5 border-b border-stone-200 dark:border-stone-800">
            <span className="text-[11px] font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Filter Motif ({filteredPuzzles.length})
            </span>
          </div>

          {/* Theme Pills */}
          <div className="flex flex-wrap gap-1">
            {[
              { id: 'all', label: 'All' },
              { id: 'mate', label: 'Checkmates' },
              { id: 'sacrifice', label: 'Sacrifices' },
              { id: 'fork', label: 'Forks' },
              { id: 'pin', label: 'Pins & Skewers' },
              { id: 'discovered', label: 'Discovered' },
              { id: 'endgame', label: 'Endgames' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as PuzzleFilterCategory)}
                className={`px-2 py-1 rounded-md text-[11px] font-mono transition-colors cursor-pointer ${
                  selectedCategory === cat.id
                    ? `${themeCfg.activeTabClass} font-bold`
                    : 'bg-stone-50 dark:bg-stone-950 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 border border-stone-200 dark:border-stone-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Puzzle List Container */}
          <div className="h-44 lg:h-52 overflow-y-auto space-y-1.5 pr-1 mt-1">
            {filteredPuzzles.map((p, idx) => {
              const isSelected = p.id === currentPuzzle.id;
              return (
                <button
                  key={p.id}
                  onClick={() => loadPuzzle(p, idx)}
                  className={`w-full text-left p-2 rounded-lg border transition-all flex justify-between items-center cursor-pointer ${
                    isSelected
                      ? `${themeCfg.subtleBgClass} ${themeCfg.borderClass} shadow-xs`
                      : 'bg-stone-50 dark:bg-stone-950/60 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800/80'
                  }`}
                >
                  <div className="truncate pr-2">
                    <div className="text-xs font-bold text-stone-800 dark:text-stone-200 truncate">{p.theme}</div>
                    <span className="text-[10px] font-mono text-stone-500 dark:text-stone-400 capitalize">
                      {p.category || 'tactics'}
                    </span>
                  </div>
                  <span className={`text-xs font-mono font-semibold ${themeCfg.textClass} shrink-0`}>
                    {p.rating}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Center Column: Chessboard & Action Bar */}
      <div className="flex flex-col items-center gap-3 order-1 lg:order-2">
        {/* Puzzle Header Card */}
        <div className="w-full max-w-[640px] p-3 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl flex items-center justify-between shadow-xs">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100 truncate">{currentPuzzle.theme}</h2>
              <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${themeCfg.subtleBgClass} ${themeCfg.textClass} font-bold shrink-0`}>
                {currentPuzzle.rating} Elo
              </span>
              <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${themeCfg.subtleBgClass} ${themeCfg.textClass} border ${themeCfg.borderClass} font-bold uppercase shrink-0`}>
                Tactics
              </span>
            </div>
            <p className="text-[11px] text-stone-500 dark:text-stone-400 font-mono mt-0.5">
              {currentPuzzle.toMove === 'w' ? 'White' : 'Black'} to move & win
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            {onAnalyzePosition && (
              <button
                onClick={() => onAnalyzePosition(new GameTree(currentPuzzle.fen))}
                className="px-2.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1 cursor-pointer"
                title="Analyze in Engine"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Analyze</span>
              </button>
            )}
          </div>
        </div>

        {/* Board */}
        <Chessboard
          board={tree.chess.board}
          orientation={currentPuzzle.toMove}
          turn={tree.chess.turn}
          interactive={!isSolved}
          canSelect={(sq) => {
            if (isSolved) return false;
            const p = tree.chess.board[sq];
            return !!p && colorOf(p) === tree.chess.turn;
          }}
          getLegalTargets={(sq) => tree.chess.getLegalTargetsForSquare(sq)}
          onMove={(from, to, promo) => handleAttemptMove(from, to, promo)}
          lastMove={lastMoveData}
          hintSquare={activeHintSq}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          animationEnabled={animationEnabled}
          animationSpeed={animationSpeed}
          uiTheme={uiTheme}
        />

        {/* Centered Primary Action Bar: Next Puzzle in the Middle */}
        <div className="w-full max-w-[640px] flex items-center justify-center gap-2 pt-0.5">
          <button
            onClick={handleHint}
            disabled={isSolved}
            className="px-3 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-700 dark:text-stone-300 font-semibold text-xs border border-stone-200 dark:border-stone-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Lightbulb className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
            <span>Hint</span>
          </button>

          <button
            id="puzzle-next-btn-center"
            onClick={handleNextPuzzle}
            className={`px-6 py-2.5 rounded-xl active:scale-95 text-xs font-bold transition-all shadow-md flex items-center gap-2 cursor-pointer ${themeCfg.primaryClass}`}
          >
            <span>Next Puzzle</span>
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => loadPuzzle(currentPuzzle)}
            className="px-3 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 font-semibold text-xs border border-stone-200 dark:border-stone-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retry</span>
          </button>
        </div>

        {/* Feedback Bar */}
        <div
          className={`w-full max-w-[640px] p-3 rounded-xl border flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 text-xs shadow-md transition-all ${
            isSolved
              ? 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-500/60 text-emerald-800 dark:text-emerald-200'
              : isFailed
              ? 'bg-red-50 dark:bg-red-950/70 border-red-500/60 text-red-800 dark:text-red-200'
              : 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 text-stone-800 dark:text-stone-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {isSolved ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            ) : isFailed ? (
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            ) : (
              <Zap className="w-4 h-4 text-amber-500 shrink-0" />
            )}
            <span className="font-medium">{statusMessage}</span>
          </div>

          {/* Solution toggle */}
          <div className="flex items-center gap-1.5 justify-end shrink-0">
            <button
              onClick={handleShowSolution}
              disabled={isSolved}
              className="px-2.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-30 text-stone-700 dark:text-stone-300 font-semibold text-[11px] border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
            >
              Show Solution
            </button>
          </div>
        </div>
      </div>

      {/* Right Column: Tactical Tip & Solution Guide */}
      <div className="flex flex-col gap-3 order-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col gap-3 shadow-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-stone-200 dark:border-stone-800">
            <Target className="w-4 h-4 text-amber-500" />
            <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Tactical Objective
            </h3>
          </div>

          <p className="text-xs text-stone-700 dark:text-stone-300 leading-relaxed">
            {currentPuzzle.description || 'Calculate the winning continuation for this position.'}
          </p>

          <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800/80 space-y-1.5">
            <span className="text-[10px] font-mono uppercase text-amber-600 dark:text-amber-400 font-bold">
              Pro Tactics Guide
            </span>
            <ul className="text-xs text-stone-600 dark:text-stone-400 space-y-1 list-disc list-inside">
              <li>Check forcing moves: checks, captures, threats.</li>
              <li>Notice unprotected pieces and undefended back ranks.</li>
              <li>Exploit pins and overloaded defenders.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
