import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Activity,
  Bot,
  Sparkles,
  Sliders,
  ChevronRight,
  Heart,
  Upload,
  BookOpen,
  FileText,
  Check,
  AlertTriangle,
  Dices,
  Shuffle,
} from 'lucide-react';
import { Chessboard } from '../components/Chessboard/Chessboard';
import { CapturedPieces } from '../components/Chessboard/CapturedPieces';
import { GameTree } from '../engine/gameTree';
import { globalEngine } from '../engine/engineService';
import { BOT_PRESETS } from '../engine/botPresets';
import { globalAudio } from '../utils/audio';
import { generateChess960 } from '../engine/chess960';
import {
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  GameStatus,
  Square,
  SavedGame,
  PVLine,
  AnimationSpeed,
  UIThemeColor,
} from '../types/chess';
import { sqName, nameToSq, Chess } from '../engine/chessRules';
import { getThemeConfig } from '../utils/themeColors';

const BOT_POSITION_PRESETS = [
  {
    name: 'Sicilian Defense: Najdorf',
    category: 'Opening',
    fen: 'rnbqkb1r/pp2pppp/3p1n2/8/3NP3/8/PPP2PPP/RNBQKB1R w KQkq - 0 5',
    desc: 'One of the sharpest, most combative openings in chess.',
  },
  {
    name: "King's Gambit Accepted",
    category: 'Opening',
    fen: 'rnbqkbnr/pppp1ppp/8/4p3/4PP2/8/PPPP2PP/RNBQKBNR b KQkq - 0 2',
    desc: 'Romantic, aggressive attack from move two.',
  },
  {
    name: 'French Defense: Winawer',
    category: 'Opening',
    fen: 'rnbqk1nr/ppp2ppp/4p3/3p4/1b1PP3/2N5/PPP2PPP/R1BQKBNR w KQkq - 2 4',
    desc: 'Complex pawn structure and asymmetric play.',
  },
  {
    name: 'Sharp Tactical Middlegame',
    category: 'Middlegame',
    fen: 'r1b2rk1/pp3ppp/2n1pn2/q1bp4/2P5/2N1PN2/PP1BBPPP/R2Q1RK1 w - - 4 10',
    desc: 'Tense center with tactical counterchances for both sides.',
  },
  {
    name: 'Lucena Position (Rook Endgame)',
    category: 'Endgame',
    fen: '1K1k4/1P6/8/8/8/8/r7/2R5 w - - 0 1',
    desc: 'The fundamental winning technique for rook and pawn endgames.',
  },
  {
    name: 'Queen & Pawn Endgame',
    category: 'Endgame',
    fen: '8/6pk/5p1p/4p3/1q6/7P/P4PP1/3Q2K1 w - - 0 1',
    desc: 'Perpetual check threats vs outside passed pawn conversion.',
  },
  {
    name: 'Opposite-Colored Bishops',
    category: 'Endgame',
    fen: '8/4k3/4p1p1/3pP1P1/1b1P4/5K2/2B5/8 w - - 0 1',
    desc: 'Classic drawing vs winning technical fortress endgame.',
  },
];

interface BotMatchViewProps {
  onAnalyzeGame: (tree: GameTree) => void;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  soundEnabled: boolean;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  uiTheme?: UIThemeColor;
  isActive?: boolean;
}

export const BotMatchView: React.FC<BotMatchViewProps> = ({
  onAnalyzeGame,
  boardTheme,
  pieceTheme,
  pieceStyle,
  soundEnabled,
  animationEnabled = true,
  animationSpeed = 'normal',
  uiTheme = 'orange',
  isActive = true,
}) => {
  const themeCfg = getThemeConfig(uiTheme);
  const [tree, setTree] = useState<GameTree>(() => new GameTree());
  const [isCustomPosition, setIsCustomPosition] = useState<boolean>(false);
  const [isChess960Mode, setIsChess960Mode] = useState<boolean>(false);
  const [chess960Id, setChess960Id] = useState<number>(518);
  const [chess960Rank, setChess960Rank] = useState<string>('RNBQKBNR');

  const [whiteBot, setWhiteBot] = useState<string>('intermediate');
  const [whiteCustomDepth, setWhiteCustomDepth] = useState<number>(5);
  const [whiteCustomTimeMs, setWhiteCustomTimeMs] = useState<number>(1000);

  const [blackBot, setBlackBot] = useState<string>('intermediate');
  const [blackCustomDepth, setBlackCustomDepth] = useState<number>(5);
  const [blackCustomTimeMs, setBlackCustomTimeMs] = useState<number>(1000);

  const [moveDelayMs, setMoveDelayMs] = useState<number>(600);

  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [gameResult, setGameResult] = useState<GameStatus | null>(null);

  // Save Modal State
  const [saveModalOpen, setSaveModalOpen] = useState<boolean>(false);
  const [saveTitle, setSaveTitle] = useState<string>('');
  const [saveFavorite, setSaveFavorite] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  // Import Position Modal State
  const [importModalOpen, setImportModalOpen] = useState<boolean>(false);
  const [importTab, setImportTab] = useState<'presets' | 'chess960' | 'fen' | 'pgn'>('presets');
  const [fenInput, setFenInput] = useState<string>('');
  const [pgnInput, setPgnInput] = useState<string>('');
  const [importError, setImportError] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);

  // Cancellation and unmount ref to completely isolate bot match from other views
  const matchActiveRef = useRef<boolean>(false);
  const matchGenRef = useRef<number>(0);
  const initialDuelFenRef = useRef<string | null>(null);

  // Repetition draw toggle
  const [allowRepetitionDraw, setAllowRepetitionDraw] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('aperture_bot_allow_repetition');
      if (stored !== null) return stored === 'true';
    } catch {}
    return true;
  });

  // Load Chess960 position
  const handleLoadChess960 = (id?: number) => {
    try {
      stopMatch();
      const pos = generateChess960(id);
      setChess960Id(pos.id);
      setChess960Rank(pos.rankString);
      setIsChess960Mode(true);
      setIsCustomPosition(true);
      initialDuelFenRef.current = pos.fen;
      const newTree = new GameTree(pos.fen);
      setTree(newTree);
      setGameResult(null);
      setImportSuccess(`Chess960 #${pos.id} (${pos.rankString}) loaded!`);
      setTimeout(() => {
        setImportSuccess(null);
      }, 1500);
    } catch (err: any) {
      setImportError('Failed to generate Chess960: ' + err.message);
    }
  };

  // Auto record match to history
  const autoRecordBotMatch = useCallback((status: GameStatus, endTree: GameTree) => {
    try {
      if (endTree.mainline().length === 0) return;
      const whiteLabel =
        whiteBot === 'custom'
          ? `Custom Bot (D:${whiteCustomDepth}, ${whiteCustomTimeMs}ms)`
          : BOT_PRESETS[whiteBot]?.label || 'White Bot';
      const blackLabel =
        blackBot === 'custom'
          ? `Custom Bot (D:${blackCustomDepth}, ${blackCustomTimeMs}ms)`
          : BOT_PRESETS[blackBot]?.label || 'Black Bot';

      const pgn = endTree.toPGN({
        white: whiteLabel,
        black: blackLabel,
        result: status.result || '*',
        event: 'Aperture Bot Duel',
      });

      const record: SavedGame = {
        id: `match-bot-${Date.now()}`,
        title: `Bot Duel: ${whiteLabel} vs ${blackLabel}`,
        pgn,
        date: new Date().toISOString().slice(0, 10),
        result: status.result || '*',
        mode: 'bot-bot',
        category: 'bot',
        white: whiteLabel,
        black: blackLabel,
        favorite: false,
      };

      const existingRaw = localStorage.getItem('aperture_match_history');
      const existing = existingRaw ? JSON.parse(existingRaw) : [];
      localStorage.setItem('aperture_match_history', JSON.stringify([record, ...existing.slice(0, 99)]));
    } catch (e) {
      console.error('Failed to auto-record bot match:', e);
    }
  }, [whiteBot, blackBot, whiteCustomDepth, whiteCustomTimeMs, blackCustomDepth, blackCustomTimeMs]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      matchActiveRef.current = false;
      matchGenRef.current += 1;
      globalEngine.stop();
    };
  }, []);

  // When switching away from Bot Match mode, pause the match cleanly while preserving state
  useEffect(() => {
    if (!isActive && isRunning) {
      setIsRunning(false);
      setIsPaused(true);
      matchActiveRef.current = false;
      matchGenRef.current += 1;
      globalEngine.stop();
    }
  }, [isActive, isRunning]);

  const handleSaveBotGame = () => {
    try {
      const whiteLabel =
        whiteBot === 'custom'
          ? `Custom Bot (Depth ${whiteCustomDepth})`
          : BOT_PRESETS[whiteBot]?.label || 'White Bot';
      const blackLabel =
        blackBot === 'custom'
          ? `Custom Bot (Depth ${blackCustomDepth})`
          : BOT_PRESETS[blackBot]?.label || 'Black Bot';

      const pgn = tree.toPGN({
        white: whiteLabel,
        black: blackLabel,
        result: gameResult?.result || '*',
        event: 'Aperture Bot Duel',
      });
      const newSavedGame: SavedGame = {
        id: `bot-duel-${Date.now()}`,
        title: saveTitle.trim() || `Bot Duel: ${whiteLabel} vs ${blackLabel}`,
        pgn,
        date: new Date().toISOString().slice(0, 10),
        result: gameResult?.result || '*',
        mode: 'bot-bot',
        category: 'bot',
        white: whiteLabel,
        black: blackLabel,
        favorite: saveFavorite,
      };

      const existingRaw = localStorage.getItem('aperture_saved_games');
      const existing = existingRaw ? JSON.parse(existingRaw) : [];
      localStorage.setItem('aperture_saved_games', JSON.stringify([newSavedGame, ...existing]));
      setSavedSuccess(true);
      setTimeout(() => {
        setSaveModalOpen(false);
        setSavedSuccess(false);
      }, 1200);
    } catch (err) {
      console.error('Error saving bot game:', err);
    }
  };

  const runBotStep = useCallback(
    async (currentTree: GameTree, genId: number) => {
      if (!matchActiveRef.current || matchGenRef.current !== genId) return;

      const chess = currentTree.chess;
      const status = chess.status();
      const isRepetition = status.reason === 'threefold repetition' || status.reason === 'fivefold repetition';
      if (status.over && (allowRepetitionDraw || !isRepetition)) {
        setIsRunning(false);
        matchActiveRef.current = false;
        setGameResult(status);
        autoRecordBotMatch(status, currentTree);
        if (soundEnabled) {
          if (status.result === '1/2-1/2') globalAudio.draw();
          else if (status.reason === 'checkmate') globalAudio.defeat();
          else globalAudio.victory();
        }
        return;
      }

      const turn = chess.turn;
      const botKey = turn === 'w' ? whiteBot : blackBot;
      const isCustom = botKey === 'custom';
      const depth = isCustom
        ? turn === 'w'
          ? whiteCustomDepth
          : blackCustomDepth
        : BOT_PRESETS[botKey]?.depth || 5;
      const timeMs = isCustom
        ? turn === 'w'
          ? whiteCustomTimeMs
          : blackCustomTimeMs
        : BOT_PRESETS[botKey]?.timeMs || 1000;
      const cfg = BOT_PRESETS[botKey] || BOT_PRESETS.intermediate;

      let chosenUci = '';
      try {
        const fen = chess.fen();
        // Guard against engine worker timeouts
        const enginePromise = globalEngine.getBestMoveWithAlternatives(fen, {
          maxDepth: depth,
          timeMs,
          multipv: isCustom ? 2 : cfg.multipv,
        });

        // Timeout fallback if engine is unresponsive for more than requested time + 3s
        const timeoutPromise = new Promise<{ move: string; lines: PVLine[] }>((resolve) => {
          setTimeout(() => {
            const legals = chess.legalMoves();
            const fallback = legals[0];
            const fallbackUci = fallback
              ? `${sqName(fallback.from)}${sqName(fallback.to)}${fallback.promotion ? fallback.promotion.toLowerCase() : ''}`
              : '';
            resolve({ move: fallbackUci, lines: [] });
          }, Math.max(timeMs + 3000, 3500));
        });

        const res = await Promise.race([enginePromise, timeoutPromise]);
        if (!matchActiveRef.current || matchGenRef.current !== genId) return;

        chosenUci = res.move;
        // Blunder probability
        if (!isCustom && res.lines.length > 1 && cfg.blunderChance > 0 && Math.random() < cfg.blunderChance) {
          const alt = 1 + Math.floor(Math.random() * (res.lines.length - 1));
          if (res.lines[alt]?.pv?.[0]) chosenUci = res.lines[alt].pv[0];
        }

        // If repetition draw is disabled, proactively prevent cyclical repetitions
        if (!allowRepetitionDraw && chosenUci) {
          const testChess = chess.clone();
          const from = chosenUci.slice(0, 2);
          const to = chosenUci.slice(2, 4);
          const promo = chosenUci.length > 4 ? chosenUci[4].toUpperCase() : undefined;
          const testRes = testChess.move({ from, to, promotion: promo });
          if (testRes && (testChess.isThreefold() || testChess.isFivefold())) {
            let foundAlternative = false;
            if (res.lines && res.lines.length > 1) {
              for (let i = 1; i < res.lines.length; i++) {
                const altUci = res.lines[i]?.pv?.[0];
                if (altUci) {
                  const altChess = chess.clone();
                  const aFrom = altUci.slice(0, 2);
                  const aTo = altUci.slice(2, 4);
                  const aPromo = altUci.length > 4 ? altUci[4].toUpperCase() : undefined;
                  const aRes = altChess.move({ from: aFrom, to: aTo, promotion: aPromo });
                  if (aRes && !altChess.isThreefold() && !altChess.isFivefold()) {
                    chosenUci = altUci;
                    foundAlternative = true;
                    break;
                  }
                }
              }
            }
            if (!foundAlternative) {
              const legals = chess.legalMoves();
              for (const cand of legals) {
                const candUci = `${sqName(cand.from)}${sqName(cand.to)}${cand.promotion ? cand.promotion.toLowerCase() : ''}`;
                if (candUci !== chosenUci) {
                  const altChess = chess.clone();
                  const aRes = altChess.move({ from: sqName(cand.from), to: sqName(cand.to), promotion: cand.promotion });
                  if (aRes && !altChess.isThreefold() && !altChess.isFivefold()) {
                    chosenUci = candUci;
                    break;
                  }
                }
              }
            }
          }
        }
      } catch (err) {
        console.warn('Bot engine search error, picking fallback move:', err);
      }

      if (!matchActiveRef.current || matchGenRef.current !== genId) return;

      // Infallible fallback: If no valid UCI was produced, select from legal moves
      if (!chosenUci) {
        const legals = chess.legalMoves();
        if (legals.length > 0) {
          const m = legals[Math.floor(Math.random() * Math.min(legals.length, 3))];
          chosenUci = `${sqName(m.from)}${sqName(m.to)}${m.promotion ? m.promotion.toLowerCase() : ''}`;
        }
      }

      if (chosenUci) {
        const from = chosenUci.slice(0, 2);
        const to = chosenUci.slice(2, 4);
        const promo = chosenUci.length > 4 ? chosenUci[4].toUpperCase() : undefined;

        let moveRes = currentTree.addMove(from, to, promo);
        // If exact UCI format failed, try all valid legal moves to prevent freezing
        if (!moveRes) {
          const legals = currentTree.chess.legalMoves();
          for (const cand of legals) {
            const cFrom = sqName(cand.from);
            const cTo = sqName(cand.to);
            const cPromo = cand.promotion ? cand.promotion.toUpperCase() : undefined;
            moveRes = currentTree.addMove(cFrom, cTo, cPromo);
            if (moveRes) break;
          }
        }

        if (moveRes) {
          if (soundEnabled) {
            if (moveRes.san?.includes('+')) globalAudio.check();
            else if (moveRes.san?.includes('O-O')) globalAudio.castle();
            else if (moveRes.uci?.promotion || moveRes.san?.includes('=')) globalAudio.promote();
            else if (moveRes.san?.includes('x')) globalAudio.capture();
            else globalAudio.move();
          }
          setTree(currentTree.clone());

          const afterStatus = currentTree.chess.status();
          const isAfterRep = afterStatus.reason === 'threefold repetition' || afterStatus.reason === 'fivefold repetition';
          if (afterStatus.over && (allowRepetitionDraw || !isAfterRep)) {
            setIsRunning(false);
            matchActiveRef.current = false;
            setGameResult(afterStatus);
            autoRecordBotMatch(afterStatus, currentTree);
            if (soundEnabled) {
              if (afterStatus.result === '1/2-1/2') globalAudio.draw();
              else if (afterStatus.reason === 'checkmate') globalAudio.defeat();
              else globalAudio.victory();
            }
            return;
          }

          // Schedule next bot move
          setTimeout(() => {
            if (matchActiveRef.current && matchGenRef.current === genId) {
              runBotStep(currentTree, genId);
            }
          }, moveDelayMs);
          return;
        }
      }

      // If no moves can be played, terminate cleanly
      const finalStatus = currentTree.chess.status();
      setIsRunning(false);
      matchActiveRef.current = false;
      setGameResult(finalStatus);
      autoRecordBotMatch(finalStatus, currentTree);
    },
    [
      whiteBot,
      blackBot,
      whiteCustomDepth,
      whiteCustomTimeMs,
      blackCustomDepth,
      blackCustomTimeMs,
      moveDelayMs,
      soundEnabled,
      allowRepetitionDraw,
      autoRecordBotMatch,
    ]
  );

  const handleImportFen = () => {
    if (!fenInput.trim()) return;
    try {
      const fen = fenInput.trim();
      const chess = new Chess(fen);
      const newTree = new GameTree(fen);
      initialDuelFenRef.current = fen;
      setTree(newTree);
      setIsCustomPosition(true);
      setGameResult(null);
      setIsRunning(false);
      setIsPaused(false);
      matchActiveRef.current = false;
      matchGenRef.current += 1;
      globalEngine.stop();
      setImportSuccess('FEN position loaded successfully!');
      setTimeout(() => {
        setImportModalOpen(false);
        setImportSuccess(null);
        setFenInput('');
      }, 600);
    } catch (err: any) {
      setImportError('Invalid FEN: ' + err.message);
    }
  };

  const handleImportPgn = () => {
    if (!pgnInput.trim()) return;
    try {
      const newTree = new GameTree();
      newTree.loadPGN(pgnInput.trim());
      const fen = newTree.chess.fen();
      initialDuelFenRef.current = fen;
      setTree(newTree);
      setIsCustomPosition(true);
      setGameResult(null);
      setIsRunning(false);
      setIsPaused(false);
      matchActiveRef.current = false;
      matchGenRef.current += 1;
      globalEngine.stop();
      setImportSuccess('PGN game loaded successfully!');
      setTimeout(() => {
        setImportModalOpen(false);
        setImportSuccess(null);
        setPgnInput('');
      }, 600);
    } catch (err: any) {
      setImportError('Invalid PGN: ' + err.message);
    }
  };

  const handleSelectPreset = (fen: string) => {
    try {
      initialDuelFenRef.current = fen;
      const newTree = new GameTree(fen);
      setTree(newTree);
      setIsCustomPosition(true);
      setGameResult(null);
      setIsRunning(false);
      setIsPaused(false);
      matchActiveRef.current = false;
      matchGenRef.current += 1;
      globalEngine.stop();
      setImportSuccess('Preset position loaded!');
      setTimeout(() => {
        setImportModalOpen(false);
        setImportSuccess(null);
      }, 500);
    } catch (err: any) {
      setImportError('Error loading preset: ' + err.message);
    }
  };

  const handleResetToStartpos = () => {
    stopMatch();
    initialDuelFenRef.current = null;
    const newTree = new GameTree();
    setTree(newTree);
    setIsCustomPosition(false);
    setGameResult(null);
  };

  const startMatch = (fromCurrent: boolean | any = false) => {
    const isFromCurrent = typeof fromCurrent === 'boolean' ? fromCurrent : false;
    stopMatch();

    let activeTree: GameTree;
    if (isFromCurrent) {
      activeTree = tree.clone();
    } else if (initialDuelFenRef.current) {
      activeTree = new GameTree(initialDuelFenRef.current);
    } else {
      activeTree = new GameTree();
    }

    setTree(activeTree);
    setIsRunning(true);
    setIsPaused(false);
    setGameResult(null);
    matchActiveRef.current = true;
    const newGen = matchGenRef.current + 1;
    matchGenRef.current = newGen;

    runBotStep(activeTree, newGen);
  };

  const resumeMatch = () => {
    setIsRunning(true);
    setIsPaused(false);
    matchActiveRef.current = true;
    const newGen = matchGenRef.current + 1;
    matchGenRef.current = newGen;
    runBotStep(tree, newGen);
  };

  const handlePlayAgain = () => {
    stopMatch();
    const startFen = initialDuelFenRef.current;
    const newTree = startFen ? new GameTree(startFen) : new GameTree();
    setTree(newTree);
    setGameResult(null);
    setIsRunning(true);
    setIsPaused(false);
    matchActiveRef.current = true;
    const newGen = matchGenRef.current + 1;
    matchGenRef.current = newGen;

    runBotStep(newTree, newGen);
  };

  const togglePause = () => {
    if (isPaused) {
      setIsPaused(false);
      matchActiveRef.current = true;
      runBotStep(tree, matchGenRef.current);
    } else {
      setIsPaused(true);
      matchActiveRef.current = false;
      globalEngine.stop();
    }
  };

  const stopMatch = () => {
    if (isRunning && soundEnabled) {
      globalAudio.resign();
    }
    setIsRunning(false);
    setIsPaused(false);
    matchActiveRef.current = false;
    matchGenRef.current += 1;
    globalEngine.stop();
  };

  const lastMoveData = tree.current.uci
    ? { from: nameToSq(tree.current.uci.from), to: nameToSq(tree.current.uci.to) }
    : null;
  const checkSq = tree.chess.inCheck(tree.chess.turn)
    ? tree.chess.kingSquare(tree.chess.turn)
    : null;

  return (
    <div className="w-full flex-1 flex flex-col lg:grid lg:grid-cols-[280px_minmax(360px,1fr)_320px] gap-4 p-3 sm:p-5 max-w-7xl mx-auto">
      {/* Left Column: Moves list */}
      <div className="flex flex-col gap-3 order-2 lg:order-1">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col h-72 lg:h-[480px] shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
            <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Bot Game Moves
            </h3>
            <span className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-bold">
              Ply {tree.current.ply}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto py-2 font-mono text-xs space-y-1">
            {tree.mainline().length === 0 ? (
              <div className="h-full flex items-center justify-center text-stone-400 text-xs italic">
                Moves will appear during match
              </div>
            ) : (
              <div className="grid grid-cols-[36px_1fr_1fr] gap-x-2 gap-y-1 text-stone-800 dark:text-stone-300">
                {Array.from({ length: Math.ceil(tree.mainline().length / 2) }).map((_, rIdx) => {
                  const wNode = tree.mainline()[rIdx * 2];
                  const bNode = tree.mainline()[rIdx * 2 + 1];
                  return (
                    <React.Fragment key={`bot-move-${rIdx}`}>
                      <span className="text-stone-400 text-right">{rIdx + 1}.</span>
                      <span className="px-1.5 py-0.5">{wNode?.san}</span>
                      <span className="px-1.5 py-0.5">{bNode?.san || ''}</span>
                    </React.Fragment>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Center Column: Chessboard & Controls */}
      <div className="flex flex-col items-center gap-3 order-1 lg:order-2">
        {/* Match Header */}
        <div className="w-full max-w-[640px] p-3 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl flex flex-col gap-2 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-stone-700 dark:text-stone-300" />
                <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                  {BOT_PRESETS[whiteBot]?.label} (White)
                </span>
              </div>
              <span className="text-stone-400 font-mono text-xs font-bold">vs</span>
              <div className="flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                  {BOT_PRESETS[blackBot]?.label} (Black)
                </span>
              </div>
            </div>

            {/* Analyze match button */}
            <button
              id="bot-match-analyze-btn"
              onClick={() => onAnalyzeGame(tree)}
              disabled={tree.mainline().length === 0}
              className={`px-3 py-1.5 rounded-lg font-bold text-xs shadow-md transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer ${themeCfg.primaryClass}`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Analyze Game</span>
            </button>
          </div>

          {/* Captured Pieces Bar */}
          {(() => {
            const captured = tree.chess.getCapturedPieces();
            if (captured.w.length === 0 && captured.b.length === 0) return null;
            return (
              <div className="flex items-center justify-between pt-1.5 border-t border-stone-100 dark:border-stone-800 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] uppercase font-semibold text-stone-400">White captured:</span>
                  <CapturedPieces pieces={captured.w} pieceTheme={pieceTheme} pieceStyle={pieceStyle} />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] uppercase font-semibold text-stone-400">Black captured:</span>
                  <CapturedPieces pieces={captured.b} pieceTheme={pieceTheme} pieceStyle={pieceStyle} />
                </div>
              </div>
            );
          })()}
        </div>

        {/* Board */}
        <Chessboard
          board={tree.chess.board}
          orientation="w"
          turn={tree.chess.turn}
          interactive={false}
          lastMove={lastMoveData}
          checkSquare={checkSq}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          animationEnabled={animationEnabled}
          animationSpeed={animationSpeed}
          uiTheme={uiTheme}
        />

        {/* Playback Controls & Position Tools */}
        <div className="w-full max-w-[640px] flex flex-wrap items-center justify-center gap-2.5 pt-1">
          {!isRunning ? (
            <>
              {isPaused || (tree.ply > 0 && !gameResult) ? (
                <>
                  <button
                    id="bot-match-resume-btn"
                    onClick={resumeMatch}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Resume Duel</span>
                  </button>

                  <button
                    id="bot-match-restart-btn"
                    onClick={() => startMatch(isCustomPosition)}
                    className={`px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 ${themeCfg.primaryClass}`}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restart Match</span>
                  </button>
                </>
              ) : (
                <button
                  id="bot-match-start-btn"
                  onClick={() => startMatch(isCustomPosition)}
                  className={`px-5 py-2.5 rounded-xl font-bold text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95 ${themeCfg.primaryClass}`}
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{isCustomPosition ? 'Play from This Position' : 'Start Bot Duel'}</span>
                </button>
              )}

              <button
                id="bot-match-960-btn"
                onClick={() => handleLoadChess960()}
                className="px-3.5 py-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Generate and play random Chess960 position"
              >
                <Dices className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
                <span>🎲 Chess960</span>
              </button>

              <button
                id="bot-match-import-pos-btn"
                onClick={() => {
                  setImportError(null);
                  setImportSuccess(null);
                  setImportModalOpen(true);
                }}
                className="px-3.5 py-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
                <span>Import Position</span>
              </button>

              {isCustomPosition && (
                <button
                  onClick={handleResetToStartpos}
                  className="px-3 py-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300 text-xs font-medium border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1"
                  title="Reset back to standard starting position"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Startpos</span>
                </button>
              )}
            </>
          ) : (
            <>
              <button
                onClick={togglePause}
                className="px-4 py-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-300 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {isPaused ? <Play className="w-3.5 h-3.5 text-emerald-500" /> : <Pause className="w-3.5 h-3.5" />}
                <span>{isPaused ? 'Resume Duel' : 'Pause'}</span>
              </button>
              <button
                onClick={stopMatch}
                className="px-4 py-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-300 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Stop Duel</span>
              </button>
            </>
          )}
        </div>

        {/* Paused Match Notification Banner */}
        {isPaused && !gameResult && (
          <div className="w-full max-w-[640px] px-3.5 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-300 flex items-center justify-between text-xs animate-in fade-in duration-200">
            <span className="font-medium">
              ⏸️ Duel paused (Move {tree.ply}). Ready to resume whenever you wish.
            </span>
            <button
              onClick={resumeMatch}
              className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>Resume</span>
            </button>
          </div>
        )}

        {/* Custom Position / Chess960 Banner */}
        {isCustomPosition && !isRunning && !gameResult && (
          <div className={`w-full max-w-[640px] px-3.5 py-2 rounded-xl border flex items-center justify-between text-xs ${themeCfg.badgeBg} ${themeCfg.borderClass} ${themeCfg.textClass}`}>
            <span className="font-mono text-[11px] truncate">
              {isChess960Mode
                ? `🎲 Chess960 Position #${chess960Id} (${chess960Rank}) Loaded`
                : `📍 Custom Position Loaded (${tree.chess.turn === 'w' ? 'White' : 'Black'} to move)`}
            </span>
            <div className="flex items-center gap-2 shrink-0 ml-2">
              {isChess960Mode && (
                <button
                  onClick={() => handleLoadChess960()}
                  className="text-[11px] font-bold underline hover:opacity-80 flex items-center gap-1 cursor-pointer"
                >
                  <Shuffle className="w-3 h-3" />
                  <span>Randomize</span>
                </button>
              )}
              <button
                onClick={() => {
                  setImportError(null);
                  setImportSuccess(null);
                  setImportModalOpen(true);
                }}
                className="text-[11px] underline font-bold hover:opacity-80 shrink-0"
              >
                Change
              </button>
            </div>
          </div>
        )}

        {/* Game Finished Banner with Save Option */}
        {gameResult && (
          <div className={`w-full max-w-[640px] bg-white dark:bg-stone-900 border-2 rounded-xl p-4 shadow-xl flex flex-col items-center gap-3 animate-in zoom-in-95 duration-150 ${themeCfg.borderClass}`}>
            <div className="text-center">
              <h3 className={`text-base font-bold ${themeCfg.textClass}`}>
                {gameResult.result === '1-0'
                  ? 'White Wins Match!'
                  : gameResult.result === '0-1'
                  ? 'Black Wins Match!'
                  : 'Game Drawn'}
              </h3>
              <p className="text-xs text-stone-600 dark:text-stone-300 font-mono capitalize mt-0.5">
                {gameResult.reason} ({gameResult.result})
              </p>
            </div>

            <div className="flex flex-wrap gap-2 justify-center">
              <button
                id="bot-match-play-again-btn"
                onClick={handlePlayAgain}
                className={`px-4 py-2 rounded-lg font-bold text-xs shadow-md transition-colors cursor-pointer flex items-center gap-1.5 ${themeCfg.primaryClass}`}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Play Again</span>
              </button>
              <button
                onClick={() => setSaveModalOpen(true)}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Save to Saved Games</span>
              </button>
              <button
                onClick={() => onAnalyzeGame(tree)}
                className="px-4 py-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-semibold text-xs border border-stone-300 dark:border-stone-700 flex items-center gap-1.5 cursor-pointer"
              >
                <Activity className="w-4 h-4" />
                <span>Analyze & Review</span>
              </button>
            </div>
          </div>
        )}

        {/* Save Game Modal */}
        {saveModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-md w-full p-5 flex flex-col gap-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
                <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
                  Save Bot Duel to Archive
                </h3>
                <span className={`text-xs font-mono font-bold ${themeCfg.textClass}`}>
                  {gameResult?.result}
                </span>
              </div>

              {savedSuccess ? (
                <div className="py-6 text-center text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                  ✓ Bot Duel saved to archive!
                </div>
              ) : (
                <>
                  <div className="space-y-1">
                    <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
                      Match Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Bot Duel: Advanced vs Grandmaster"
                      value={saveTitle}
                      onChange={(e) => setSaveTitle(e.target.value)}
                      className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2 text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden"
                    />
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer text-xs text-stone-700 dark:text-stone-300">
                    <input
                      type="checkbox"
                      checked={saveFavorite}
                      onChange={(e) => setSaveFavorite(e.target.checked)}
                      className="rounded"
                    />
                    <span>Mark as Favorite (❤️ Saved in Favorites tab)</span>
                  </label>

                  <div className="flex justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
                    <button
                      onClick={() => setSaveModalOpen(false)}
                      className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold"
                    >
                      Dismiss
                    </button>
                    <button
                      onClick={handleSaveBotGame}
                      className={`px-4 py-1.5 rounded-lg text-stone-950 text-xs font-bold shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                    >
                      Save Match
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* Import Position Modal */}
        {importModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-lg w-full p-5 flex flex-col gap-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
                <div className="flex items-center gap-2">
                  <Upload className={`w-4 h-4 ${themeCfg.textClass}`} />
                  <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
                    Import Duel Position
                  </h3>
                </div>
                <button
                  onClick={() => setImportModalOpen(false)}
                  className="text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Modal Tabs */}
              <div className="flex flex-wrap gap-1 border-b border-stone-200 dark:border-stone-800 pb-2">
                {[
                  { id: 'presets', label: 'Presets', icon: BookOpen },
                  { id: 'chess960', label: 'Chess960', icon: Dices },
                  { id: 'fen', label: 'Paste FEN', icon: Sliders },
                  { id: 'pgn', label: 'Paste PGN', icon: FileText },
                ].map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setImportTab(tab.id as any);
                        setImportError(null);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                        importTab === tab.id
                          ? themeCfg.activeTabClass
                          : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Status / Notifications */}
              {importError && (
                <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{importError}</span>
                </div>
              )}
              {importSuccess && (
                <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2 font-bold">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{importSuccess}</span>
                </div>
              )}

              {/* Tab 1: Presets */}
              {importTab === 'presets' && (
                <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                  {BOT_POSITION_PRESETS.map((preset, idx) => (
                    <button
                      key={`preset-${idx}`}
                      onClick={() => handleSelectPreset(preset.fen)}
                      className="w-full text-left p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 hover:border-amber-400/60 dark:hover:border-amber-400/60 transition-all flex flex-col gap-1 cursor-pointer group"
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold text-stone-900 dark:text-stone-100 group-hover:${themeCfg.textClass} transition-colors`}>
                          {preset.name}
                        </span>
                        <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${themeCfg.badgeBg} ${themeCfg.textClass}`}>
                          {preset.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 dark:text-stone-400">
                        {preset.desc}
                      </p>
                    </button>
                  ))}
                </div>
              )}

              {/* Tab 2: Chess960 Generator */}
              {importTab === 'chess960' && (
                <div className="space-y-3">
                  <p className="text-xs text-stone-600 dark:text-stone-300">
                    Fischer Random Chess generates a verified, strictly legal randomized setup from all 960 permutations with bishops on opposite colors and king between rooks.
                  </p>
                  
                  <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-stone-800 dark:text-stone-200 font-mono">
                        Position #{chess960Id}
                      </span>
                      <span className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${themeCfg.badgeBg} ${themeCfg.textClass}`}>
                        {chess960Rank}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="0"
                        max="959"
                        value={chess960Id}
                        onChange={(e) => {
                          const id = +e.target.value;
                          const pos = generateChess960(id);
                          setChess960Id(pos.id);
                          setChess960Rank(pos.rankString);
                        }}
                        className="flex-1 accent-amber-500 cursor-pointer"
                      />
                      <button
                        onClick={() => {
                          const randId = Math.floor(Math.random() * 960);
                          const pos = generateChess960(randId);
                          setChess960Id(pos.id);
                          setChess960Rank(pos.rankString);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-stone-200 dark:bg-stone-800 hover:bg-stone-300 dark:hover:bg-stone-700 text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Shuffle className="w-3.5 h-3.5" />
                        <span>Random</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setImportModalOpen(false)}
                      className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        handleLoadChess960(chess960Id);
                        setImportModalOpen(false);
                      }}
                      className={`px-4 py-1.5 rounded-lg font-bold text-xs shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                    >
                      Load Chess960 Position
                    </button>
                  </div>
                </div>
              )}

              {/* Tab 3: FEN */}
              {importTab === 'fen' && (
                <div className="space-y-3">
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    Enter a valid Forsyth-Edwards Notation (FEN) string representing any board state:
                  </p>
                  <input
                    type="text"
                    value={fenInput}
                    onChange={(e) => setFenInput(e.target.value)}
                    placeholder="e.g. 8/4k3/4p1p1/3pP1P1/1b1P4/1N6/4K3/8 w - - 0 1"
                    className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden"
                  />
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setImportModalOpen(false)}
                      className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleImportFen}
                      className={`px-4 py-1.5 rounded-lg font-bold text-xs shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                    >
                      Load FEN Position
                    </button>
                  </div>
                </div>
              )}

              {/* Tab 4: PGN */}
              {importTab === 'pgn' && (
                <div className="space-y-3">
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    Paste Portable Game Notation (PGN) text to continue the match from the final move:
                  </p>
                  <textarea
                    value={pgnInput}
                    onChange={(e) => setPgnInput(e.target.value)}
                    placeholder="[Event &quot;...&quot;] 1. e4 e5 2. Nf3 ..."
                    className="w-full h-32 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden"
                  />
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setImportModalOpen(false)}
                      className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleImportPgn}
                      className={`px-4 py-1.5 rounded-lg font-bold text-xs shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                    >
                      Load PGN Game
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Right Column: Bot Configuration */}
      <div className="flex flex-col gap-3 order-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col gap-4 shadow-xs">
          <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300 pb-2 border-b border-stone-200 dark:border-stone-800">
            Match Config
          </h3>

          {/* White Bot */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
              White Engine Bot
            </label>
            <select
              value={whiteBot}
              disabled={isRunning}
              onChange={(e) => setWhiteBot(e.target.value)}
              className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2 text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden disabled:opacity-50"
            >
              {Object.entries(BOT_PRESETS).map(([k, p]) => (
                <option key={k} value={k}>
                  {p.label} (~{p.elo} Elo)
                </option>
              ))}
              <option value="custom">⚙️ Custom Parameters</option>
            </select>

            {whiteBot === 'custom' && (
              <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 space-y-2">
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-stone-600 dark:text-stone-300">
                    <span>Search Depth</span>
                    <span className={`font-bold ${themeCfg.textClass}`}>
                      Depth {whiteCustomDepth}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="12"
                    value={whiteCustomDepth}
                    disabled={isRunning}
                    onChange={(e) => setWhiteCustomDepth(+e.target.value)}
                    className={`w-full ${themeCfg.sliderAccent} disabled:opacity-50`}
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-stone-600 dark:text-stone-300">
                    <span>Think Time</span>
                    <span className={`font-bold ${themeCfg.textClass}`}>
                      {whiteCustomTimeMs}ms
                    </span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="4000"
                    step="100"
                    value={whiteCustomTimeMs}
                    disabled={isRunning}
                    onChange={(e) => setWhiteCustomTimeMs(+e.target.value)}
                    className={`w-full ${themeCfg.sliderAccent} disabled:opacity-50`}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Black Bot */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
              Black Engine Bot
            </label>
            <select
              value={blackBot}
              disabled={isRunning}
              onChange={(e) => setBlackBot(e.target.value)}
              className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2 text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden disabled:opacity-50"
            >
              {Object.entries(BOT_PRESETS).map(([k, p]) => (
                <option key={k} value={k}>
                  {p.label} (~{p.elo} Elo)
                </option>
              ))}
              <option value="custom">⚙️ Custom Parameters</option>
            </select>

            {blackBot === 'custom' && (
              <div className="p-2.5 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 space-y-2">
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-stone-600 dark:text-stone-300">
                    <span>Search Depth</span>
                    <span className={`font-bold ${themeCfg.textClass}`}>
                      Depth {blackCustomDepth}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="12"
                    value={blackCustomDepth}
                    disabled={isRunning}
                    onChange={(e) => setBlackCustomDepth(+e.target.value)}
                    className={`w-full ${themeCfg.sliderAccent} disabled:opacity-50`}
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-stone-600 dark:text-stone-300">
                    <span>Think Time</span>
                    <span className={`font-bold ${themeCfg.textClass}`}>
                      {blackCustomTimeMs}ms
                    </span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="4000"
                    step="100"
                    value={blackCustomTimeMs}
                    disabled={isRunning}
                    onChange={(e) => setBlackCustomTimeMs(+e.target.value)}
                    className={`w-full ${themeCfg.sliderAccent} disabled:opacity-50`}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Move Speed */}
          <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            <div className="flex justify-between text-[11px] font-mono text-stone-500 dark:text-stone-400">
              <span>Move Speed Delay</span>
              <span>{moveDelayMs}ms</span>
            </div>
            <input
              type="range"
              min="100"
              max="2000"
              step="100"
              value={moveDelayMs}
              onChange={(e) => setMoveDelayMs(+e.target.value)}
              className={`w-full ${themeCfg.sliderAccent}`}
            />
          </div>

          {/* Repetition Draw Toggle */}
          <div className="space-y-1.5 pt-2 border-t border-stone-200 dark:border-stone-800">
            <div className="flex justify-between items-center text-[11px] font-mono text-stone-500 dark:text-stone-400">
              <span className="font-semibold text-stone-800 dark:text-stone-200">Draw by Repetition:</span>
              <button
                id="bot-toggle-repetition-draw"
                onClick={() => {
                  const next = !allowRepetitionDraw;
                  setAllowRepetitionDraw(next);
                  try {
                    localStorage.setItem('aperture_bot_allow_repetition', String(next));
                  } catch {}
                }}
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold transition-all cursor-pointer ${
                  allowRepetitionDraw
                    ? themeCfg.activeTabClass
                    : 'bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-300 dark:hover:bg-stone-700'
                }`}
              >
                {allowRepetitionDraw ? 'ALLOWED' : 'DISABLED'}
              </button>
            </div>
            <p className="text-[10px] text-stone-500 dark:text-stone-400">
              {allowRepetitionDraw
                ? 'Standard 3-fold repetition triggers a draw as normal.'
                : 'Disabled: Bots actively avoid repeating moves and continue playing indefinitely.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
