import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  RotateCcw,
  Undo2,
  Pause,
  Play,
  Flag,
  Handshake,
  Activity,
  PlusCircle,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Bot,
  User,
  Clock,
  Sparkles,
  Dices,
  Upload,
  Bookmark,
  Check,
  AlertCircle,
} from 'lucide-react';
import { Chessboard } from '../components/Chessboard/Chessboard';
import { CapturedPieces } from '../components/Chessboard/CapturedPieces';
import { GameTree } from '../engine/gameTree';
import { globalEngine } from '../engine/engineService';
import { globalAudio } from '../utils/audio';
import { BOT_PRESETS } from '../engine/botPresets';
import { generateChess960, getRandomChess960, Chess960Position } from '../engine/chess960';
import {
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  GameStatus,
  Square,
  BotPresetConfig,
  SavedGame,
  SavedPosition,
  AnimationSpeed,
  DragRefreshRate,
  PlayVariantMode,
  UIThemeColor,
} from '../types/chess';
import { sqName, nameToSq, colorOf, Chess, START_FEN, fileOf, rankOf, sqOf } from '../engine/chessRules';
import { getThemeConfig } from '../utils/themeColors';

interface PlayViewProps {
  onAnalyzeGame: (tree: GameTree) => void;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  soundEnabled: boolean;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  dragRefreshRate?: DragRefreshRate;
  dragAndDropEnabled?: boolean;
  autoQueenEnabled?: boolean;
  showCoordinates?: boolean;
  showLegalMoves?: boolean;
  showCheckHighlight?: boolean;
  showLastMoveHighlight?: boolean;
  uiTheme?: UIThemeColor;
  isActive?: boolean;
}

export const PlayView: React.FC<PlayViewProps> = ({
  onAnalyzeGame,
  boardTheme,
  pieceTheme,
  pieceStyle,
  soundEnabled,
  animationEnabled = true,
  animationSpeed = 'normal',
  dragRefreshRate = '60fps',
  dragAndDropEnabled = true,
  autoQueenEnabled = false,
  showCoordinates = true,
  showLegalMoves = true,
  showCheckHighlight = true,
  showLastMoveHighlight = true,
  uiTheme,
  isActive = true,
}) => {
  const themeCfg = getThemeConfig(uiTheme);
  const [tree, setTree] = useState<GameTree>(() => new GameTree());
  const [gameMode, setGameMode] = useState<'human-bot' | 'human-human'>('human-bot');
  const [variantMode, setVariantMode] = useState<PlayVariantMode>('standard');
  const [chess960Pos, setChess960Pos] = useState<Chess960Position>(() => getRandomChess960());
  const [customFen, setCustomFen] = useState<string>(START_FEN);
  const [customPositionName, setCustomPositionName] = useState<string>('Custom Position');

  const [humanColor, setHumanColor] = useState<PieceColor | 'random'>('w');
  const [effectiveHumanColor, setEffectiveHumanColor] = useState<PieceColor>('w');
  const [botPreset, setBotPreset] = useState<string>('intermediate');
  const [customDepth, setCustomDepth] = useState<number>(5);
  const [customTimeMs, setCustomTimeMs] = useState<number>(1200);

  const [timePreset, setTimePreset] = useState<string>('600_0'); // 10+0 default
  const [timeControl, setTimeControl] = useState<number>(600); // 10 mins
  const [increment, setIncrement] = useState<number>(0); // 0 sec for standard 10m
  const [customMinutes, setCustomMinutes] = useState<number>(10);
  const [customIncrement, setCustomIncrement] = useState<number>(5);
  const [timers, setTimers] = useState<{ w: number; b: number }>({ w: 600000, b: 600000 });
  const [turnStartTs, setTurnStartTs] = useState<number>(Date.now());
  const [moveGen, setMoveGen] = useState<number>(0);
  const clockIntervalRef = useRef<any>(null);
  const lastTickRef = useRef<number>(Date.now());

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isBotThinking, setIsBotThinking] = useState<boolean>(false);
  const [boardOrientation, setBoardOrientation] = useState<PieceColor>('w');
  const [gameResult, setGameResult] = useState<GameStatus | null>(null);

  // Custom Position Import Modal
  const [importModalOpen, setImportModalOpen] = useState<boolean>(false);
  const [importTab, setImportTab] = useState<'fen' | 'pgn' | 'saved'>('fen');
  const [importInput, setImportInput] = useState<string>('');
  const [importError, setImportError] = useState<string | null>(null);

  const [savedPositions, setSavedPositions] = useState<SavedPosition[]>(() => {
    try {
      const data = localStorage.getItem('aperture_saved_positions');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });

  const [saveModalOpen, setSaveModalOpen] = useState<boolean>(false);
  const [saveTitle, setSaveTitle] = useState<string>('');
  const [saveFavorite, setSaveFavorite] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  // Auto-record match history to localStorage
  const autoRecordMatch = useCallback((status: GameStatus, endTree: GameTree) => {
    try {
      if (endTree.mainline().length === 0) return;
      const whiteName =
        gameMode === 'human-bot'
          ? effectiveHumanColor === 'w'
            ? 'Human'
            : `Aperture Bot (${BOT_PRESETS[botPreset]?.label || botPreset})`
          : 'Player 1';
      const blackName =
        gameMode === 'human-bot'
          ? effectiveHumanColor === 'b'
            ? 'Human'
            : `Aperture Bot (${BOT_PRESETS[botPreset]?.label || botPreset})`
          : 'Player 2';

      const eventTitle =
        variantMode === 'chess960'
          ? `Chess960 (SP #${chess960Pos.id})`
          : variantMode === 'custom'
          ? `Custom Setup (${customPositionName})`
          : gameMode === 'human-bot'
          ? `Casual vs ${BOT_PRESETS[botPreset]?.label || 'Bot'}`
          : 'Pass & Play Match';

      const pgn = endTree.toPGN({
        white: whiteName,
        black: blackName,
        result: status.result || '*',
        event: eventTitle,
      });

      const record: SavedGame = {
        id: `match-${Date.now()}`,
        title: `${whiteName} vs ${blackName}`,
        pgn,
        date: new Date().toISOString().slice(0, 10),
        result: status.result || '*',
        mode: gameMode,
        category: gameMode === 'human-bot' ? 'bot' : 'human',
        white: whiteName,
        black: blackName,
        favorite: false,
      };

      const existingRaw = localStorage.getItem('aperture_match_history');
      const existing = existingRaw ? JSON.parse(existingRaw) : [];
      localStorage.setItem('aperture_match_history', JSON.stringify([record, ...existing.slice(0, 99)]));
    } catch (e) {
      console.error('Failed to auto-record match:', e);
    }
  }, [gameMode, effectiveHumanColor, botPreset, variantMode, chess960Pos, customPositionName]);

  const handleSaveGame = () => {
    try {
      const whiteName =
        gameMode === 'human-bot'
          ? effectiveHumanColor === 'w'
            ? 'Human'
            : `Aperture Bot (${BOT_PRESETS[botPreset]?.label || botPreset})`
          : 'Player 1';
      const blackName =
        gameMode === 'human-bot'
          ? effectiveHumanColor === 'b'
            ? 'Human'
            : `Aperture Bot (${BOT_PRESETS[botPreset]?.label || botPreset})`
          : 'Player 2';

      const pgn = tree.toPGN({
        white: whiteName,
        black: blackName,
        result: gameResult?.result || '*',
        event:
          variantMode === 'chess960'
            ? `Chess960 (SP #${chess960Pos.id})`
            : variantMode === 'custom'
            ? `Custom Setup (${customPositionName})`
            : gameMode === 'human-bot'
            ? 'Casual vs Engine Bot'
            : 'Pass & Play Match',
      });

      const newSavedGame: SavedGame = {
        id: `game-${Date.now()}`,
        title:
          saveTitle.trim() ||
          `${gameMode === 'human-bot' ? 'Match vs Bot' : 'Two Player Match'} (${new Date().toLocaleDateString()})`,
        pgn,
        date: new Date().toISOString().slice(0, 10),
        result: gameResult?.result || '*',
        mode: gameMode,
        category: gameMode === 'human-bot' ? 'bot' : 'human',
        white: whiteName,
        black: blackName,
        favorite: saveFavorite,
      };

      const existingRaw = localStorage.getItem('aperture_saved_games');
      const existing = existingRaw ? JSON.parse(existingRaw) : [];
      localStorage.setItem('aperture_saved_games', JSON.stringify([newSavedGame, ...existing]));
      setSavedSuccess(true);
      setTimeout(() => {
        setSaveModalOpen(false);
        setSavedSuccess(false);
      }, 1200);
    } catch (err) {
      console.error('Error saving game:', err);
    }
  };

  // Sound triggers
  const playSoundForMove = (res: any, status: GameStatus) => {
    if (!soundEnabled) return;
    if (status.over) {
      if (status.reason === 'resignation') {
        globalAudio.resign();
      } else if (status.result === '1/2-1/2') {
        globalAudio.draw();
      } else if (gameMode === 'human-human') {
        // Winning sound for both White and Black in Human vs Human
        globalAudio.victory();
      } else if (gameMode === 'human-bot') {
        const isHumanWinner =
          (status.result === '1-0' && effectiveHumanColor === 'w') ||
          (status.result === '0-1' && effectiveHumanColor === 'b');
        if (isHumanWinner) {
          globalAudio.victory();
        } else {
          // Checkmate loss or timeout loss against bot
          globalAudio.defeat();
        }
      } else {
        globalAudio.victory();
      }
    } else if (res.san && res.san.includes('+')) {
      globalAudio.check();
    } else if (res.castle) {
      globalAudio.castle();
    } else if (res.promotion) {
      globalAudio.promote();
    } else if (res.capture) {
      globalAudio.capture();
    } else {
      globalAudio.move();
    }
  };

  // Handle End Game
  const endGame = useCallback((status: GameStatus) => {
    setIsPlaying(false);
    setIsBotThinking(false);
    globalEngine.stop();
    if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
    setGameResult(status);
    autoRecordMatch(status, tree);
  }, [tree, autoRecordMatch]);

  // Clocks Loop - Active Real-Time Ticking
  useEffect(() => {
    if (!isPlaying || isPaused || timeControl === 0) return;

    lastTickRef.current = Date.now();
    clockIntervalRef.current = setInterval(() => {
      const now = Date.now();
      const delta = now - lastTickRef.current;
      lastTickRef.current = now;

      setTimers((prev) => {
        const side = tree.chess.turn;
        const newRemaining = Math.max(0, prev[side] - delta);

        if (newRemaining <= 0) {
          if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
          const timeoutStatus: GameStatus = {
            over: true,
            result: side === 'w' ? '0-1' : '1-0',
            reason: 'timeout',
          };
          if (soundEnabled) {
            if (gameMode === 'human-human') {
              globalAudio.victory();
            } else {
              const isHumanWinner =
                (side === 'b' && effectiveHumanColor === 'w') ||
                (side === 'w' && effectiveHumanColor === 'b');
              if (isHumanWinner) {
                globalAudio.victory();
              } else {
                globalAudio.defeat();
              }
            }
          }
          endGame(timeoutStatus);
          return { ...prev, [side]: 0 };
        }
        return { ...prev, [side]: newRemaining };
      });
    }, 100);

    return () => {
      if (clockIntervalRef.current) clearInterval(clockIntervalRef.current);
    };
  }, [isPlaying, isPaused, tree.chess.turn, timeControl, endGame, gameMode, effectiveHumanColor, soundEnabled]);

  // Trigger Bot Move
  const triggerBotMove = async (currentTree: GameTree, genId: number) => {
    setIsBotThinking(true);
    const cfg = BOT_PRESETS[botPreset] || BOT_PRESETS.intermediate;
    const depth = botPreset === 'custom' ? customDepth : cfg.depth;
    const timeMs = botPreset === 'custom' ? customTimeMs : cfg.timeMs;

    try {
      const fen = currentTree.chess.fen();
      const res = await globalEngine.getBestMoveWithAlternatives(fen, {
        maxDepth: depth,
        timeMs,
        multipv: cfg.multipv,
      });

      if (!isPlaying || currentTree.chess.fen() !== fen) return;

      let chosenUci = res.move;
      // Blunder probability for lower levels
      if (res.lines.length > 1 && cfg.blunderChance > 0 && Math.random() < cfg.blunderChance) {
        const altIdx = 1 + Math.floor(Math.random() * (res.lines.length - 1));
        if (res.lines[altIdx]?.pv?.[0]) chosenUci = res.lines[altIdx].pv[0];
      }

      if (chosenUci) {
        const from = chosenUci.slice(0, 2);
        const to = chosenUci.slice(2, 4);
        const promo = chosenUci.length > 4 ? chosenUci[4].toUpperCase() : undefined;

        const moveRes = currentTree.addMove(from, to, promo);
        if (moveRes) {
          const status = currentTree.chess.status();
          playSoundForMove(moveRes, status);
          lastTickRef.current = Date.now();
          // Add increment to bot
          const botSide = currentTree.chess.turn === 'w' ? 'b' : 'w';
          setTimers((prev) => ({
            ...prev,
            [botSide]: prev[botSide] + increment * 1000,
          }));
          setTree(currentTree.clone());
          setTurnStartTs(Date.now());
          if (status.over) endGame(status);
        }
      }
    } catch (err) {
      console.error('[Bot Error]', err);
    } finally {
      setIsBotThinking(false);
    }
  };

  const startNewGame = useCallback(() => {
    globalEngine.stop();
    const newGen = moveGen + 1;
    setMoveGen(newGen);
    setIsBotThinking(false);

    let startFen = START_FEN;
    if (variantMode === 'chess960') {
      const fresh960 = getRandomChess960();
      setChess960Pos(fresh960);
      startFen = fresh960.fen;
    } else if (variantMode === 'custom') {
      startFen = customFen;
    }

    const newTree = new GameTree(startFen);
    setTree(newTree);

    let assignedColor: PieceColor = 'w';
    if (gameMode === 'human-bot') {
      if (humanColor === 'random') {
        assignedColor = Math.random() < 0.5 ? 'w' : 'b';
      } else {
        assignedColor = humanColor;
      }
    }
    setEffectiveHumanColor(assignedColor);
    setBoardOrientation(assignedColor);

    const effectiveBaseSeconds = timePreset === 'custom' ? customMinutes * 60 : timeControl;
    const effectiveIncrement = timePreset === 'custom' ? customIncrement : increment;

    const initialMs = effectiveBaseSeconds > 0 ? effectiveBaseSeconds * 1000 : 0;
    setTimers({ w: initialMs, b: initialMs });
    lastTickRef.current = Date.now();
    setTurnStartTs(Date.now());
    setIsPlaying(true);
    setIsPaused(false);
    setGameResult(null);

    globalAudio.gameStart();

    // If bot plays the first side to move, trigger bot move immediately
    if (gameMode === 'human-bot' && newTree.chess.turn !== assignedColor) {
      triggerBotMove(newTree, newGen);
    }
  }, [
    gameMode,
    variantMode,
    chess960Pos,
    customFen,
    humanColor,
    timePreset,
    timeControl,
    increment,
    customMinutes,
    customIncrement,
    moveGen,
    botPreset,
    customDepth,
    customTimeMs,
  ]);

  // Execute a Move
  const applyMove = useCallback(
    (fromName: string, toName: string, promo?: string) => {
      if (!isPlaying || isPaused || isBotThinking) return;

      const currentTurn = tree.chess.turn;
      const res = tree.addMove(fromName, toName, promo);
      if (!res) return;

      lastTickRef.current = Date.now();
      setTimers((prev) => ({
        ...prev,
        [currentTurn]: prev[currentTurn] + increment * 1000,
      }));
      setTurnStartTs(Date.now());

      const status = tree.chess.status();
      playSoundForMove(res, status);
      setTree(tree.clone());

      if (status.over) {
        endGame(status);
      } else if (gameMode === 'human-bot' && tree.chess.turn !== effectiveHumanColor) {
        triggerBotMove(tree, moveGen);
      }
    },
    [isPlaying, isPaused, isBotThinking, tree, increment, gameMode, effectiveHumanColor, moveGen, endGame]
  );

  // Undo Move
  const handleUndo = () => {
    if (!isPlaying || isBotThinking) return;
    globalEngine.stop();
    const nextGen = moveGen + 1;
    setMoveGen(nextGen);

    const steps = gameMode === 'human-bot' ? (tree.ply === 1 ? 1 : 2) : 1;
    for (let i = 0; i < steps; i++) {
      if (tree.current.parent) tree.deleteNode(tree.current);
    }
    const cloned = tree.clone();
    setTree(cloned);
    lastTickRef.current = Date.now();
    setTurnStartTs(Date.now());

    // If after undo it's the bot's turn, trigger bot move
    if (gameMode === 'human-bot' && cloned.chess.turn !== effectiveHumanColor) {
      triggerBotMove(cloned, nextGen);
    }
  };

  const handleResign = () => {
    if (!isPlaying) return;
    const resignResult: GameStatus = {
      over: true,
      result: effectiveHumanColor === 'w' ? '0-1' : '1-0',
      reason: 'resignation',
    };
    if (soundEnabled) globalAudio.resign();
    endGame(resignResult);
  };

  const handleOfferDraw = () => {
    if (!isPlaying) return;
    const drawResult: GameStatus = {
      over: true,
      result: '1/2-1/2',
      reason: 'draw by agreement',
    };
    if (soundEnabled) globalAudio.draw();
    endGame(drawResult);
  };

  // Format Clock string
  const formatTime = (ms: number) => {
    const totalSec = Math.max(0, Math.ceil(ms / 1000));
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };

  // Process Import Position
  const handleProcessImport = () => {
    setImportError(null);
    const raw = importInput.trim();
    if (!raw) {
      setImportError('Please enter FEN or PGN text.');
      return;
    }

    if (importTab === 'fen') {
      try {
        const c = new Chess(raw);
        setCustomFen(c.fen());
        setCustomPositionName('Imported FEN');
        setImportModalOpen(false);
        setImportInput('');
      } catch (err: any) {
        setImportError(err.message || 'Invalid FEN string.');
      }
    } else {
      try {
        const parsedTree = GameTree.fromPGN(raw);
        const endFen = parsedTree.chess.fen();
        const c = new Chess(endFen);
        setCustomFen(c.fen());
        setCustomPositionName('Imported PGN');
        setImportModalOpen(false);
        setImportInput('');
      } catch (err: any) {
        setImportError(err.message || 'Invalid PGN format.');
      }
    }
  };

  const chess = tree.chess;
  const lastMoveData = tree.current.uci
    ? { from: nameToSq(tree.current.uci.from), to: nameToSq(tree.current.uci.to) }
    : null;
  const checkSq = chess.inCheck(chess.turn) ? chess.kingSquare(chess.turn) : null;
  const captured = chess.getCapturedPieces();
  const whiteMat = chess.material('w');
  const blackMat = chess.material('b');
  const matDiff = whiteMat - blackMat;

  const topIsBlack = boardOrientation === 'w';
  const topColor: PieceColor = topIsBlack ? 'b' : 'w';
  const bottomColor: PieceColor = topIsBlack ? 'w' : 'b';

  return (
    <div className="w-full flex-1 flex flex-col lg:grid lg:grid-cols-[280px_minmax(360px,1fr)_320px] gap-4 p-3 sm:p-5 max-w-7xl mx-auto">
      {/* Left Column: Move History & Game Tree */}
      <div className="flex flex-col gap-3 order-2 lg:order-1">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-3 flex flex-col gap-3 h-[280px] lg:h-[580px] shadow-xs">
          <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-800 pb-2">
            <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Move Notation
            </h3>
            <span className="text-[11px] font-mono text-stone-500 dark:text-stone-400">
              Ply: {tree.current.ply}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto pr-1">
            {tree.mainline().length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-stone-400 text-xs text-center p-4">
                <Sparkles className="w-6 h-6 mb-2 text-amber-500/60" />
                <p className="font-semibold text-stone-600 dark:text-stone-300">No moves made yet</p>
                <p className="text-[11px] mt-0.5">Start match or play moves on the board</p>
              </div>
            ) : (
              <div className="grid grid-cols-[28px_1fr_1fr] gap-x-1 gap-y-0.5 text-xs font-mono">
                {Array.from({ length: Math.ceil(tree.mainline().length / 2) }).map((_, i) => {
                  const moveNum = i + 1;
                  const mainline = tree.mainline();
                  const wNode = mainline[i * 2];
                  const bNode = mainline[i * 2 + 1];

                  const isWActive = tree.current.id === wNode?.id;
                  const isBActive = tree.current.id === bNode?.id;

                  return (
                    <React.Fragment key={moveNum}>
                      <span className="text-stone-400 dark:text-stone-500 py-1 text-right pr-1 select-none">
                        {moveNum}.
                      </span>
                      <button
                        onClick={() => {
                          tree.goTo(wNode.id);
                          setTree(tree.clone());
                        }}
                        className={`text-left px-2 py-1 rounded transition-colors truncate cursor-pointer ${
                          isWActive
                            ? `${themeCfg.activeTabClass}`
                            : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                        }`}
                      >
                        {wNode?.san}
                      </button>
                      {bNode ? (
                        <button
                          onClick={() => {
                            tree.goTo(bNode.id);
                            setTree(tree.clone());
                          }}
                          className={`text-left px-2 py-1 rounded transition-colors truncate cursor-pointer ${
                            isBActive
                              ? `${themeCfg.activeTabClass}`
                              : 'hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                          }`}
                        >
                          {bNode?.san}
                        </button>
                      ) : (
                        <span />
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            )}
          </div>

          {/* Navigation Controls */}
          <div className="pt-2 border-t border-stone-200 dark:border-stone-800 flex items-center justify-center gap-2">
            <button
              onClick={() => {
                tree.toStart();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="First Move"
            >
              <ChevronsLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                tree.back();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Previous Move"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                tree.forward();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Next Move"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                tree.toEnd();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Latest Move"
            >
              <ChevronsRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Center Column: Chessboard & Clocks */}
      <div className="flex flex-col items-center gap-3 order-1 lg:order-2">
        {/* Top Player Card */}
        <div className="w-full max-w-[640px] flex items-center justify-between p-2.5 bg-white dark:bg-stone-900/90 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-stone-100 dark:bg-stone-800 flex items-center justify-center text-stone-800 dark:text-stone-300 font-bold border border-stone-200 dark:border-stone-700">
              {gameMode === 'human-bot' && topColor !== effectiveHumanColor ? (
                <Bot className="w-4 h-4 text-amber-500" />
              ) : (
                <User className="w-4 h-4 text-stone-700 dark:text-stone-300" />
              )}
            </div>
            <div>
              <div className="text-xs font-bold text-stone-900 dark:text-stone-200 flex items-center gap-1.5">
                {gameMode === 'human-bot' && topColor !== effectiveHumanColor ? (
                  <span>
                    Aperture Bot (
                    {BOT_PRESETS[botPreset]?.label || 'Intermediate'})
                  </span>
                ) : (
                  <span>{topColor === 'w' ? 'White' : 'Black'}</span>
                )}
                {isBotThinking && topColor !== effectiveHumanColor && (
                  <span className="text-[10px] text-amber-500 dark:text-amber-400 font-mono animate-pulse">
                    Thinking...
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-stone-500 dark:text-stone-400">
                <span className="text-[10px] uppercase font-semibold">Captured:</span>
                <CapturedPieces
                  pieces={topColor === 'w' ? captured.w : captured.b}
                  pieceTheme={pieceTheme}
                  pieceStyle={pieceStyle}
                />
                {topColor === 'w' && matDiff > 0 && (
                  <span className="text-emerald-500 dark:text-emerald-400 font-mono font-bold ml-1">+{matDiff}</span>
                )}
                {topColor === 'b' && matDiff < 0 && (
                  <span className="text-emerald-500 dark:text-emerald-400 font-mono font-bold ml-1">+{Math.abs(matDiff)}</span>
                )}
              </div>
            </div>
          </div>

          {timeControl > 0 && (
            <div
              className={`px-3 py-1.5 rounded-lg font-mono font-bold text-base flex items-center gap-1.5 ${
                chess.turn === topColor && isPlaying
                  ? 'bg-amber-400/20 text-amber-800 dark:text-amber-300 border border-amber-400/40 shadow-xs'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{formatTime(timers[topColor])}</span>
            </div>
          )}
        </div>

        {/* Board */}
        <Chessboard
          board={chess.board}
          orientation={boardOrientation}
          turn={chess.turn}
          interactive={isPlaying && !isPaused && !isBotThinking}
          canSelect={(sq) => {
            if (!isPlaying || isPaused || isBotThinking) return false;
            const p = chess.board[sq];
            if (!p || colorOf(p) !== chess.turn) return false;
            if (gameMode === 'human-bot' && chess.turn !== effectiveHumanColor) return false;
            return true;
          }}
          getLegalTargets={(sq) => chess.getLegalTargetsForSquare(sq)}
          onMove={(from, to, promo) => applyMove(sqName(from), sqName(to), promo)}
          lastMove={lastMoveData}
          checkSquare={checkSq}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          animationEnabled={animationEnabled}
          animationSpeed={animationSpeed}
          dragRefreshRate={dragRefreshRate}
          dragAndDropEnabled={dragAndDropEnabled}
          autoQueenEnabled={autoQueenEnabled}
          showCoordinates={showCoordinates}
          showLegalMoves={showLegalMoves}
          showCheckHighlight={showCheckHighlight}
          showLastMoveHighlight={showLastMoveHighlight}
          uiTheme={uiTheme}
        />

        {/* Bottom Player Card */}
        <div className="w-full max-w-[640px] flex items-center justify-between p-2.5 bg-white dark:bg-stone-900/90 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-stone-100 dark:bg-stone-800 flex items-center justify-center text-stone-800 dark:text-stone-300 font-bold border border-stone-200 dark:border-stone-700">
              <User className="w-4 h-4 text-stone-700 dark:text-stone-300" />
            </div>
            <div>
              <div className="text-xs font-bold text-stone-900 dark:text-stone-200">
                {gameMode === 'human-bot' && bottomColor === effectiveHumanColor
                  ? 'You (Human)'
                  : bottomColor === 'w'
                  ? 'White'
                  : 'Black'}
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-stone-500 dark:text-stone-400">
                <span className="text-[10px] uppercase font-semibold">Captured:</span>
                <CapturedPieces
                  pieces={bottomColor === 'w' ? captured.w : captured.b}
                  pieceTheme={pieceTheme}
                  pieceStyle={pieceStyle}
                />
                {bottomColor === 'w' && matDiff > 0 && (
                  <span className="text-emerald-500 dark:text-emerald-400 font-mono font-bold ml-1">+{matDiff}</span>
                )}
                {bottomColor === 'b' && matDiff < 0 && (
                  <span className="text-emerald-500 dark:text-emerald-400 font-mono font-bold ml-1">+{Math.abs(matDiff)}</span>
                )}
              </div>
            </div>
          </div>

          {timeControl > 0 && (
            <div
              className={`px-3 py-1.5 rounded-lg font-mono font-bold text-base flex items-center gap-1.5 ${
                chess.turn === bottomColor && isPlaying
                  ? 'bg-amber-400/20 text-amber-800 dark:text-amber-300 border border-amber-400/40 shadow-xs'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{formatTime(timers[bottomColor])}</span>
            </div>
          )}
        </div>

        {/* Board Action Buttons */}
        <div className="w-full max-w-[640px] flex flex-wrap items-center justify-center gap-2 pt-1">
          <button
            id="play-undo-btn"
            onClick={handleUndo}
            disabled={!isPlaying || isBotThinking || tree.current.ply === 0}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-800 dark:text-stone-200 text-xs font-medium border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>Undo</span>
          </button>

          <button
            id="play-flip-btn"
            onClick={() => setBoardOrientation(boardOrientation === 'w' ? 'b' : 'w')}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-medium border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Flip</span>
          </button>

          <button
            id="play-pause-btn"
            onClick={() => setIsPaused(!isPaused)}
            disabled={!isPlaying}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-800 dark:text-stone-200 text-xs font-medium border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
          >
            {isPaused ? <Play className="w-3.5 h-3.5 text-emerald-500" /> : <Pause className="w-3.5 h-3.5" />}
            <span>{isPaused ? 'Resume' : 'Pause'}</span>
          </button>

          <button
            id="play-draw-btn"
            onClick={handleOfferDraw}
            disabled={!isPlaying}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-40 text-stone-800 dark:text-stone-200 text-xs font-medium border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
          >
            <Handshake className="w-3.5 h-3.5" />
            <span>Draw</span>
          </button>

          <button
            id="play-resign-btn"
            onClick={handleResign}
            disabled={!isPlaying}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-100 dark:bg-red-950/60 hover:bg-red-200 dark:hover:bg-red-900 border border-red-200 dark:border-red-800/80 disabled:opacity-40 text-red-700 dark:text-red-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <Flag className="w-3.5 h-3.5 text-red-500" />
            <span>Resign</span>
          </button>

          {/* Analyze Position Button - RESTRICTED: Disabled while game is active */}
          <button
            id="play-analyze-now-btn"
            onClick={() => onAnalyzeGame(tree)}
            disabled={isPlaying}
            title={
              isPlaying
                ? 'Analysis is disabled while the match is in progress. Conclude the match to analyze.'
                : 'Load the completed game into the engine analysis board'
            }
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
              isPlaying
                ? 'bg-stone-100 dark:bg-stone-800/50 border-stone-200 dark:border-stone-800 text-stone-400 cursor-not-allowed opacity-50'
                : `${themeCfg.subtleBgClass} ${themeCfg.borderClass} ${themeCfg.textClass} hover:opacity-90 cursor-pointer shadow-xs font-bold`
            }`}
          >
            <Activity className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
            <span>Analyze Position</span>
            {isPlaying && (
              <span className="text-[9px] font-mono uppercase text-stone-400 ml-0.5">(Post-Match)</span>
            )}
          </button>
        </div>

        {/* Game Over Banner with Save to Saved Games Option */}
        {gameResult && (
          <div className={`w-full max-w-[640px] bg-white dark:bg-stone-900 border-2 ${themeCfg.borderClass} rounded-xl p-4 shadow-xl flex flex-col items-center gap-3 animate-in zoom-in-95 duration-200`}>
            <div className="text-center">
              <h3 className={`text-lg font-serif font-black ${themeCfg.textClass}`}>
                {gameResult.result === '1-0'
                  ? 'White Wins!'
                  : gameResult.result === '0-1'
                  ? 'Black Wins!'
                  : 'Game Drawn!'}
              </h3>
              <p className="text-xs text-stone-600 dark:text-stone-400 font-mono capitalize mt-0.5">
                {gameResult.reason || 'Match Concluded'} &bull; Result: {gameResult.result}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2">
              <button
                onClick={startNewGame}
                className={`px-4 py-2 rounded-lg font-bold text-xs shadow-md transition-colors flex items-center gap-1.5 cursor-pointer ${themeCfg.primaryClass}`}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Rematch / Play Again</span>
              </button>

              <button
                onClick={() => onAnalyzeGame(tree)}
                className="px-4 py-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-semibold text-xs border border-stone-300 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Activity className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
                <span>Full Engine Review</span>
              </button>

              <button
                onClick={() => setSaveModalOpen(true)}
                className="px-3.5 py-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-semibold text-xs border border-stone-300 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Bookmark className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
                <span>Save to Archive</span>
              </button>
            </div>
          </div>
        )}

        {/* Save Match Modal */}
        {saveModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-md w-full p-5 flex flex-col gap-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
                <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
                  Save Match Record
                </h3>
                <span className={`text-xs font-mono font-bold ${themeCfg.textClass}`}>
                  {gameResult?.result || '*'}
                </span>
              </div>

              {savedSuccess ? (
                <div className="py-6 text-center text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                  ✓ Game successfully saved to archive!
                </div>
              ) : (
                <>
                  <div className="space-y-1">
                    <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
                      Match Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Sharp Sicilian Victory vs Aperture Bot"
                      value={saveTitle}
                      onChange={(e) => setSaveTitle(e.target.value)}
                      className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2 text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden"
                    />
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer text-xs text-stone-700 dark:text-stone-300">
                    <input
                      type="checkbox"
                      checked={saveFavorite}
                      onChange={(e) => setSaveFavorite(e.target.checked)}
                      className="rounded"
                    />
                    <span>Mark as Favorite (❤️ Saved in Favorites tab)</span>
                  </label>

                  <div className="flex justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
                    <button
                      onClick={() => setSaveModalOpen(false)}
                      className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
                    >
                      Dismiss
                    </button>
                    <button
                      onClick={handleSaveGame}
                      className={`px-4 py-1.5 rounded-lg text-xs font-bold shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                    >
                      Save Match
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Right Column: Game Setup & Match Options */}
      <div className="flex flex-col gap-3 order-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col gap-4 shadow-xs">
          <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
            <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Game Setup
            </h3>
            {isPlaying && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold">
                ● Live Game
              </span>
            )}
          </div>

          {/* Prominent Start Game Button at the top */}
          <button
            id="play-start-game-prominent-btn"
            onClick={startNewGame}
            className={`w-full py-3 px-4 rounded-xl font-black text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${themeCfg.primaryClass} hover:opacity-90 active:scale-[0.99]`}
          >
            {isPlaying ? (
              <>
                <RotateCcw className="w-4 h-4" />
                <span>Restart Game</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Start Game</span>
              </>
            )}
          </button>

          {/* 1. Game Mode / Variant: Classic, Chess960, Custom Position */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
              Chess Variant & Starting Mode
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                id="variant-standard-btn"
                onClick={() => setVariantMode('standard')}
                className={`py-2 px-1 rounded-lg text-xs font-semibold border transition-all text-center cursor-pointer ${
                  variantMode === 'standard'
                    ? `${themeCfg.activeTabClass} ${themeCfg.borderClass}`
                    : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                Classic Chess
              </button>
              <button
                id="variant-chess960-btn"
                onClick={() => setVariantMode('chess960')}
                className={`py-2 px-1 rounded-lg text-xs font-semibold border transition-all text-center cursor-pointer ${
                  variantMode === 'chess960'
                    ? `${themeCfg.activeTabClass} ${themeCfg.borderClass}`
                    : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                Chess960
              </button>
              <button
                id="variant-custom-btn"
                onClick={() => setVariantMode('custom')}
                className={`py-2 px-1 rounded-lg text-xs font-semibold border transition-all text-center cursor-pointer ${
                  variantMode === 'custom'
                    ? `${themeCfg.activeTabClass} ${themeCfg.borderClass}`
                    : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                Custom Pos
              </button>
            </div>

            {/* Chess960 Configuration Box */}
            {variantMode === 'chess960' && (
              <div className={`p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950 border ${themeCfg.borderClass} flex flex-col gap-2 animate-in fade-in`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Dices className={`w-4 h-4 ${themeCfg.textClass}`} />
                    <span className="text-xs font-bold text-stone-800 dark:text-stone-200 font-mono">
                      Fischer Random #{chess960Pos.id}
                    </span>
                  </div>
                  <button
                    onClick={() => setChess960Pos(getRandomChess960())}
                    className="px-2 py-1 rounded-md bg-stone-200 dark:bg-stone-800 hover:bg-stone-300 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-[11px] font-mono font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Roll New</span>
                  </button>
                </div>
                <div className="p-1.5 rounded-lg bg-stone-200/60 dark:bg-stone-900 font-mono text-[11px] text-stone-700 dark:text-stone-300 tracking-wider text-center font-bold">
                  {chess960Pos.rankString}
                </div>
              </div>
            )}

            {/* Custom Position Configuration Box */}
            {variantMode === 'custom' && (
              <div className={`p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950 border ${themeCfg.borderClass} flex flex-col gap-2 animate-in fade-in`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-800 dark:text-stone-200 truncate">
                    {customPositionName}
                  </span>
                  <button
                    onClick={() => {
                      setImportError(null);
                      setImportModalOpen(true);
                    }}
                    className={`px-2 py-1 rounded-md text-[11px] font-bold flex items-center gap-1 shadow-xs cursor-pointer ${themeCfg.primaryClass}`}
                  >
                    <Upload className="w-3 h-3" />
                    <span>Import FEN / PGN</span>
                  </button>
                </div>
                <div className="p-1.5 rounded-lg bg-stone-200/60 dark:bg-stone-900 font-mono text-[10px] text-stone-600 dark:text-stone-400 truncate">
                  {customFen}
                </div>
              </div>
            )}
          </div>

          {/* Opponent Selection */}
          <div className="space-y-1">
            <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
              Opponent
            </label>
            <select
              id="play-mode-select"
              value={gameMode}
              onChange={(e) => setGameMode(e.target.value as any)}
              className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2 text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden cursor-pointer"
            >
              <option value="human-bot">Human vs Aperture Engine Bot</option>
              <option value="human-human">Two Players (Pass & Play)</option>
            </select>
          </div>

          {/* Color Selection */}
          {gameMode === 'human-bot' && (
            <div className="space-y-1">
              <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
                Play As
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'w', label: 'White' },
                  { id: 'b', label: 'Black' },
                  { id: 'random', label: 'Random' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setHumanColor(c.id as any)}
                    className={`py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      humanColor === c.id
                        ? `${themeCfg.activeTabClass} ${themeCfg.borderClass}`
                        : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Bot Strength */}
          {gameMode === 'human-bot' && (
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
                  Bot Strength
                </label>
                <span className={`text-[11px] font-mono font-bold ${themeCfg.textClass}`}>
                  ~{BOT_PRESETS[botPreset]?.elo || 1500} Elo
                </span>
              </div>
              <select
                id="play-bot-preset"
                value={botPreset}
                onChange={(e) => setBotPreset(e.target.value)}
                className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2 text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden cursor-pointer"
              >
                {Object.entries(BOT_PRESETS).map(([key, item]) => (
                  <option key={key} value={key}>
                    {item.label} (Depth {item.depth})
                  </option>
                ))}
                <option value="custom">Custom Parameters</option>
              </select>

              {botPreset === 'custom' && (
                <div className="pt-2 space-y-2 border-t border-stone-200 dark:border-stone-800">
                  <div className="flex justify-between text-[10px] font-mono text-stone-500 dark:text-stone-400">
                    <span>Search Depth: {customDepth}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={customDepth}
                    onChange={(e) => setCustomDepth(+e.target.value)}
                    className="w-full"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-stone-500 dark:text-stone-400">
                    <span>Think Time: {customTimeMs}ms</span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="5000"
                    step="100"
                    value={customTimeMs}
                    onChange={(e) => setCustomTimeMs(+e.target.value)}
                    className="w-full"
                  />
                </div>
              )}
            </div>
          )}

          {/* Time Control */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
                Time Control
              </label>
              <span className={`text-[11px] font-mono font-bold ${themeCfg.textClass}`}>
                {timeControl === 0
                  ? 'Unlimited'
                  : timePreset === 'custom'
                  ? `${customMinutes}m + ${customIncrement}s`
                  : timePreset.replace('_', ' + ')}
              </span>
            </div>

            {/* Quick Presets Grid grouped by pace */}
            <div className="space-y-2">
              {/* Bullet & Blitz */}
              <div>
                <span className="text-[10px] font-mono font-semibold text-stone-400 dark:text-stone-500 uppercase tracking-wider block mb-1">
                  ⚡ Bullet & Blitz
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { id: '60_0', label: '1 min', tc: 60, inc: 0 },
                    { id: '120_1', label: '2+1', tc: 120, inc: 1 },
                    { id: '180_0', label: '3 min', tc: 180, inc: 0 },
                    { id: '180_2', label: '3+2', tc: 180, inc: 2 },
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setTimePreset(p.id);
                        setTimeControl(p.tc);
                        setIncrement(p.inc);
                      }}
                      className={`py-1.5 px-1 rounded-lg text-xs font-mono font-bold transition-all text-center border cursor-pointer ${
                        timePreset === p.id
                          ? `${themeCfg.activeTabClass} ${themeCfg.borderClass} shadow-xs`
                          : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rapid & Classical */}
              <div>
                <span className="text-[10px] font-mono font-semibold text-stone-400 dark:text-stone-500 uppercase tracking-wider block mb-1">
                  ⏱️ Rapid & Classical
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { id: '300_0', label: '5 min', tc: 300, inc: 0 },
                    { id: '600_0', label: '10 min', tc: 600, inc: 0 },
                    { id: '900_10', label: '15+10', tc: 900, inc: 10 },
                    { id: '1800_0', label: '30 min', tc: 1800, inc: 0 },
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setTimePreset(p.id);
                        setTimeControl(p.tc);
                        setIncrement(p.inc);
                      }}
                      className={`py-1.5 px-1 rounded-lg text-xs font-mono font-bold transition-all text-center border cursor-pointer ${
                        timePreset === p.id
                          ? `${themeCfg.activeTabClass} ${themeCfg.borderClass} shadow-xs`
                          : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Casual & Custom Options */}
              <div className="grid grid-cols-2 gap-1.5 pt-1">
                <button
                  onClick={() => {
                    setTimePreset('0_0');
                    setTimeControl(0);
                    setIncrement(0);
                  }}
                  className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition-all text-center border flex items-center justify-center gap-1 cursor-pointer ${
                    timePreset === '0_0'
                      ? `${themeCfg.activeTabClass} ${themeCfg.borderClass} shadow-xs`
                      : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                  }`}
                >
                  <span>∞ Casual / No Clock</span>
                </button>
                <button
                  onClick={() => {
                    setTimePreset('custom');
                    setTimeControl(customMinutes * 60);
                    setIncrement(customIncrement);
                  }}
                  className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition-all text-center border flex items-center justify-center gap-1 cursor-pointer ${
                    timePreset === 'custom'
                      ? `${themeCfg.activeTabClass} ${themeCfg.borderClass} shadow-xs`
                      : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                  }`}
                >
                  <span>⚙️ Custom Clock</span>
                </button>
              </div>
            </div>

            {timePreset === 'custom' && (
              <div className="mt-2 space-y-2.5 border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-950 p-2.5 rounded-xl">
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-stone-600 dark:text-stone-300">
                    <span>Base Minutes</span>
                    <span className={`font-bold ${themeCfg.textClass}`}>
                      {customMinutes} {customMinutes === 1 ? 'min' : 'mins'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="60"
                    value={customMinutes}
                    onChange={(e) => {
                      const mins = +e.target.value;
                      setCustomMinutes(mins);
                      setTimeControl(mins * 60);
                    }}
                    className="w-full"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-stone-600 dark:text-stone-300">
                    <span>Increment (Seconds)</span>
                    <span className={`font-bold ${themeCfg.textClass}`}>
                      +{customIncrement}s
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="30"
                    value={customIncrement}
                    onChange={(e) => {
                      const inc = +e.target.value;
                      setCustomIncrement(inc);
                      setIncrement(inc);
                    }}
                    className="w-full"
                  />
                </div>
              </div>
            )}
          </div>

          <button
            id="play-start-btn"
            onClick={startNewGame}
            className={`w-full py-2.5 rounded-lg font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-1.5 mt-2 cursor-pointer ${themeCfg.primaryClass}`}
          >
            <Play className="w-4 h-4" />
            <span>Start Match</span>
          </button>
        </div>
      </div>

      {/* Import Modal for Custom Position in Play Mode */}
      {importModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-lg w-full p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
              <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
                Import Custom Starting Position
              </h3>
              <div className="flex gap-1 bg-stone-100 dark:bg-stone-800 p-0.5 rounded-lg">
                <button
                  onClick={() => setImportTab('fen')}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    importTab === 'fen'
                      ? 'bg-amber-400 text-stone-950 font-bold'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  FEN
                </button>
                <button
                  onClick={() => setImportTab('pgn')}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    importTab === 'pgn'
                      ? 'bg-amber-400 text-stone-950 font-bold'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  PGN
                </button>
                <button
                  onClick={() => setImportTab('saved')}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    importTab === 'saved'
                      ? 'bg-amber-400 text-stone-950 font-bold'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  Saved ({savedPositions.length})
                </button>
              </div>
            </div>

            {importTab === 'saved' ? (
              <div className="flex flex-col gap-2 max-h-60 overflow-y-auto">
                {savedPositions.length === 0 ? (
                  <p className="text-xs text-stone-400 italic text-center py-6">
                    No saved positions found. Save positions in the Board Editor to choose them here.
                  </p>
                ) : (
                  savedPositions.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setCustomFen(p.fen);
                        setCustomPositionName(p.name);
                        setImportModalOpen(false);
                      }}
                      className="p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 hover:border-amber-400 text-left transition-all cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-800 dark:text-stone-200">{p.name}</span>
                        <span className="text-[10px] font-mono text-amber-500">Select &rarr;</span>
                      </div>
                      <p className="text-[11px] font-mono text-stone-400 truncate mt-1">{p.fen}</p>
                    </button>
                  ))
                )}
              </div>
            ) : (
              <>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {importTab === 'fen'
                    ? 'Paste a standard 6-field FEN position string to play from.'
                    : 'Paste a game in PGN format to play from its resulting position.'}
                </p>

                <textarea
                  value={importInput}
                  onChange={(e) => setImportInput(e.target.value)}
                  placeholder={
                    importTab === 'fen'
                      ? 'e.g. r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3'
                      : 'e.g. 1. e4 e5 2. Nf3 Nc6 ...'
                  }
                  className="w-full h-32 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden focus:border-amber-500"
                />

                {importError && (
                  <div className="p-2.5 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-xs font-mono">
                    {importError}
                  </div>
                )}
              </>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
              <button
                onClick={() => setImportModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              {importTab !== 'saved' && (
                <button
                  onClick={handleProcessImport}
                  className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-bold shadow-md cursor-pointer"
                >
                  Apply Starting Position
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
