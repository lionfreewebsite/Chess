import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  Palette,
  Sliders,
  Sparkles,
  Shield,
  Play,
  Check,
  Zap,
  Activity,
  RotateCcw,
  MousePointer,
  Crown,
  Eye,
  Layers,
} from 'lucide-react';
import {
  BoardTheme,
  PieceTheme,
  PieceStyle,
  AnimationSpeed,
  DragRefreshRate,
  UIThemeColor,
  Square,
} from '../types/chess';
import { globalAudio, SoundType, SoundConfig } from '../utils/audio';
import { ChessPieceSvg } from '../components/Chessboard/ChessPieceSvg';
import { Chessboard } from '../components/Chessboard/Chessboard';
import { GameTree } from '../engine/gameTree';
import { sqName, nameToSq } from '../engine/chessRules';
import { UI_THEMES, getThemeConfig } from '../utils/themeColors';

interface SettingsViewProps {
  uiTheme: UIThemeColor;
  setUiTheme: (t: UIThemeColor) => void;
  boardTheme: BoardTheme;
  setBoardTheme: (t: BoardTheme) => void;
  pieceTheme: PieceTheme;
  setPieceTheme: (t: PieceTheme) => void;
  pieceStyle: PieceStyle;
  setPieceStyle: (s: PieceStyle) => void;
  soundEnabled: boolean;
  setSoundEnabled: (en: boolean) => void;
  animationEnabled: boolean;
  setAnimationEnabled: (en: boolean) => void;
  animationSpeed: AnimationSpeed;
  setAnimationSpeed: (s: AnimationSpeed) => void;
  dragAndDropEnabled: boolean;
  setDragAndDropEnabled: (en: boolean) => void;
  dragRefreshRate: DragRefreshRate;
  setDragRefreshRate: (r: DragRefreshRate) => void;
  autoQueenEnabled: boolean;
  setAutoQueenEnabled: (en: boolean) => void;
  showCoordinates: boolean;
  setShowCoordinates: (en: boolean) => void;
  showLegalMoves: boolean;
  setShowLegalMoves: (en: boolean) => void;
  showCheckHighlight: boolean;
  setShowCheckHighlight: (en: boolean) => void;
  showLastMoveHighlight: boolean;
  setShowLastMoveHighlight: (en: boolean) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  uiTheme,
  setUiTheme,
  boardTheme,
  setBoardTheme,
  pieceTheme,
  setPieceTheme,
  pieceStyle,
  setPieceStyle,
  soundEnabled,
  setSoundEnabled,
  animationEnabled,
  setAnimationEnabled,
  animationSpeed,
  setAnimationSpeed,
  dragAndDropEnabled,
  setDragAndDropEnabled,
  dragRefreshRate,
  setDragRefreshRate,
  autoQueenEnabled,
  setAutoQueenEnabled,
  showCoordinates,
  setShowCoordinates,
  showLegalMoves,
  setShowLegalMoves,
  showCheckHighlight,
  setShowCheckHighlight,
  showLastMoveHighlight,
  setShowLastMoveHighlight,
}) => {
  const [demoTree, setDemoTree] = useState<GameTree>(() => new GameTree());
  const [demoMoveIdx, setDemoMoveIdx] = useState<number>(0);
  const [soundFxConfig, setSoundFxConfig] = useState<SoundConfig>(() => globalAudio.getConfig());

  const handleToggleSound = (type: SoundType, enabled: boolean) => {
    globalAudio.setSoundEffectEnabled(type, enabled);
    setSoundFxConfig({ ...globalAudio.getConfig() });
  };

  const handleToggleAllSounds = (enabled: boolean) => {
    globalAudio.setAllSoundEffects(enabled);
    setSoundFxConfig({ ...globalAudio.getConfig() });
  };

  const SOUND_ITEMS: {
    id: SoundType;
    label: string;
    desc: string;
    play: () => void;
  }[] = [
    {
      id: 'move',
      label: 'Move Sound',
      desc: 'Wooden tap when moving to an empty square',
      play: () => globalAudio.move(),
    },
    {
      id: 'capture',
      label: 'Capture Sound',
      desc: 'Resonant thud when taking an opponent piece',
      play: () => globalAudio.capture(),
    },
    {
      id: 'check',
      label: 'Check Alert',
      desc: 'High-pitch alert bell when a King is in check',
      play: () => globalAudio.check(),
    },
    {
      id: 'castle',
      label: 'Castle Sound',
      desc: 'Dual slide effect when castling kingside/queenside',
      play: () => globalAudio.castle(),
    },
    {
      id: 'promote',
      label: 'Promotion Fanfare',
      desc: 'Ascending chord upon pawn coronation',
      play: () => globalAudio.promote(),
    },
    {
      id: 'victory',
      label: 'Winning Sound',
      desc: 'Triumphant major jingle for checkmate win (Human vs Human & Bot matches)',
      play: () => globalAudio.victory(),
    },
    {
      id: 'defeat',
      label: 'Checkmate Loss / Defeat',
      desc: 'Descending somber cadence for checkmate loss vs bots or in bot matches',
      play: () => globalAudio.defeat(),
    },
    {
      id: 'draw',
      label: 'Draw Sound',
      desc: 'Harmonic double tone for stalemate, repetition, or draw agreement',
      play: () => globalAudio.draw(),
    },
    {
      id: 'resign',
      label: 'Resign Sound',
      desc: 'Gentle acknowledging tone when a player or bot resigns',
      play: () => globalAudio.resign(),
    },
    {
      id: 'gameStart',
      label: 'Game Start Sound',
      desc: 'Opening acoustic pulse when starting a match',
      play: () => globalAudio.gameStart(),
    },
    {
      id: 'error',
      label: 'Illegal Move / Error',
      desc: 'Low warning buzz on illegal moves or incorrect puzzle attempts',
      play: () => globalAudio.error(),
    },
  ];

  const themeCfg = getThemeConfig(uiTheme);

  const DEMO_MOVES = [
    { from: 'e2', to: 'e4' },
    { from: 'e7', to: 'e5' },
    { from: 'g1', to: 'f3' },
    { from: 'b8', to: 'c6' },
    { from: 'f1', to: 'c4' },
    { from: 'g8', to: 'f6' },
    { from: 'd2', to: 'd4' },
    { from: 'e5', to: 'd4' },
  ];

  const handlePlayNextDemoMove = () => {
    if (demoMoveIdx >= DEMO_MOVES.length) {
      const reset = new GameTree();
      setDemoTree(reset);
      setDemoMoveIdx(0);
      return;
    }
    const nextMove = DEMO_MOVES[demoMoveIdx];
    const newTree = demoTree.clone();
    newTree.addMove(nextMove.from, nextMove.to);
    setDemoTree(newTree);
    setDemoMoveIdx(demoMoveIdx + 1);
    if (soundEnabled) globalAudio.move();
  };

  const handleResetDemo = () => {
    setDemoTree(new GameTree());
    setDemoMoveIdx(0);
  };

  const BOARD_THEMES: { id: BoardTheme; label: string; light: string; dark: string }[] = [
    { id: 'walnut', label: 'Classic Walnut', light: '#f0d9b5', dark: '#b58863' },
    { id: 'tournament', label: 'Tournament Green', light: '#eeeed2', dark: '#769656' },
    { id: 'azure', label: 'Azure Oceanic', light: '#e8edf9', dark: '#6085a8' },
    { id: 'coral', label: 'Coral Wood', light: '#f4e7dc', dark: '#b86b53' },
    { id: 'graphite', label: 'Graphite Slate', light: '#4b5563', dark: '#1f2937' },
    { id: 'midnight', label: 'Midnight Dark', light: '#2d3748', dark: '#1a202c' },
  ];

  const PIECE_THEMES: { id: PieceTheme; label: string; desc: string }[] = [
    { id: 'ivory', label: 'Classic Ivory & Charcoal', desc: 'Standard grandmaster tournament styling' },
    { id: 'wood', label: 'Ebony & Warm Gold', desc: 'Rich luxury golden accents & dark wood' },
    { id: 'metallic', label: 'Metallic Bronze & Titanium', desc: 'Polished titanium and gunmetal finish' },
    { id: 'neon', label: 'Cyberpunk Neon', desc: 'Futuristic vibrant cyan and electric amber' },
  ];

  const SPEED_OPTIONS: { id: AnimationSpeed; label: string; duration: string; desc: string }[] = [
    { id: 'fast', label: 'Fast', duration: '120ms', desc: 'Snappy response for blitz & bullet games' },
    { id: 'normal', label: 'Normal', duration: '220ms', desc: 'Balanced smooth glide for standard play' },
    { id: 'slow', label: 'Slow', duration: '380ms', desc: 'Gentle cinematic piece transitions' },
  ];

  const lastMoveData = demoTree.current.uci
    ? { from: nameToSq(demoTree.current.uci.from), to: nameToSq(demoTree.current.uci.to) }
    : null;

  return (
    <div className="w-full flex-1 max-w-5xl mx-auto p-4 sm:p-6 flex flex-col gap-6">
      <div className="border-b border-stone-200 dark:border-stone-800 pb-3">
        <h1 className="text-xl font-bold font-serif text-stone-900 dark:text-stone-100">Preferences & Settings</h1>
        <p className="text-xs text-stone-500 dark:text-stone-400 font-mono mt-0.5">
          Customize UI accent themes, touch/drag controls, board themes, piece sets, move animations, and audio
        </p>
      </div>

      {/* 1. Website UI Theme Color Selector */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        <div className="flex items-center gap-2">
          <Palette className={`w-4 h-4 ${themeCfg.textClass}`} />
          <div>
            <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Website UI Theme Accent Color</h2>
            <p className="text-[11px] text-stone-500 dark:text-stone-400">
              Personalize primary action buttons, active navigation indicators, and highlights
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {UI_THEMES.map((theme) => {
            const isSelected = uiTheme === theme.id;
            return (
              <button
                key={theme.id}
                id={`theme-color-${theme.id}`}
                onClick={() => setUiTheme(theme.id)}
                className={`p-3.5 rounded-xl border flex flex-col gap-2 text-left transition-all cursor-pointer ${
                  isSelected
                    ? `${theme.borderClass} bg-stone-100/80 dark:bg-stone-800/80 shadow-md ring-2 ${theme.ringClass}`
                    : 'bg-stone-50 dark:bg-stone-950/60 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-4 h-4 rounded-full shadow-inner border border-white/20"
                      style={{ backgroundColor: theme.previewColor }}
                    />
                    <span className="text-xs font-bold text-stone-900 dark:text-stone-100">{theme.label}</span>
                  </div>
                  {isSelected && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: theme.previewColor }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-stone-500 dark:text-stone-400">{theme.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Board Controls & Input Preferences */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        <div className="flex items-center gap-2">
          <MousePointer className={`w-4 h-4 ${themeCfg.textClass}`} />
          <div>
            <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Controls & Interaction</h2>
            <p className="text-[11px] text-stone-500 dark:text-stone-400">
              Configure piece grabbing, touch gestures, and auto-promotions
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Touch and Drag Pieces Toggle */}
          <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                Touch & Drag Pieces (Default ON)
              </span>
              <span className="text-[11px] text-stone-500 dark:text-stone-400">
                Pick up pieces by clicking or touching, and drag to drop on destination.
              </span>
            </div>
            <button
              id="toggle-drag-drop-btn"
              onClick={() => setDragAndDropEnabled(!dragAndDropEnabled)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer shrink-0 ${
                dragAndDropEnabled
                  ? `${themeCfg.primaryClass} font-bold shadow-xs`
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 border-stone-300 dark:border-stone-700'
              }`}
            >
              {dragAndDropEnabled ? 'Drag ON' : 'Click Only'}
            </button>
          </div>

          {/* Auto-Queen Promotion Toggle */}
          <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                Auto-Queen Promotion
              </span>
              <span className="text-[11px] text-stone-500 dark:text-stone-400">
                Instantly promote pawns to Queens without popping up the selector.
              </span>
            </div>
            <button
              id="toggle-auto-queen-btn"
              onClick={() => setAutoQueenEnabled(!autoQueenEnabled)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer shrink-0 ${
                autoQueenEnabled
                  ? `${themeCfg.primaryClass} font-bold shadow-xs`
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 border-stone-300 dark:border-stone-700'
              }`}
            >
              {autoQueenEnabled ? 'Auto ON' : 'Prompt Always'}
            </button>
          </div>
        </div>

        {/* Drag Smoothness / Refresh Rate (60 FPS / 30 FPS / Unlimited) */}
        <div className="pt-3 border-t border-stone-200 dark:border-stone-800 space-y-2">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                Piece Dragging Refresh Rate (Smoothness)
              </span>
              <span className="text-[11px] text-stone-500 dark:text-stone-400">
                Control the frame refresh rate of the floating piece during drag gestures
              </span>
            </div>
            <span className={`text-xs font-mono font-bold ${themeCfg.textClass}`}>
              {dragRefreshRate === '60fps' ? '60 FPS' : dragRefreshRate === '30fps' ? '30 FPS' : 'Unlimited'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { id: '60fps' as DragRefreshRate, label: '60 FPS (Ultra Smooth)', desc: 'Standard high-precision animation loop' },
              { id: '30fps' as DragRefreshRate, label: '30 FPS (Power Saver)', desc: 'Reduced refresh rate for low-power devices' },
              { id: 'unlimited' as DragRefreshRate, label: 'Native Display (Uncapped)', desc: 'Matches 120Hz/144Hz high refresh screens' },
            ].map((rate) => {
              const isSelected = dragRefreshRate === rate.id;
              return (
                <button
                  key={rate.id}
                  id={`drag-fps-${rate.id}`}
                  onClick={() => setDragRefreshRate(rate.id)}
                  className={`p-3 rounded-xl border flex flex-col gap-1 text-left transition-all cursor-pointer ${
                    isSelected
                      ? `${themeCfg.borderClass} bg-stone-100/80 dark:bg-stone-800/80 shadow-md ring-2 ${themeCfg.ringClass}`
                      : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-stone-800 dark:text-stone-200">{rate.label}</span>
                    {isSelected && <Check className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />}
                  </div>
                  <span className="text-[11px] text-stone-500 dark:text-stone-400">{rate.desc}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Board Visual Highlights & Indicators */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        <div className="flex items-center gap-2">
          <Eye className={`w-4 h-4 ${themeCfg.textClass}`} />
          <div>
            <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Board Visual Highlights</h2>
            <p className="text-[11px] text-stone-500 dark:text-stone-400">
              Customize square overlays, dots, check alerts, and rank/file notation
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Coordinates */}
          <label className="p-3 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between cursor-pointer">
            <span className="text-xs font-medium text-stone-700 dark:text-stone-300">
              Rank & File Coordinates
            </span>
            <input
              type="checkbox"
              checked={showCoordinates}
              onChange={(e) => setShowCoordinates(e.target.checked)}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
          </label>

          {/* Legal Moves */}
          <label className="p-3 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between cursor-pointer">
            <span className="text-xs font-medium text-stone-700 dark:text-stone-300">
              Legal Move Target Dots
            </span>
            <input
              type="checkbox"
              checked={showLegalMoves}
              onChange={(e) => setShowLegalMoves(e.target.checked)}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
          </label>

          {/* Check Glow */}
          <label className="p-3 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between cursor-pointer">
            <span className="text-xs font-medium text-stone-700 dark:text-stone-300">
              Check Warning Glow
            </span>
            <input
              type="checkbox"
              checked={showCheckHighlight}
              onChange={(e) => setShowCheckHighlight(e.target.checked)}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
          </label>

          {/* Last Move */}
          <label className="p-3 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between cursor-pointer">
            <span className="text-xs font-medium text-stone-700 dark:text-stone-300">
              Last Move Highlight
            </span>
            <input
              type="checkbox"
              checked={showLastMoveHighlight}
              onChange={(e) => setShowLastMoveHighlight(e.target.checked)}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
          </label>
        </div>
      </div>

      {/* 4. Move Animation Settings */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className={`w-4 h-4 ${themeCfg.textClass}`} />
            <div>
              <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Piece Move Animations</h2>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                Smooth gliding transitions when pieces move across the board
              </p>
            </div>
          </div>
          <button
            id="toggle-move-animations-btn"
            onClick={() => setAnimationEnabled(!animationEnabled)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              animationEnabled
                ? `${themeCfg.primaryClass} font-bold shadow-xs`
                : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 border-stone-300 dark:border-stone-700'
            }`}
          >
            {animationEnabled ? 'Animations ON' : 'Animations OFF'}
          </button>
        </div>

        {/* Speed Selection */}
        {animationEnabled && (
          <div className="space-y-3 pt-3 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-semibold text-stone-700 dark:text-stone-300">
                Animation Speed
              </span>
              <span className={`text-[11px] font-mono ${themeCfg.textClass} font-bold capitalize`}>
                {animationSpeed} ({SPEED_OPTIONS.find((s) => s.id === animationSpeed)?.duration})
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {SPEED_OPTIONS.map((speed) => {
                const isSelected = animationSpeed === speed.id;
                return (
                  <button
                    key={speed.id}
                    id={`speed-btn-${speed.id}`}
                    onClick={() => setAnimationSpeed(speed.id)}
                    className={`p-3 rounded-xl border flex flex-col gap-1 text-left transition-all cursor-pointer ${
                      isSelected
                        ? `${themeCfg.borderClass} bg-stone-100/80 dark:bg-stone-800/80 shadow-md ring-2 ${themeCfg.ringClass}`
                        : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-stone-800 dark:text-stone-200">{speed.label}</span>
                      <span className="text-[10px] font-mono text-stone-500 dark:text-stone-400 font-semibold">
                        {speed.duration}
                      </span>
                    </div>
                    <span className="text-[11px] text-stone-500 dark:text-stone-400">{speed.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* 5. Board Color Themes */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-3 shadow-xs">
        <div className="flex items-center gap-2">
          <Palette className={`w-4 h-4 ${themeCfg.textClass}`} />
          <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Chessboard Theme</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {BOARD_THEMES.map((theme) => {
            const isSelected = boardTheme === theme.id;
            const previewPieces = ['R', 'N', 'b', 'q', 'p', 'P', 'k', 'K'];
            return (
              <button
                key={theme.id}
                id={`board-theme-${theme.id}`}
                onClick={() => setBoardTheme(theme.id)}
                className={`p-3 rounded-xl border flex flex-col gap-2.5 text-left transition-all cursor-pointer ${
                  isSelected
                    ? `${themeCfg.borderClass} bg-stone-100/80 dark:bg-stone-800/80 shadow-md ring-2 ${themeCfg.ringClass}`
                    : 'bg-stone-50 dark:bg-stone-950/60 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-800 dark:text-stone-200">{theme.label}</span>
                  {isSelected && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: themeCfg.previewColor }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>

                {/* Display selected piece theme on this chess board theme */}
                <div className="grid grid-cols-4 grid-rows-2 h-14 w-full rounded-lg overflow-hidden border border-stone-300 dark:border-stone-700 shadow-inner">
                  {Array.from({ length: 8 }).map((_, i) => {
                    const row = Math.floor(i / 4);
                    const col = i % 4;
                    const isLight = (row + col) % 2 === 0;
                    const pc = previewPieces[i];
                    return (
                      <div
                        key={i}
                        style={{ backgroundColor: isLight ? theme.light : theme.dark }}
                        className="w-full h-full flex items-center justify-center p-0.5"
                      >
                        <div className="w-5 h-5">
                          <ChessPieceSvg piece={pc} theme={pieceTheme} styleType={pieceStyle} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 6. Piece Styling Selection */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-3 shadow-xs">
        <div className="flex items-center gap-2">
          <Sparkles className={`w-4 h-4 ${themeCfg.textClass}`} />
          <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Piece Visual Style & Theme</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {PIECE_THEMES.map((item) => {
            const isSelected = pieceTheme === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setPieceTheme(item.id)}
                className={`p-4 rounded-xl border flex flex-col gap-2.5 text-left transition-all cursor-pointer ${
                  isSelected
                    ? `${themeCfg.borderClass} bg-stone-100/80 dark:bg-stone-800/80 shadow-md ring-2 ${themeCfg.ringClass}`
                    : 'bg-stone-50 dark:bg-stone-950/60 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-800 dark:text-stone-200">{item.label}</span>
                  {isSelected && (
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: themeCfg.previewColor }}
                    >
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>

                {/* Visual Piece Sample Gallery */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-stone-200/60 dark:bg-stone-950 border border-stone-300 dark:border-stone-800/80">
                  <div className="flex items-center gap-1.5">
                    <div className="w-7 h-7"><ChessPieceSvg piece="K" theme={item.id} /></div>
                    <div className="w-7 h-7"><ChessPieceSvg piece="Q" theme={item.id} /></div>
                    <div className="w-7 h-7"><ChessPieceSvg piece="N" theme={item.id} /></div>
                  </div>
                  <div className="h-5 w-px bg-stone-300 dark:bg-stone-800" />
                  <div className="flex items-center gap-1.5">
                    <div className="w-7 h-7"><ChessPieceSvg piece="k" theme={item.id} /></div>
                    <div className="w-7 h-7"><ChessPieceSvg piece="q" theme={item.id} /></div>
                    <div className="w-7 h-7"><ChessPieceSvg piece="n" theme={item.id} /></div>
                  </div>
                </div>

                <span className="text-[11px] text-stone-500 dark:text-stone-400">{item.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 7. Audio & Sound Effects */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {soundEnabled ? (
              <Volume2 className={`w-4 h-4 ${themeCfg.textClass}`} />
            ) : (
              <VolumeX className="w-4 h-4 text-stone-400" />
            )}
            <div>
              <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Audio Synthesizer & Sound Effects</h2>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                Configure master audio output and toggle individual sound effects (all active by default)
              </p>
            </div>
          </div>
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
              soundEnabled
                ? `${themeCfg.primaryClass} font-bold shadow-xs`
                : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 border-stone-300 dark:border-stone-700'
            }`}
          >
            {soundEnabled ? 'Audio Enabled' : 'Audio Muted'}
          </button>
        </div>

        {soundEnabled && (
          <div className="space-y-3 pt-3 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400 font-semibold">
                Granular Sound FX Controls
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleAllSounds(true)}
                  className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                >
                  Enable All
                </button>
                <span className="text-stone-300 dark:text-stone-700">|</span>
                <button
                  type="button"
                  onClick={() => handleToggleAllSounds(false)}
                  className="text-[11px] font-mono text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
                >
                  Disable All
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SOUND_ITEMS.map((item) => {
                const isItemEnabled = soundFxConfig[item.id] ?? true;
                return (
                  <div
                    key={item.id}
                    className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                      isItemEnabled
                        ? 'bg-stone-50/70 dark:bg-stone-950/70 border-stone-200 dark:border-stone-800'
                        : 'bg-stone-100/40 dark:bg-stone-900/40 border-dashed border-stone-200 dark:border-stone-800 opacity-60'
                    }`}
                  >
                    <div className="flex items-start gap-2.5 min-w-0 pr-2">
                      <input
                        type="checkbox"
                        id={`sound-toggle-${item.id}`}
                        checked={isItemEnabled}
                        onChange={(e) => handleToggleSound(item.id, e.target.checked)}
                        className="mt-0.5 h-4 w-4 rounded border-stone-300 dark:border-stone-700 text-stone-900 focus:ring-stone-500 cursor-pointer"
                      />
                      <label htmlFor={`sound-toggle-${item.id}`} className="flex flex-col cursor-pointer min-w-0 select-none">
                        <span className="text-xs font-semibold text-stone-800 dark:text-stone-200">
                          {item.label}
                        </span>
                        <span className="text-[10.5px] text-stone-500 dark:text-stone-400 leading-tight truncate">
                          {item.desc}
                        </span>
                      </label>
                    </div>

                    <button
                      type="button"
                      onClick={() => item.play()}
                      title={`Sample ${item.label}`}
                      className="px-2.5 py-1 rounded-md bg-white dark:bg-stone-800 hover:bg-stone-100 dark:hover:bg-stone-700 border border-stone-200 dark:border-stone-700 text-[11px] font-mono text-stone-700 dark:text-stone-300 shrink-0 transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                    >
                      <Play className="w-3 h-3 text-stone-500 fill-stone-500" />
                      <span>Play</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* 8. Live Interactive Settings Preview Stage */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className={`w-4 h-4 ${themeCfg.textClass}`} />
            <div>
              <h2 className="text-sm font-bold text-stone-800 dark:text-stone-200">Interactive Preview Playground</h2>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                Test and verify your board colors, piece set, drag-and-drop moves, and smooth animations live
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="demo-step-move-btn"
              onClick={handlePlayNextDemoMove}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer flex items-center gap-1.5 ${themeCfg.primaryClass}`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Step Move ({demoMoveIdx}/{DEMO_MOVES.length})</span>
            </button>
            <button
              id="demo-reset-btn"
              onClick={handleResetDemo}
              className="p-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 border border-stone-300 dark:border-stone-700 text-stone-600 dark:text-stone-300 transition-colors cursor-pointer"
              title="Reset Preview"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-6 items-center justify-center pt-2">
          <div className="w-full max-w-[380px]">
            {(() => {
              const lastMoveData = demoTree.current?.uci
                ? { from: nameToSq(demoTree.current.uci.from), to: nameToSq(demoTree.current.uci.to) }
                : null;
              return (
                <Chessboard
                  board={demoTree.chess.board}
                  orientation="w"
                  turn={demoTree.chess.turn}
                  interactive={true}
                  canSelect={(sq) => {
                    const pc = demoTree.chess.board[sq];
                    return !!pc && (demoTree.chess.turn === 'w' ? pc === pc.toUpperCase() : pc === pc.toLowerCase());
                  }}
                  getLegalTargets={(sq) => demoTree.chess.getLegalTargetsForSquare(sq)}
                  onMove={(from, to, promo) => {
                    const fStr = sqName(from);
                    const tStr = sqName(to);
                    const newTree = demoTree.clone();
                    const node = newTree.addMove(fStr, tStr, promo);
                    if (node) {
                      setDemoTree(newTree);
                      if (soundEnabled) {
                        if (node.isCapture) globalAudio.capture();
                        else if (node.isCheck) globalAudio.check();
                        else globalAudio.move();
                      }
                    }
                  }}
                  lastMove={lastMoveData}
                  dragRefreshRate={dragRefreshRate}
                  boardTheme={boardTheme}
                  pieceTheme={pieceTheme}
                  pieceStyle={pieceStyle}
                  animationEnabled={animationEnabled}
                  animationSpeed={animationSpeed}
                  dragAndDropEnabled={dragAndDropEnabled}
                  autoQueenEnabled={autoQueenEnabled}
                  showCoordinates={showCoordinates}
                  showLegalMoves={showLegalMoves}
                  showCheckHighlight={showCheckHighlight}
                  showLastMoveHighlight={showLastMoveHighlight}
                  uiTheme={uiTheme}
                />
              );
            })()}
          </div>

          <div className="flex flex-col gap-2.5 text-xs max-w-xs">
            <div className={`p-3 rounded-lg border ${themeCfg.borderClass} ${themeCfg.subtleBgClass}`}>
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: themeCfg.previewColor }} />
                <span>Active Preferences</span>
              </div>
              <ul className="space-y-1 text-[11px] text-stone-600 dark:text-stone-300 font-mono">
                <li>UI Accent: <span className="font-bold">{themeCfg.label}</span></li>
                <li>Board: <span className="font-bold capitalize">{boardTheme}</span></li>
                <li>Pieces: <span className="font-bold capitalize">{pieceTheme}</span></li>
                <li>Drag & Drop: <span className="font-bold">{dragAndDropEnabled ? 'Enabled' : 'Disabled'}</span></li>
                <li>Animations: <span className="font-bold">{animationEnabled ? animationSpeed : 'Disabled'}</span></li>
              </ul>
            </div>
            <p className="text-[11px] text-stone-500 dark:text-stone-400 italic">
              Try picking up or dragging pieces, or click "Step Move" to preview animated grandmaster play.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
