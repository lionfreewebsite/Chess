import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ChevronsLeft,
  ChevronLeft,
  ChevronRight,
  ChevronsRight,
  RotateCcw,
  Sparkles,
  Download,
  Upload,
  Copy,
  Trash2,
  ArrowUpCircle,
  Play,
  Pause,
  Layers,
  FileText,
  Activity,
  Check,
  Edit3,
  Cpu,
  Sliders,
} from 'lucide-react';
import { Chessboard, ArrowData } from '../components/Chessboard/Chessboard';
import { GameTree } from '../engine/gameTree';
import { globalEngine } from '../engine/engineService';
import { GameReviewer, GameReviewReport } from '../engine/gameReview';
import { globalAudio } from '../utils/audio';
import { detectDeviceCapabilities } from '../utils/deviceDetection';
import { getThemeConfig } from '../utils/themeColors';
import { CLASSIFICATION_CONFIGS } from '../utils/classificationBadge';
import {
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  PVLine,
  EngineInfo,
  Square,
  GameTreeNode,
  AnimationSpeed,
  DragRefreshRate,
  UIThemeColor,
} from '../types/chess';
import { sqName, nameToSq, colorOf, Chess } from '../engine/chessRules';

interface AnalysisViewProps {
  initialTree?: GameTree;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  soundEnabled: boolean;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  dragRefreshRate?: DragRefreshRate;
  dragAndDropEnabled?: boolean;
  autoQueenEnabled?: boolean;
  showCoordinates?: boolean;
  showLegalMoves?: boolean;
  showCheckHighlight?: boolean;
  showLastMoveHighlight?: boolean;
  uiTheme?: UIThemeColor;
  onOpenEditor?: (fen: string) => void;
  isActive?: boolean;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({
  initialTree,
  boardTheme,
  pieceTheme,
  pieceStyle,
  soundEnabled,
  animationEnabled = true,
  animationSpeed = 'normal',
  dragRefreshRate = '60fps',
  dragAndDropEnabled = true,
  autoQueenEnabled = false,
  showCoordinates = true,
  showLegalMoves = true,
  showCheckHighlight = true,
  showLastMoveHighlight = true,
  uiTheme = 'orange',
  onOpenEditor,
  isActive = true,
}) => {
  const [tree, setTree] = useState<GameTree>(() => initialTree || new GameTree());
  const [boardOrientation, setBoardOrientation] = useState<PieceColor>('w');

  // Sync with initialTree when provided from another view (e.g. Play, BotMatch, Puzzles)
  useEffect(() => {
    if (initialTree) {
      setTree(initialTree.clone());
      setReviewReport(null);
    }
  }, [initialTree]);

  // Device hardware detection
  const [deviceCaps] = useState(() => detectDeviceCapabilities());

  // Engine controls & user preference state (persists user's manual toggle)
  const [userEnginePref, setUserEnginePref] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('aperture_user_engine_pref');
      if (stored !== null) return stored === 'true';
    } catch {}
    return true;
  });

  // Effective live engine state: active only when view is visible AND user preference is ON
  const isEngineOn = isActive && userEnginePref;

  const handleToggleEngine = (newVal: boolean) => {
    setUserEnginePref(newVal);
    try {
      localStorage.setItem('aperture_user_engine_pref', String(newVal));
    } catch {}
    if (!newVal) {
      globalEngine.stop();
    }
  };

  // When switching away from analysis mode, stop the engine worker
  useEffect(() => {
    if (!isActive) {
      globalEngine.stop();
    }
  }, [isActive]);
  const [multiPV, setMultiPV] = useState<number>(() => {
    try {
      const val = parseInt(localStorage.getItem('aperture_analysis_multipv') || '1', 10);
      return val >= 1 ? val : 1;
    } catch {
      return 1;
    }
  });
  const [multiPVEnabled, setMultiPVEnabled] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('aperture_analysis_multipv_enabled');
      if (stored !== null) return stored === 'true';
    } catch {}
    return false;
  });

  const [depthCap, setDepthCap] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('aperture_depth_cap');
      if (stored) return parseInt(stored, 10);
    } catch {}
    return deviceCaps.isLowOrMidEnd ? 12 : 16;
  });
  const [optimizationMode, setOptimizationMode] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('aperture_optimization_mode');
      if (stored !== null) return stored === 'true';
    } catch {}
    return deviceCaps.isLowOrMidEnd;
  });

  const [engineLines, setEngineLines] = useState<PVLine[]>([]);
  const [engineStats, setEngineStats] = useState<{ depth: number; nodes: number; nps: number }>({
    depth: 0,
    nodes: 0,
    nps: 0,
  });

  // Review state
  const [isReviewing, setIsReviewing] = useState<boolean>(false);
  const [reviewProgress, setReviewProgress] = useState<{ current: number; total: number } | null>(null);
  const [reviewReport, setReviewReport] = useState<GameReviewReport | null>(null);
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);

  const themeCfg = getThemeConfig(uiTheme);

  // Import / Export Modal
  const [importExportModal, setImportExportModal] = useState<boolean>(false);
  const [modalTab, setModalTab] = useState<'pgn' | 'fen'>('pgn');
  const [pgnInput, setPgnInput] = useState<string>('');
  const [fenInput, setFenInput] = useState<string>('');
  const [copiedText, setCopiedText] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const debounceTimerRef = useRef<any>(null);
  const lastInfoUpdateRef = useRef<number>(0);

  // Trigger Live Engine Analysis on current position with debouncing
  const triggerLiveAnalysis = useCallback(() => {
    if (!isEngineOn) {
      globalEngine.stop();
      setEngineLines([]);
      return;
    }

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Immediately reflect cached evaluation if present
    if (tree.current.evalScore) {
      setEngineLines([
        {
          pv: tree.current.uci ? [tree.current.uci.from + tree.current.uci.to] : [],
          score: tree.current.evalScore,
          depth: tree.current.evalDepth || 10,
          nodes: 0,
          time: 0,
        },
      ]);
    }

    debounceTimerRef.current = setTimeout(() => {
      const currentFen = tree.chess.fen();
      const effectiveDepth = optimizationMode ? Math.min(depthCap, 12) : depthCap;
      const effectivePv = !multiPVEnabled ? 1 : (optimizationMode ? Math.min(multiPV, 2) : multiPV);

      globalEngine.analyze(currentFen, {
        multipv: effectivePv,
        maxDepth: effectiveDepth,
        infinite: true,
      });
    }, 75);
  }, [isEngineOn, multiPVEnabled, multiPV, depthCap, optimizationMode, tree]);

  // Listen to engine stream with throttled state updates
  useEffect(() => {
    const handleInfo = (info: EngineInfo) => {
      const now = performance.now();
      // Throttle engine updates to 60-100ms intervals to prevent UI jank
      if (now - lastInfoUpdateRef.current < 80 && info.depth < 14) {
        return;
      }
      lastInfoUpdateRef.current = now;

      setEngineStats({
        depth: info.depth,
        nodes: info.nodes,
        nps: info.nps,
      });
      if (info.lines) {
        setEngineLines(info.lines);
        // Cache evaluation on active node for the graph
        if (info.lines[0]?.score) {
          const score = info.lines[0].score;
          const cpVal =
            score.mate !== undefined ? (score.mate > 0 ? 2500 : -2500) : score.cp || 0;
          tree.current.evalScore = score;
          tree.current.evalCp = cpVal;
          tree.current.evalDepth = info.depth;
        }
      }
    };

    globalEngine.on('info', handleInfo);
    return () => {
      globalEngine.off('info', handleInfo);
    };
  }, [tree]);

  // Keyboard navigation for smooth review
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture when typing in inputs/textareas
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA' ||
        importExportModal ||
        showReviewModal
      ) {
        return;
      }

      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        tree.back();
        setTree(tree.clone());
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        tree.forward();
        setTree(tree.clone());
      } else if (e.key === 'Home') {
        e.preventDefault();
        tree.toStart();
        setTree(tree.clone());
      } else if (e.key === 'End') {
        e.preventDefault();
        tree.toEnd();
        setTree(tree.clone());
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [tree, importExportModal, showReviewModal]);

  // Restart engine on position or settings change
  useEffect(() => {
    triggerLiveAnalysis();
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
      globalEngine.stop();
    };
  }, [triggerLiveAnalysis]);

  // Redraw evaluation graph with dynamic real-time updates and baseline
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const renderGraph = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.parentElement?.clientWidth || canvas.clientWidth || 300;
      const h = 80;

      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      ctx.clearRect(0, 0, w, h);
      const mid = h / 2;

      // Advantage guide lines (+3, 0, -3)
      ctx.strokeStyle = 'rgba(150, 150, 150, 0.15)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);

      const yPlus3 = h - (50 + 50 * Math.tanh(300 / 380)) * 0.01 * h;
      const yMinus3 = h - (50 + 50 * Math.tanh(-300 / 380)) * 0.01 * h;

      ctx.beginPath();
      ctx.moveTo(0, yPlus3);
      ctx.lineTo(w, yPlus3);
      ctx.moveTo(0, yMinus3);
      ctx.lineTo(w, yMinus3);
      ctx.stroke();
      ctx.setLineDash([]);

      // Center baseline (0.00)
      ctx.strokeStyle = 'rgba(150, 150, 150, 0.4)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(0, mid);
      ctx.lineTo(w, mid);
      ctx.stroke();

      const mainline = tree.activeLine();
      const total = Math.max(1, mainline.length);

      const xFor = (i: number) => (total <= 1 ? w / 2 : (i / (total - 1)) * (w - 20) + 10);
      const yFor = (cp: number) => {
        // High positive cp (White ahead) -> higher on screen (smaller Y)
        // Negative cp (Black ahead) -> lower on screen (larger Y)
        const pct = 50 + 50 * Math.tanh(cp / 380);
        return Math.max(6, Math.min(h - 6, h - (pct / 100) * h));
      };

      if (mainline.length > 0) {
        // Draw Area Fill to Baseline
        ctx.beginPath();
        mainline.forEach((nd, i) => {
          let cp = nd.evalCp;
          if (cp === undefined) {
            // Fast heuristic fallback
            const c = new Chess(nd.fenAfter);
            cp = (c.material('w') - c.material('b')) * 100;
          }
          const x = xFor(i);
          const y = yFor(cp);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });

        const lastX = xFor(mainline.length - 1);
        const firstX = xFor(0);
        ctx.lineTo(lastX, mid);
        ctx.lineTo(firstX, mid);
        ctx.closePath();

        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, `${themeCfg.hex}66`);
        grad.addColorStop(0.5, `${themeCfg.hex}14`);
        grad.addColorStop(1, 'rgba(100, 116, 139, 0.35)');
        ctx.fillStyle = grad;
        ctx.fill();

        // Draw Continuous Evaluation Curve
        ctx.beginPath();
        mainline.forEach((nd, i) => {
          let cp = nd.evalCp;
          if (cp === undefined) {
            const c = new Chess(nd.fenAfter);
            cp = (c.material('w') - c.material('b')) * 100;
          }
          const x = xFor(i);
          const y = yFor(cp);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.strokeStyle = themeCfg.hex;
        ctx.lineWidth = 2.2;
        ctx.stroke();

        // Current Active Position Glowing Marker
        const curIdx = mainline.indexOf(tree.current);
        if (curIdx >= 0) {
          const cp = tree.current.evalCp !== undefined ? tree.current.evalCp : 0;
          const cx = xFor(curIdx);
          const cy = yFor(cp);
          ctx.beginPath();
          ctx.arc(cx, cy, 5, 0, Math.PI * 2);
          ctx.fillStyle = themeCfg.hex;
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }
    };

    renderGraph();

    const resizeObserver = new ResizeObserver(() => {
      renderGraph();
    });
    if (canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    return () => {
      resizeObserver.disconnect();
    };
  }, [tree, engineLines, reviewReport]);

  const handleApplyMove = (from: Square, to: Square, promo?: string) => {
    const res = tree.addMove(sqName(from), sqName(to), promo);
    if (res) {
      if (soundEnabled) {
        if (res.san?.includes('+')) globalAudio.check();
        else if (res.uci?.promotion) globalAudio.promote();
        else globalAudio.move();
      }
      setTree(tree.clone());
    }
  };

  // Run full game review
  const handleStartGameReview = async () => {
    setIsReviewing(true);
    setReviewProgress({ current: 1, total: tree.mainline().length + 1 });
    globalEngine.stop();

    try {
      const reviewer = new GameReviewer();
      const report = await reviewer.runReview(tree, (cur, tot) => {
        setReviewProgress({ current: cur, total: tot });
      });
      setReviewReport(report);
      setShowReviewModal(true);
      setTree(tree.clone());
    } catch (err) {
      console.error(err);
    } finally {
      setIsReviewing(false);
      setReviewProgress(null);
      triggerLiveAnalysis();
    }
  };

  // Build engine arrows from live PV lines
  const visibleEngineLines = !isEngineOn || !multiPVEnabled
    ? []
    : engineLines.slice(0, Math.min(multiPV, 5));

  const engineArrows: ArrowData[] = visibleEngineLines
    .map((line, idx) => {
      const uci = line.pv[0];
      if (!uci || uci.length < 4) return null;
      return {
        from: nameToSq(uci.slice(0, 2)),
        to: nameToSq(uci.slice(2, 4)),
        tier: (idx === 0 ? 'best' : idx === 1 ? 'second' : 'third') as any,
      };
    })
    .filter(Boolean) as ArrowData[];

  // Format Eval string
  const formatScore = (score?: { cp?: number; mate?: number }) => {
    if (!score) return '0.00';
    if (score.mate !== undefined) {
      return (score.mate > 0 ? '+M' : '-M') + Math.abs(score.mate);
    }
    const val = (score.cp || 0) / 100;
    return (val > 0 ? '+' : '') + val.toFixed(2);
  };

  const topScore = engineLines[0]?.score;
  const chess = tree.chess;
  const lastMoveData = tree.current.uci
    ? { from: nameToSq(tree.current.uci.from), to: nameToSq(tree.current.uci.to) }
    : null;
  const checkSq = chess.inCheck(chess.turn) ? chess.kingSquare(chess.turn) : null;
  const opening = tree.currentOpening();

  // Eval Bar Height calculation
  const getEvalBarHeight = () => {
    if (!topScore) return 50;
    if (topScore.mate !== undefined) return topScore.mate > 0 ? 98 : 2;
    const pct = 50 + 50 * Math.tanh((topScore.cp || 0) / 380);
    return Math.max(2, Math.min(98, pct));
  };

  return (
    <div className="w-full flex-1 flex flex-col lg:grid lg:grid-cols-[280px_minmax(360px,1fr)_340px] gap-4 p-3 sm:p-5 max-w-7xl mx-auto">
      {/* Left Column: Variations Tree & Comments */}
      <div className="flex flex-col gap-3 order-2 lg:order-1">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col h-72 lg:h-[420px] shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
            <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Move Tree
            </h3>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  if (tree.current.parent) {
                    tree.deleteNode(tree.current);
                    setTree(tree.clone());
                  }
                }}
                disabled={!tree.current.parent}
                className="p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-500 hover:text-red-500 disabled:opacity-30 transition-colors"
                title="Delete Current Variation"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  if (tree.current.parent) {
                    tree.promoteToMainline(tree.current);
                    setTree(tree.clone());
                  }
                }}
                disabled={!tree.current.parent}
                className="p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-500 hover:text-amber-500 disabled:opacity-30 transition-colors"
                title="Promote to Mainline"
              >
                <ArrowUpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Move Tree Container */}
          <div className="flex-1 overflow-y-auto py-2 font-mono text-xs space-y-1">
            {tree.mainline().length === 0 ? (
              <div className="h-full flex items-center justify-center text-stone-400 text-xs italic">
                Play moves on the board to branch variations
              </div>
            ) : (
              <div className="flex flex-wrap gap-x-2 gap-y-1 text-stone-800 dark:text-stone-300">
                {tree.mainline().map((mNode) => {
                  const num = Math.ceil(mNode.ply / 2);
                  const isWhiteMove = mNode.ply % 2 === 1;
                  return (
                    <span key={`node-${mNode.id}`} className="inline-flex items-center gap-1">
                      {isWhiteMove && (
                        <span className="text-stone-400 text-[11px]">{num}.</span>
                      )}
                      <button
                        onClick={() => {
                          tree.goTo(mNode);
                          setTree(tree.clone());
                        }}
                        className={`px-1.5 py-0.5 rounded text-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
                          tree.current === mNode
                            ? `${themeCfg.activeTabClass}`
                            : 'hover:bg-stone-100 dark:hover:bg-stone-800'
                        }`}
                      >
                        <span className="font-semibold">{mNode.san}</span>
                        {mNode.classification && (() => {
                          const badge = CLASSIFICATION_CONFIGS[mNode.classification];
                          if (!badge) return null;
                          return (
                            <span
                              className={`inline-flex items-center justify-center min-w-[14px] h-[14px] px-1 rounded-full text-[9px] font-sans font-black leading-none shadow-2xs ${badge.bgClass} ${badge.textClass}`}
                              title={badge.label}
                            >
                              {badge.iconType === 'book' ? '📖' : badge.badgeText}
                            </span>
                          );
                        })()}
                      </button>
                    </span>
                  );
                })}
              </div>
            )}
          </div>

          {/* Comment input on current position */}
          <div className="pt-2 border-t border-stone-200 dark:border-stone-800">
            <input
              type="text"
              placeholder="Add annotation / note to this move..."
              value={tree.current.comment || ''}
              onChange={(e) => {
                tree.setComment(e.target.value);
                setTree(tree.clone());
              }}
              className={`w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg px-2.5 py-1.5 text-xs text-stone-800 dark:text-stone-200 placeholder-stone-400 focus:outline-hidden focus:${themeCfg.borderClass}`}
            />
          </div>
        </div>

        {/* Evaluation Graph */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-3 flex flex-col gap-2 shadow-xs">
          <div className="flex items-center justify-between text-[11px] font-mono text-stone-500 dark:text-stone-400">
            <span>Evaluation Graph</span>
            <span className={`${themeCfg.textClass} font-semibold`}>
              {opening ? `${opening.eco} · ${opening.name}` : 'Custom Line'}
            </span>
          </div>
          <canvas
            ref={canvasRef}
            className="w-full h-16 rounded bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 cursor-pointer"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const frac = (e.clientX - rect.left) / rect.width;
              const line = tree.activeLine();
              if (line.length) {
                const targetIdx = Math.max(
                  0,
                  Math.min(line.length - 1, Math.round(frac * (line.length - 1)))
                );
                tree.goTo(line[targetIdx]);
                setTree(tree.clone());
              }
            }}
          />
        </div>
      </div>

      {/* Center Column: Chessboard & Eval Bar */}
      <div className="flex flex-col items-center gap-3 order-1 lg:order-2">
        {/* Top Info Bar */}
        <div className="w-full max-w-[640px] flex items-center justify-between p-2.5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xs">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
              {opening ? opening.name : 'Chess Analysis Board'}
            </span>
            {opening && (
              <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${themeCfg.badgeBg}`}>
                {opening.eco}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {onOpenEditor && (
              <button
                id="analysis-open-editor-btn"
                onClick={() => onOpenEditor(chess.fen())}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors"
                title="Open position in Board Editor"
              >
                <Edit3 className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
                <span>Edit in Editor</span>
              </button>
            )}

            <button
              id="analysis-review-btn"
              onClick={() => handleStartGameReview()}
              disabled={isReviewing || tree.mainline().length === 0}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs shadow-xs transition-colors cursor-pointer disabled:opacity-40 ${themeCfg.primaryClass}`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isReviewing ? 'Reviewing...' : 'Game Review'}</span>
            </button>
          </div>
        </div>

        {/* Board with Eval Bar */}
        <div className="w-full max-w-[640px] flex gap-2.5 items-stretch">
          {/* Vertical Evaluation Bar */}
          <div
            className="w-4 rounded-lg bg-stone-200 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 relative overflow-hidden flex flex-col justify-end shadow-inner"
            title={`Eval: ${formatScore(topScore)}`}
          >
            <div
              className={`w-full ${themeCfg.primaryClass.split(' ')[0]} transition-all duration-300 ease-out`}
              style={{ height: `${getEvalBarHeight()}%` }}
            />
            <div className="absolute inset-x-0 top-1/2 h-0.5 bg-stone-950/30" />
          </div>

          {/* The Board */}
          <div className="flex-1">
            <Chessboard
              board={chess.board}
              orientation={boardOrientation}
              turn={chess.turn}
              interactive={true}
              canSelect={(sq) => {
                const p = chess.board[sq];
                return !!p && colorOf(p) === chess.turn;
              }}
              getLegalTargets={(sq) => chess.getLegalTargetsForSquare(sq)}
              onMove={(from, to, promo) => handleApplyMove(from, to, promo)}
              lastMove={lastMoveData}
              lastMoveClassification={tree.current.classification}
              checkSquare={checkSq}
              engineArrows={engineArrows}
              boardTheme={boardTheme}
              pieceTheme={pieceTheme}
              pieceStyle={pieceStyle}
              animationEnabled={animationEnabled}
              animationSpeed={animationSpeed}
              dragRefreshRate={dragRefreshRate}
              dragAndDropEnabled={dragAndDropEnabled}
              autoQueenEnabled={autoQueenEnabled}
              showCoordinates={showCoordinates}
              showLegalMoves={showLegalMoves}
              showCheckHighlight={showCheckHighlight}
              showLastMoveHighlight={showLastMoveHighlight}
              uiTheme={uiTheme}
            />
          </div>
        </div>

        {/* Reorganized Modern Board Toolbar */}
        <div className="w-full max-w-[640px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-2 shadow-xs flex flex-wrap items-center justify-between gap-2">
          {/* Navigation Controls Group */}
          <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-950 p-1 rounded-lg border border-stone-200/80 dark:border-stone-800">
            <button
              onClick={() => {
                tree.toStart();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded-md hover:bg-stone-200 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="First Move (Start)"
            >
              <ChevronsLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                tree.back();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded-md hover:bg-stone-200 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Previous Move (Left Arrow)"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                tree.forward();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded-md hover:bg-stone-200 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Next Move (Right Arrow)"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                tree.toEnd();
                setTree(tree.clone());
              }}
              className="p-1.5 rounded-md hover:bg-stone-200 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Last Move (End)"
            >
              <ChevronsRight className="w-4 h-4" />
            </button>
            <div className="w-[1px] h-4 bg-stone-300 dark:bg-stone-700 mx-0.5" />
            <button
              onClick={() => setBoardOrientation((prev) => (prev === 'w' ? 'b' : 'w'))}
              className="p-1.5 rounded-md hover:bg-stone-200 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors cursor-pointer"
              title="Flip Board Orientation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Action Tools Group */}
          <div className="flex items-center gap-1.5">
            <button
              id="analysis-import-export-btn"
              onClick={() => {
                setModalTab('pgn');
                setPgnInput(tree.toPGN());
                setFenInput(chess.fen());
                setImportExportModal(true);
              }}
              className="px-2.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Upload className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
              <span>PGN / FEN</span>
            </button>

            <button
              onClick={() => {
                navigator.clipboard.writeText(chess.fen());
                setCopiedText(true);
                setTimeout(() => setCopiedText(false), 1500);
              }}
              className="px-2.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Copy current FEN to clipboard"
            >
              {copiedText ? (
                <Check className="w-3.5 h-3.5 text-emerald-500" />
              ) : (
                <Copy className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
              )}
              <span>{copiedText ? 'Copied!' : 'Copy FEN'}</span>
            </button>

            {onOpenEditor && (
              <button
                onClick={() => onOpenEditor(chess.fen())}
                className="px-2.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Open position in Board Editor"
              >
                <Edit3 className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
                <span>Editor</span>
              </button>
            )}

            <button
              onClick={() => {
                tree.reset();
                setTree(new GameTree());
              }}
              className="px-2.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-red-100 dark:hover:bg-red-950/60 hover:text-red-600 dark:hover:text-red-400 text-stone-700 dark:text-stone-300 text-xs font-semibold border border-stone-200 dark:border-stone-700 transition-colors flex items-center gap-1 cursor-pointer"
              title="Reset Board to Starting Position"
            >
              <Trash2 className="w-3.5 h-3.5 opacity-70" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>

      {/* Right Column: Engine Readout & Multi-PV Lines */}
      <div className="flex flex-col gap-3 order-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col gap-3 shadow-xs">
          <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-500" />
              <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
                Evaluation
              </h3>
            </div>
            <label className="flex items-center gap-1.5 text-xs text-stone-700 dark:text-stone-300 font-mono cursor-pointer">
              <input
                type="checkbox"
                checked={userEnginePref}
                onChange={(e) => handleToggleEngine(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <span>Engine {userEnginePref ? 'ON' : 'OFF'}</span>
            </label>
          </div>

          {/* Engine Header: Score & Depth */}
          <div className="flex items-baseline justify-between">
            <span className={`text-3xl font-mono font-black ${themeCfg.textClass}`}>
              {formatScore(topScore)}
            </span>
            <div className="text-right text-[11px] font-mono text-stone-500 dark:text-stone-400">
              <div>
                Depth: <span className="text-stone-800 dark:text-stone-200 font-bold">{engineStats.depth}</span>
              </div>
              <div>
                Speed:{' '}
                <span className="text-stone-800 dark:text-stone-200">
                  {engineStats.nps > 1000
                    ? `${(engineStats.nps / 1000).toFixed(0)}k`
                    : engineStats.nps}{' '}
                  n/s
                </span>
              </div>
            </div>
          </div>

          {/* Optimization Mode Badge */}
          <div className="p-2 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Cpu className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
              <span className="text-[11px] font-mono text-stone-700 dark:text-stone-300 font-medium">
                Device Optimization
              </span>
            </div>
            <button
              onClick={() => {
                const next = !optimizationMode;
                setOptimizationMode(next);
                try {
                  localStorage.setItem('aperture_optimization_mode', String(next));
                } catch {}
              }}
              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-colors ${
                optimizationMode
                  ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                  : 'bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
              }`}
            >
              {optimizationMode ? 'ENABLED' : 'OFF'}
            </button>
          </div>

          {/* Multi-PV Candidates */}
          <div className="space-y-1.5 pt-1 border-t border-stone-200 dark:border-stone-800">
            <span className="text-[10px] font-mono uppercase tracking-wider text-stone-500 dark:text-stone-400">
              Top Engine Lines
            </span>

            {visibleEngineLines.length === 0 ? (
              <div className="text-xs text-stone-400 font-mono py-2 italic">
                {isEngineOn ? 'Calculating position...' : 'Engine paused'}
              </div>
            ) : (
              visibleEngineLines.map((line, idx) => (
                <div
                  key={`pv-${idx}`}
                  className="p-2 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800/80 font-mono text-xs flex flex-col gap-0.5 transition-colors"
                >
                  <div className={`flex justify-between items-center ${themeCfg.textClass} font-bold`}>
                    <span>
                      #{idx + 1} {formatScore(line.score)}
                    </span>
                    <span className="text-[10px] text-stone-500 dark:text-stone-400">
                      Best: {line.pv[0] || '-'}
                    </span>
                  </div>
                  <div className="text-[11px] text-stone-600 dark:text-stone-400 truncate">
                    {line.pv.slice(0, 6).join(' ')}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Engine Configuration & Depth Customization */}
          <div className="pt-2 border-t border-stone-200 dark:border-stone-800 space-y-3">
            {/* Depth Cap Control */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px] font-mono text-stone-500 dark:text-stone-400">
                <span>
                  Depth Limit: <strong className={`${themeCfg.textClass} font-bold`}>{depthCap} plies</strong>
                </span>
                <span className="text-[10px] text-stone-400">
                  {depthCap <= 10 ? 'Fast/Mobile' : depthCap <= 14 ? 'Balanced' : depthCap <= 18 ? 'Deep' : 'Master'}
                </span>
              </div>
              <input
                type="range"
                min="6"
                max="22"
                value={depthCap}
                onChange={(e) => {
                  const val = +e.target.value;
                  setDepthCap(val);
                  try {
                    localStorage.setItem('aperture_depth_cap', String(val));
                  } catch {}
                }}
                className="w-full cursor-pointer"
                style={{ accentColor: themeCfg.hex }}
              />
              {/* Depth Presets */}
              <div className="grid grid-cols-4 gap-1 pt-0.5">
                {[
                  { d: 10, label: 'Fast (10)' },
                  { d: 14, label: 'Standard (14)' },
                  { d: 18, label: 'Deep (18)' },
                  { d: 22, label: 'Ultra (22)' },
                ].map((preset) => (
                  <button
                    key={preset.d}
                    onClick={() => {
                      setDepthCap(preset.d);
                      try {
                        localStorage.setItem('aperture_depth_cap', String(preset.d));
                      } catch {}
                    }}
                    className={`px-1 py-1 rounded text-[10px] font-mono font-medium transition-colors ${
                      depthCap === preset.d
                        ? `${themeCfg.activeTabClass}`
                        : 'bg-stone-50 dark:bg-stone-950 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 border border-stone-200 dark:border-stone-800'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Multi-PV Selection & Enable/Disable Toggle */}
            <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
              <div className="flex justify-between items-center text-[11px] font-mono text-stone-500 dark:text-stone-400">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-stone-800 dark:text-stone-200">Multi-PV Engine Lines:</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${multiPVEnabled ? themeCfg.badgeBg : 'bg-stone-200 dark:bg-stone-800 text-stone-500'}`}>
                    {multiPVEnabled ? `${multiPV} ${multiPV === 1 ? 'Line' : 'Lines'}` : '0 Lines (Disabled)'}
                  </span>
                </div>
                <button
                  onClick={() => {
                    const next = !multiPVEnabled;
                    setMultiPVEnabled(next);
                    if (next && multiPV < 1) {
                      setMultiPV(1);
                      try {
                        localStorage.setItem('aperture_analysis_multipv', '1');
                      } catch {}
                    }
                    try {
                      localStorage.setItem('aperture_analysis_multipv_enabled', String(next));
                    } catch {}
                  }}
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold transition-all cursor-pointer ${
                    multiPVEnabled
                      ? themeCfg.activeTabClass
                      : 'bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-300 dark:hover:bg-stone-700'
                  }`}
                >
                  {multiPVEnabled ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Line Count Selector (Active when enabled) */}
              {multiPVEnabled ? (
                <div className="flex items-center justify-between gap-1 pt-1">
                  <span className="text-[10px] text-stone-400">Simultaneous Lines:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((count) => (
                      <button
                        key={count}
                        onClick={() => {
                          setMultiPV(count);
                          try {
                            localStorage.setItem('aperture_analysis_multipv', String(count));
                          } catch {}
                        }}
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-colors cursor-pointer ${
                          multiPV === count
                            ? themeCfg.activeTabClass
                            : 'bg-stone-50 dark:bg-stone-950 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 border border-stone-200 dark:border-stone-800'
                        }`}
                      >
                        {count} {count === 1 ? 'Line' : 'Lines'}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-[10px] text-stone-400 italic">
                  Multi-PV disabled (0 lines). Single evaluation mode active for maximum speed.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Full Game Review Modal */}
      {showReviewModal && reviewReport && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-xl w-full p-6 flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2">
                <Sparkles className={`w-5 h-5 ${themeCfg.textClass}`} />
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 font-serif">
                  Game Review Report
                </h3>
              </div>
              <button
                onClick={() => setShowReviewModal(false)}
                className="text-stone-400 hover:text-stone-700 dark:hover:white text-sm"
              >
                ✕
              </button>
            </div>

            {/* Accuracy Overview Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 text-center">
                <span className="text-xs font-mono uppercase text-stone-500 dark:text-stone-400">White Accuracy</span>
                <div className="text-3xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                  {reviewReport.whiteAccuracy}%
                </div>
                <span className="text-[10px] text-stone-400 font-mono">
                  Avg Loss: {reviewReport.whiteAvgLoss} cp
                </span>
              </div>

              <div className="p-4 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 text-center">
                <span className="text-xs font-mono uppercase text-stone-500 dark:text-stone-400">Black Accuracy</span>
                <div className="text-3xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                  {reviewReport.blackAccuracy}%
                </div>
                <span className="text-[10px] text-stone-400 font-mono">
                  Avg Loss: {reviewReport.blackAvgLoss} cp
                </span>
              </div>
            </div>

            {/* Tactical Breakdown Table */}
            <div className="space-y-2">
              <span className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
                Move Classification Breakdown
              </span>
              <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                {[
                  { label: '📘 Book Moves', key: 'book', color: 'text-blue-600 dark:text-blue-400 font-bold' },
                  { label: '✨ Brilliant', key: 'brilliant', color: 'text-cyan-500 font-bold' },
                  { label: '⭐ Best Moves', key: 'best', color: 'text-emerald-500 font-bold' },
                  { label: '🟢 Excellent', key: 'excellent', color: 'text-emerald-600 dark:text-emerald-300' },
                  { label: '⚪ Good', key: 'good', color: 'text-stone-600 dark:text-stone-300' },
                  { label: '🟡 Inaccuracies', key: 'inaccuracy', color: 'text-yellow-600 dark:text-yellow-400' },
                  { label: '🟠 Mistakes', key: 'mistake', color: 'text-orange-500' },
                  { label: '🔴 Blunders', key: 'blunder', color: 'text-red-500' },
                  { label: '❌ Missed Wins', key: 'missedwin', color: 'text-purple-600 dark:text-purple-400' },
                ].map((item) => (
                  <div
                    key={item.key}
                    className="p-2 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 flex flex-col justify-between"
                  >
                    <span className={`text-[11px] truncate ${item.color}`}>{item.label}</span>
                    <div className="flex items-center justify-between text-[10px] text-stone-600 dark:text-stone-400 font-mono mt-1">
                      <span>W: {reviewReport.whiteCounts[item.key as any] || 0}</span>
                      <span>B: {reviewReport.blackCounts[item.key as any] || 0}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Move-by-Move Review List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
                  Move-by-Move Analysis ({reviewReport.moves.length} moves)
                </span>
                <span className="text-[10px] text-stone-500 font-mono">Click a move to inspect</span>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1 no-scrollbar border border-stone-200 dark:border-stone-800 rounded-xl p-2 bg-stone-50 dark:bg-stone-950">
                {reviewReport.moves.map((m, idx) => {
                  const isWhite = m.moverColor === 'w';
                  const moveNumber = Math.ceil(m.ply / 2);
                  const isCurrent = tree.current === m.node;

                  const cfg = CLASSIFICATION_CONFIGS[m.classification];

                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        tree.goTo(m.node);
                        setTree(tree.clone());
                        setShowReviewModal(false);
                      }}
                      className={`w-full p-2.5 rounded-lg border text-left transition-all flex flex-col gap-1 cursor-pointer ${
                        isCurrent
                          ? `${themeCfg.subtleBgClass} ${themeCfg.borderClass}`
                          : 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800/80 hover:border-stone-400 dark:hover:border-stone-600'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 font-mono">
                          <span className="text-xs font-bold text-stone-500">
                            {isWhite ? `${moveNumber}.` : `${moveNumber}...`}
                          </span>
                          <span className="text-xs font-black text-stone-900 dark:text-stone-100">{m.san}</span>
                          {cfg && (
                            <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border font-bold ${cfg.bgClass} ${cfg.textClass} ${cfg.ringClass}`}>
                              <span>{cfg.iconType === 'book' ? '📖' : cfg.badgeText}</span>
                              <span>{cfg.label}</span>
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-[11px] font-mono">
                          <span className="text-stone-600 dark:text-stone-400">
                            Eval: {(m.afterEval / 100).toFixed(2)}
                          </span>
                          {m.cpLoss > 15 && (
                            <span className="text-red-500 text-[10px] font-semibold">
                              -{m.cpLoss} cp
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-[11px] text-stone-600 dark:text-stone-400 leading-tight">
                        {m.explanation}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              onClick={() => setShowReviewModal(false)}
              className={`w-full py-2.5 rounded-xl font-bold text-xs shadow-md transition-colors cursor-pointer ${themeCfg.primaryClass}`}
            >
              Explore Moves in Analysis
            </button>
          </div>
        </div>
      )}

      {/* Unified Import / Export Modal */}
      {importExportModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-lg w-full p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
              <div className="flex gap-2">
                <button
                  onClick={() => setModalTab('pgn')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-colors ${
                    modalTab === 'pgn'
                      ? themeCfg.activeTabClass
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
                  }`}
                >
                  PGN Notation
                </button>
                <button
                  onClick={() => setModalTab('fen')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-colors ${
                    modalTab === 'fen'
                      ? themeCfg.activeTabClass
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400'
                  }`}
                >
                  FEN String
                </button>
              </div>
              <button
                onClick={() => setImportExportModal(false)}
                className="text-stone-400 hover:text-stone-700 dark:hover:white text-sm"
              >
                ✕
              </button>
            </div>

            {modalTab === 'pgn' ? (
              <div className="space-y-3">
                <textarea
                  value={pgnInput}
                  onChange={(e) => setPgnInput(e.target.value)}
                  placeholder="Paste PGN movetext or complete game notation here..."
                  className={`w-full h-44 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden focus:${themeCfg.borderClass}`}
                />
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(tree.toPGN());
                      setCopiedText(true);
                      setTimeout(() => setCopiedText(false), 1500);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold flex items-center gap-1"
                  >
                    {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />}
                    <span>{copiedText ? 'Copied' : 'Copy Current PGN'}</span>
                  </button>
                  <button
                    onClick={() => {
                      try {
                        const newTree = new GameTree();
                        newTree.loadPGN(pgnInput);
                        setTree(newTree);
                        setImportExportModal(false);
                      } catch (err: any) {
                        alert('Invalid PGN: ' + err.message);
                      }
                    }}
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                  >
                    Load PGN
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <input
                  type="text"
                  value={fenInput}
                  onChange={(e) => setFenInput(e.target.value)}
                  placeholder="Paste FEN position string here..."
                  className={`w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden focus:${themeCfg.borderClass}`}
                />
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(chess.fen());
                      setCopiedText(true);
                      setTimeout(() => setCopiedText(false), 1500);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold flex items-center gap-1"
                  >
                    {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />}
                    <span>{copiedText ? 'Copied' : 'Copy Current FEN'}</span>
                  </button>
                  <button
                    onClick={() => {
                      try {
                        const newTree = new GameTree(fenInput);
                        setTree(newTree);
                        setImportExportModal(false);
                      } catch (err: any) {
                        alert('Invalid FEN: ' + err.message);
                      }
                    }}
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold shadow-md cursor-pointer ${themeCfg.primaryClass}`}
                  >
                    Load FEN
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
