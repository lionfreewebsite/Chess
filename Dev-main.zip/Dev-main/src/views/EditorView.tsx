import React, { useState, useEffect } from 'react';
import {
  Trash2,
  RotateCcw,
  Activity,
  Copy,
  Check,
  CheckCircle2,
  Sparkles,
  Upload,
  FileText,
  Bookmark,
  Save,
  FolderDown,
  Trash,
  Plus,
  Play,
} from 'lucide-react';
import { Chessboard } from '../components/Chessboard/Chessboard';
import { ChessPieceSvg } from '../components/Chessboard/ChessPieceSvg';
import { GameTree } from '../engine/gameTree';
import {
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  Square,
  AnimationSpeed,
  DragRefreshRate,
  SavedPosition,
  UIThemeColor,
} from '../types/chess';
import { Chess, START_FEN, sqOf, sqName } from '../engine/chessRules';
import { getThemeConfig } from '../utils/themeColors';

interface EditorViewProps {
  initialFen?: string;
  onAnalyzePosition: (tree: GameTree) => void;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  dragRefreshRate?: DragRefreshRate;
  dragAndDropEnabled?: boolean;
  autoQueenEnabled?: boolean;
  showCoordinates?: boolean;
  showLegalMoves?: boolean;
  showCheckHighlight?: boolean;
  showLastMoveHighlight?: boolean;
  uiTheme?: UIThemeColor;
}

export const EditorView: React.FC<EditorViewProps> = ({
  initialFen,
  onAnalyzePosition,
  boardTheme,
  pieceTheme,
  pieceStyle,
  animationEnabled = true,
  animationSpeed = 'normal',
  dragRefreshRate = '60fps',
  dragAndDropEnabled = true,
  autoQueenEnabled = false,
  showCoordinates = true,
  showLegalMoves = true,
  showCheckHighlight = true,
  showLastMoveHighlight = true,
  uiTheme,
}) => {
  const themeCfg = getThemeConfig(uiTheme);
  const [board, setBoard] = useState<(string | null)[]>(() => {
    try {
      const c = new Chess(initialFen || START_FEN);
      return [...c.board];
    } catch {
      const c = new Chess();
      return [...c.board];
    }
  });

  const [turn, setTurn] = useState<PieceColor>(() => {
    try {
      if (initialFen) {
        const parts = initialFen.trim().split(/\s+/);
        if (parts[1] === 'b') return 'b';
      }
    } catch {}
    return 'w';
  });

  useEffect(() => {
    if (initialFen) {
      try {
        const c = new Chess(initialFen);
        setBoard([...c.board]);
        setTurn(c.turn);
        setCastling({ ...c.castling });
      } catch {}
    }
  }, [initialFen]);

  const [castling, setCastling] = useState<{ K: boolean; Q: boolean; k: boolean; q: boolean }>(() => {
    try {
      if (initialFen) {
        const parts = initialFen.trim().split(/\s+/);
        const castStr = parts[2] || '';
        return {
          K: castStr.includes('K'),
          Q: castStr.includes('Q'),
          k: castStr.includes('k'),
          q: castStr.includes('q'),
        };
      }
    } catch {}
    return { K: true, Q: true, k: true, q: true };
  });

  const [selectedPalettePiece, setSelectedPalettePiece] = useState<string | null>('P');
  const [copiedFen, setCopiedFen] = useState<boolean>(false);
  const [copiedPgn, setCopiedPgn] = useState<boolean>(false);

  // Saved Positions State
  const [savedPositions, setSavedPositions] = useState<SavedPosition[]>(() => {
    try {
      const data = localStorage.getItem('aperture_saved_positions');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });
  const [saveModalOpen, setSaveModalOpen] = useState<boolean>(false);
  const [saveName, setSaveName] = useState<string>('');
  const [saveNotes, setSaveNotes] = useState<string>('');

  // Import Modal State
  const [importModalOpen, setImportModalOpen] = useState<boolean>(false);
  const [importTab, setImportTab] = useState<'fen' | 'pgn' | 'saved'>('fen');
  const [importInput, setImportInput] = useState<string>('');
  const [importError, setImportError] = useState<string | null>(null);

  // Sync if initialFen changes
  useEffect(() => {
    if (initialFen) {
      try {
        const c = new Chess(initialFen);
        setBoard([...c.board]);
        setTurn(c.turn);
        const parts = initialFen.trim().split(/\s+/);
        const castStr = parts[2] || '';
        setCastling({
          K: castStr.includes('K'),
          Q: castStr.includes('Q'),
          k: castStr.includes('k'),
          q: castStr.includes('q'),
        });
      } catch {}
    }
  }, [initialFen]);

  // Persist saved positions
  const handleSavePosition = () => {
    const title = saveName.trim() || `Custom Position ${savedPositions.length + 1}`;
    const newPos: SavedPosition = {
      id: 'pos_' + Date.now(),
      name: title,
      fen: currentFEN,
      pgn: computePGN(),
      timestamp: Date.now(),
      notes: saveNotes.trim() || undefined,
    };
    const updated = [newPos, ...savedPositions];
    setSavedPositions(updated);
    try {
      localStorage.setItem('aperture_saved_positions', JSON.stringify(updated));
    } catch {}
    setSaveName('');
    setSaveNotes('');
    setSaveModalOpen(false);
  };

  const handleDeleteSavedPosition = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedPositions.filter((p) => p.id !== id);
    setSavedPositions(updated);
    try {
      localStorage.setItem('aperture_saved_positions', JSON.stringify(updated));
    } catch {}
  };

  const loadPositionFromFen = (fenStr: string) => {
    try {
      const c = new Chess(fenStr);
      setBoard([...c.board]);
      setTurn(c.turn);
      const parts = fenStr.trim().split(/\s+/);
      const castStr = parts[2] || '';
      setCastling({
        K: castStr.includes('K'),
        Q: castStr.includes('Q'),
        k: castStr.includes('k'),
        q: castStr.includes('q'),
      });
      return true;
    } catch (err: any) {
      return false;
    }
  };

  const PIECE_PALETTE = ['K', 'Q', 'R', 'B', 'N', 'P', 'k', 'q', 'r', 'b', 'n', 'p'];

  // Construct FEN from current editor state
  const computeFEN = () => {
    let fen = '';
    for (let r = 7; r >= 0; r--) {
      let empty = 0;
      for (let f = 0; f < 8; f++) {
        const sq = sqOf(f, r);
        const p = board[sq];
        if (!p) {
          empty++;
        } else {
          if (empty > 0) {
            fen += empty;
            empty = 0;
          }
          fen += p;
        }
      }
      if (empty > 0) fen += empty;
      if (r > 0) fen += '/';
    }

    fen += ` ${turn} `;

    let cast = '';
    if (castling.K) cast += 'K';
    if (castling.Q) cast += 'Q';
    if (castling.k) cast += 'k';
    if (castling.q) cast += 'q';
    fen += cast.length > 0 ? cast : '-';

    fen += ' - 0 1';
    return fen;
  };

  const currentFEN = computeFEN();

  const computePGN = () => {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '.');
    return `[Event "Aperture Board Editor Position"]
[Site "Aperture Chess Workbench"]
[Date "${today}"]
[Round "1"]
[White "${turn === 'w' ? 'White to move' : 'White'}"]
[Black "${turn === 'b' ? 'Black to move' : 'Black'}"]
[Result "*"]
[SetUp "1"]
[FEN "${currentFEN}"]

*`;
  };

  // Click on board square in editor
  const handleSquareClick = (sq: Square) => {
    const newBoard = [...board];
    if (selectedPalettePiece === 'trash') {
      newBoard[sq] = null;
    } else if (selectedPalettePiece) {
      newBoard[sq] = selectedPalettePiece;
    } else {
      newBoard[sq] = null;
    }
    setBoard(newBoard);
  };

  // Preset Clear / Reset
  const handleClearBoard = () => {
    setBoard(new Array(64).fill(null));
    setCastling({ K: false, Q: false, k: false, q: false });
  };

  const handleResetStarting = () => {
    const c = new Chess(START_FEN);
    setBoard([...c.board]);
    setTurn('w');
    setCastling({ K: true, Q: true, k: true, q: true });
  };

  // Validate Position
  const validatePosition = (): { valid: boolean; error?: string } => {
    let whiteKing = 0;
    let blackKing = 0;
    for (let sq = 0; sq < 64; sq++) {
      if (board[sq] === 'K') whiteKing++;
      if (board[sq] === 'k') blackKing++;
      const rank = Math.floor(sq / 8);
      if ((board[sq] === 'P' || board[sq] === 'p') && (rank === 0 || rank === 7)) {
        return { valid: false, error: 'Pawns cannot be placed on the 1st or 8th rank.' };
      }
    }
    if (whiteKing !== 1) return { valid: false, error: 'Board must contain exactly 1 White King.' };
    if (blackKing !== 1) return { valid: false, error: 'Board must contain exactly 1 Black King.' };

    try {
      const c = new Chess(currentFEN);
      return { valid: true };
    } catch (err: any) {
      return { valid: false, error: err.message || 'Invalid position setup.' };
    }
  };

  const status = validatePosition();

  // Load into Analysis
  const handleLoadToAnalysis = () => {
    if (!status.valid) return;
    try {
      const tree = new GameTree(currentFEN);
      onAnalyzePosition(tree);
    } catch (err) {
      console.error(err);
    }
  };

  // Process Import Modal
  const handleProcessImport = () => {
    setImportError(null);
    const raw = importInput.trim();
    if (!raw) {
      setImportError('Please enter FEN or PGN text.');
      return;
    }

    if (importTab === 'fen') {
      try {
        const c = new Chess(raw);
        setBoard([...c.board]);
        setTurn(c.turn);
        const parts = raw.split(/\s+/);
        const castStr = parts[2] || '';
        setCastling({
          K: castStr.includes('K'),
          Q: castStr.includes('Q'),
          k: castStr.includes('k'),
          q: castStr.includes('q'),
        });
        setImportModalOpen(false);
        setImportInput('');
      } catch (err: any) {
        setImportError(err.message || 'Invalid FEN notation format.');
      }
    } else {
      // PGN Parsing
      try {
        const tree = GameTree.fromPGN(raw);
        const endFen = tree.chess.fen();
        const c = new Chess(endFen);
        setBoard([...c.board]);
        setTurn(c.turn);
        const parts = endFen.split(/\s+/);
        const castStr = parts[2] || '';
        setCastling({
          K: castStr.includes('K'),
          Q: castStr.includes('Q'),
          k: castStr.includes('k'),
          q: castStr.includes('q'),
        });
        setImportModalOpen(false);
        setImportInput('');
      } catch (err: any) {
        setImportError(err.message || 'Invalid PGN sequence format.');
      }
    }
  };

  const SAMPLE_POSITIONS = [
    {
      name: 'Standard Starting Position',
      fen: START_FEN,
    },
    {
      name: 'Lucena Position (Rook Endgame)',
      fen: '1K1k4/1P6/8/8/8/8/r7/2R5 w - - 0 1',
    },
    {
      name: 'Philidor Defense Position',
      fen: '7k/R7/8/8/8/8/4r3/3K4 b - - 0 1',
    },
    {
      name: 'Queen vs Pawn Endgame',
      fen: '8/8/8/8/5k2/8/4p1K1/4Q3 w - - 0 1',
    },
  ];

  return (
    <div className="w-full flex-1 max-w-7xl mx-auto p-3 sm:p-5 grid grid-cols-1 lg:grid-cols-[260px_1fr_280px] gap-4 items-start">
      {/* Left Column: Piece Palette & Tools */}
      <div className="flex flex-col gap-3 order-2 lg:order-1">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col gap-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-800 pb-2">
            <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300">
              Piece Palette
            </h3>
            <button
              onClick={() => setSelectedPalettePiece(null)}
              className="text-[11px] font-mono text-stone-500 hover:text-amber-500 cursor-pointer"
            >
              Select / Move
            </button>
          </div>

          {/* White Pieces */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400">
              White Pieces
            </span>
            <div className="grid grid-cols-6 gap-1.5 p-1.5 rounded-lg bg-stone-100 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
              {PIECE_PALETTE.slice(0, 6).map((p) => {
                const isSelected = selectedPalettePiece === p;
                return (
                  <button
                    key={p}
                    onClick={() => setSelectedPalettePiece(p)}
                    className={`aspect-square rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-stone-950 shadow-md ring-2 ring-amber-400'
                        : 'hover:bg-stone-200 dark:hover:bg-stone-800'
                    }`}
                  >
                    <div className="w-6 h-6">
                      <ChessPieceSvg piece={p} theme={pieceTheme} />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Black Pieces */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400">
              Black Pieces
            </span>
            <div className="grid grid-cols-6 gap-1.5 p-1.5 rounded-lg bg-stone-100 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
              {PIECE_PALETTE.slice(6, 12).map((p) => {
                const isSelected = selectedPalettePiece === p;
                return (
                  <button
                    key={p}
                    onClick={() => setSelectedPalettePiece(p)}
                    className={`aspect-square rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-stone-950 shadow-md ring-2 ring-amber-400'
                        : 'hover:bg-stone-200 dark:hover:bg-stone-800'
                    }`}
                  >
                    <div className="w-6 h-6">
                      <ChessPieceSvg piece={p} theme={pieceTheme} />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Eraser Tool */}
          <button
            onClick={() => setSelectedPalettePiece('trash')}
            className={`w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
              selectedPalettePiece === 'trash'
                ? 'bg-red-500 text-white border-red-500 font-bold shadow-xs'
                : 'bg-stone-50 dark:bg-stone-950 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-800 hover:bg-red-50 dark:hover:bg-red-950/40'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Eraser / Remove Piece</span>
          </button>

          {/* Quick Actions */}
          <div className="pt-2 border-t border-stone-200 dark:border-stone-800 flex flex-col gap-2">
            <button
              onClick={handleClearBoard}
              className="w-full py-1.5 px-3 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold border border-stone-200 dark:border-stone-800 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5 text-stone-400" />
              <span>Clear Board</span>
            </button>
            <button
              onClick={handleResetStarting}
              className="w-full py-1.5 px-3 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold border border-stone-200 dark:border-stone-800 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-stone-400" />
              <span>Initial Setup</span>
            </button>
            <button
              onClick={() => {
                setImportError(null);
                setImportModalOpen(true);
              }}
              className="w-full py-1.5 px-3 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-300 dark:border-stone-700 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-amber-500" />
              <span>Import FEN / PGN</span>
            </button>
          </div>
        </div>

        {/* Validation Status Indicator */}
        <div
          className={`p-3 rounded-xl border flex items-start gap-2.5 shadow-xs ${
            status.valid
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300'
          }`}
        >
          {status.valid ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
          ) : (
            <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
          )}
          <div className="flex-1 text-xs">
            <span className="font-bold font-mono uppercase block">
              {status.valid ? 'Legal Position Setup' : 'Position Notice'}
            </span>
            <span className="text-[11px] opacity-90 leading-tight block mt-0.5">
              {status.valid
                ? 'Position is ready to analyze or export.'
                : status.error}
            </span>
          </div>
        </div>
      </div>

      {/* Center Column: Board & Primary Actions */}
      <div className="flex flex-col items-center gap-3 order-1 lg:order-2">
        <div className="w-full max-w-[640px] p-3 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: themeCfg.previewColor }} />
            <span className="text-xs font-mono font-bold text-stone-800 dark:text-stone-200 uppercase">
              Board Editor
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="editor-save-btn"
              onClick={() => setSaveModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-semibold text-xs border border-stone-200 dark:border-stone-700 shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Save className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />
              <span>Save Position</span>
            </button>
            <button
              id="editor-analyze-btn"
              onClick={handleLoadToAnalysis}
              disabled={!status.valid}
              className={`px-3 py-1.5 rounded-lg font-bold text-xs shadow-md transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50 ${themeCfg.primaryClass}`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Load in Analysis</span>
            </button>
          </div>
        </div>

        <Chessboard
          board={board}
          orientation="w"
          turn={turn}
          interactive={true}
          allowFreeDrag={true}
          canSelect={(sq) => !!board[sq]}
          onMove={(from, to) => {
            const newBoard = [...board];
            newBoard[to] = newBoard[from];
            newBoard[from] = null;
            setBoard(newBoard);
          }}
          onSquareClick={handleSquareClick}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          animationEnabled={animationEnabled}
          animationSpeed={animationSpeed}
          dragRefreshRate={dragRefreshRate}
          dragAndDropEnabled={dragAndDropEnabled}
          autoQueenEnabled={autoQueenEnabled}
          showCoordinates={showCoordinates}
          showLegalMoves={showLegalMoves}
          showCheckHighlight={showCheckHighlight}
          showLastMoveHighlight={showLastMoveHighlight}
          uiTheme={uiTheme}
        />

        {/* FEN & PGN Output Bar */}
        <div className="w-full max-w-[640px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-3 flex flex-col gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={currentFEN}
              className="flex-1 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg px-2.5 py-1.5 font-mono text-[11px] text-stone-800 dark:text-stone-200 truncate focus:outline-hidden"
            />
            {/* Copy FEN */}
            <button
              id="copy-fen-btn"
              onClick={() => {
                navigator.clipboard.writeText(currentFEN);
                setCopiedFen(true);
                setTimeout(() => setCopiedFen(false), 1500);
              }}
              className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 flex items-center gap-1 shrink-0 cursor-pointer"
            >
              {copiedFen ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />}
              <span>{copiedFen ? 'Copied' : 'Copy FEN'}</span>
            </button>

            {/* Copy PGN Button */}
            <button
              id="copy-pgn-btn"
              onClick={() => {
                navigator.clipboard.writeText(computePGN());
                setCopiedPgn(true);
                setTimeout(() => setCopiedPgn(false), 1500);
              }}
              className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold border border-stone-200 dark:border-stone-700 flex items-center gap-1 shrink-0 cursor-pointer"
            >
              {copiedPgn ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <FileText className={`w-3.5 h-3.5 ${themeCfg.textClass}`} />}
              <span>{copiedPgn ? 'Copied PGN' : 'Copy PGN'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Right Column: Position Configuration & Saved Positions */}
      <div className="flex flex-col gap-3 order-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col gap-4 shadow-xs">
          <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-stone-800 dark:text-stone-300 pb-2 border-b border-stone-200 dark:border-stone-800">
            Position State
          </h3>

          {/* Turn */}
          <div className="space-y-1">
            <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400">
              Side to Move
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setTurn('w')}
                className={`py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                  turn === 'w'
                    ? `${themeCfg.activeTabClass} ${themeCfg.borderClass}`
                    : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                }`}
              >
                White to Move
              </button>
              <button
                onClick={() => setTurn('b')}
                className={`py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                  turn === 'b'
                    ? `${themeCfg.activeTabClass} ${themeCfg.borderClass}`
                    : 'bg-stone-50 dark:bg-stone-950 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
                }`}
              >
                Black to Move
              </button>
            </div>
          </div>

          {/* Castling Availability */}
          <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400">
              Castling Rights
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs text-stone-700 dark:text-stone-200">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={castling.K}
                  onChange={(e) => setCastling({ ...castling, K: e.target.checked })}
                  className="accent-amber-500 rounded cursor-pointer"
                />
                <span>White O-O (K)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={castling.Q}
                  onChange={(e) => setCastling({ ...castling, Q: e.target.checked })}
                  className="accent-amber-500 rounded cursor-pointer"
                />
                <span>White O-O-O (Q)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={castling.k}
                  onChange={(e) => setCastling({ ...castling, k: e.target.checked })}
                  className="accent-amber-500 rounded cursor-pointer"
                />
                <span>Black O-O (k)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={castling.q}
                  onChange={(e) => setCastling({ ...castling, q: e.target.checked })}
                  className="accent-amber-500 rounded cursor-pointer"
                />
                <span>Black O-O-O (q)</span>
              </label>
            </div>
          </div>

          {/* Saved Positions Drawer / List */}
          <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400 flex items-center gap-1">
                <Save className="w-3 h-3 text-amber-500" />
                <span>Saved Positions ({savedPositions.length})</span>
              </span>
              <button
                onClick={() => setSaveModalOpen(true)}
                className="text-[10px] text-amber-600 dark:text-amber-400 hover:underline font-mono cursor-pointer"
              >
                + Save current
              </button>
            </div>

            {savedPositions.length === 0 ? (
              <p className="text-[11px] text-stone-400 italic">No saved positions yet. Click &ldquo;Save Position&rdquo; to keep setups for later.</p>
            ) : (
              <div className="flex flex-col gap-1.5 max-h-48 overflow-y-auto">
                {savedPositions.map((pos) => (
                  <div
                    key={pos.id}
                    className="p-2 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 hover:border-amber-400/60 transition-colors flex items-center justify-between gap-2"
                  >
                    <button
                      onClick={() => loadPositionFromFen(pos.fen)}
                      className="flex-1 text-left min-w-0 cursor-pointer"
                      title={pos.fen}
                    >
                      <div className="text-xs font-semibold text-stone-800 dark:text-stone-200 truncate">
                        {pos.name}
                      </div>
                      <div className="text-[10px] text-stone-400 font-mono truncate">
                        {new Date(pos.timestamp).toLocaleDateString()}
                      </div>
                    </button>
                    <button
                      onClick={(e) => handleDeleteSavedPosition(pos.id, e)}
                      className="p-1 rounded-md text-stone-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 cursor-pointer"
                      title="Delete saved position"
                    >
                      <Trash className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sample Preset Positions */}
          <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800">
            <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400 flex items-center gap-1">
              <Bookmark className="w-3 h-3 text-amber-500" />
              <span>Sample Positions</span>
            </span>
            <div className="grid grid-cols-1 gap-1.5">
              {SAMPLE_POSITIONS.map((pos) => (
                <button
                  key={pos.name}
                  onClick={() => loadPositionFromFen(pos.fen)}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 text-[11px] text-stone-700 dark:text-stone-300 font-medium transition-colors truncate cursor-pointer"
                >
                  {pos.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Save Position Modal */}
      {saveModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-md w-full p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
              <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider flex items-center gap-1.5">
                <Save className="w-4 h-4 text-amber-500" />
                <span>Save Board Position</span>
              </h3>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-stone-700 dark:text-stone-300 block mb-1">
                  Position Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Endgame Practice vs Bot, Sicilian Opening study"
                  value={saveName}
                  onChange={(e) => setSaveName(e.target.value)}
                  className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2.5 text-stone-800 dark:text-stone-200 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 dark:text-stone-300 block mb-1">
                  Notes / Tags (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. White to move and win, Rook vs Pawns"
                  value={saveNotes}
                  onChange={(e) => setSaveNotes(e.target.value)}
                  className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-2.5 text-stone-800 dark:text-stone-200 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="p-2.5 rounded-lg bg-stone-100 dark:bg-stone-800 font-mono text-[10px] text-stone-600 dark:text-stone-400 truncate">
                FEN: {currentFEN}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
              <button
                onClick={() => setSaveModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePosition}
                className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-bold shadow-md cursor-pointer"
              >
                Save Position
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal for FEN, PGN, and Saved */}
      {importModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-lg w-full p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
              <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
                Import Position
              </h3>
              <div className="flex gap-1 bg-stone-100 dark:bg-stone-800 p-0.5 rounded-lg">
                <button
                  onClick={() => setImportTab('fen')}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    importTab === 'fen'
                      ? 'bg-amber-400 text-stone-950 font-bold'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  FEN
                </button>
                <button
                  onClick={() => setImportTab('pgn')}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    importTab === 'pgn'
                      ? 'bg-amber-400 text-stone-950 font-bold'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  PGN
                </button>
                <button
                  onClick={() => setImportTab('saved')}
                  className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                    importTab === 'saved'
                      ? 'bg-amber-400 text-stone-950 font-bold'
                      : 'text-stone-600 dark:text-stone-400'
                  }`}
                >
                  Saved ({savedPositions.length})
                </button>
              </div>
            </div>

            {importTab === 'saved' ? (
              <div className="flex flex-col gap-2 max-h-60 overflow-y-auto">
                {savedPositions.length === 0 ? (
                  <p className="text-xs text-stone-400 italic text-center py-6">No saved positions available.</p>
                ) : (
                  savedPositions.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        loadPositionFromFen(p.fen);
                        setImportModalOpen(false);
                      }}
                      className="p-2.5 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 hover:border-amber-400 text-left transition-all cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-800 dark:text-stone-200">{p.name}</span>
                        <span className="text-[10px] font-mono text-amber-500">Load &rarr;</span>
                      </div>
                      <p className="text-[11px] font-mono text-stone-400 truncate mt-1">{p.fen}</p>
                    </button>
                  ))
                )}
              </div>
            ) : (
              <>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {importTab === 'fen'
                    ? 'Paste a standard 6-field FEN position string below.'
                    : 'Paste a game or position in Portable Game Notation (PGN) format below.'}
                </p>

                <textarea
                  value={importInput}
                  onChange={(e) => setImportInput(e.target.value)}
                  placeholder={
                    importTab === 'fen'
                      ? 'e.g. r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3'
                      : 'e.g. 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 ...'
                  }
                  className="w-full h-36 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden focus:border-amber-500"
                />

                {importError && (
                  <div className="p-2.5 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-xs font-mono">
                    {importError}
                  </div>
                )}
              </>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
              <button
                onClick={() => setImportModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              {importTab !== 'saved' && (
                <button
                  onClick={handleProcessImport}
                  className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-bold shadow-md cursor-pointer"
                >
                  Import Position
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
