import React, { useState, useEffect, useCallback } from 'react';
import { GameTree } from '../engine/gameTree';
import {
  OpeningVariation,
  PieceColor,
  BoardTheme,
  PieceTheme,
  PieceStyle,
  AnimationSpeed,
} from '../types/chess';
import { OPENINGS_DATABASE } from '../engine/openingBook';
import { ViewLevel, TabMode, CatalogFilter, OpeningMeta, getOpeningMetadata } from '../components/OpeningTrainer/types';
import { OpeningCatalog } from '../components/OpeningTrainer/OpeningCatalog';
import { VariationList } from '../components/OpeningTrainer/VariationList';
import { StudyWorkbench } from '../components/OpeningTrainer/StudyWorkbench';
import { UIThemeColor } from '../types/chess';

export type { OpeningMeta };
export { getOpeningMetadata };

interface OpeningViewProps {
  onAnalyzeOpening: (tree: GameTree) => void;
  boardTheme: BoardTheme;
  pieceTheme: PieceTheme;
  pieceStyle: PieceStyle;
  soundEnabled: boolean;
  animationEnabled?: boolean;
  animationSpeed?: AnimationSpeed;
  uiTheme?: UIThemeColor;
}

export const OpeningView: React.FC<OpeningViewProps> = ({
  onAnalyzeOpening,
  boardTheme,
  pieceTheme,
  pieceStyle,
  soundEnabled,
  animationEnabled = true,
  animationSpeed = 'normal',
  uiTheme,
}) => {
  // Navigation Hierarchy Level: 'catalog' | 'variation_select' | 'study_workbench'
  const [viewLevel, setViewLevel] = useState<ViewLevel>('catalog');
  const [selectedOpening, setSelectedOpening] = useState<OpeningVariation>(OPENINGS_DATABASE[0]);
  const [selectedChapterIndex, setSelectedChapterIndex] = useState<number>(0);
  const [trainColor, setTrainColor] = useState<PieceColor>('w');
  const [activeTab, setActiveTab] = useState<TabMode>('overview');

  // Filter & Search state in catalog
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<CatalogFilter>('all');

  // Temporary completion toast notice
  const [completionNotice, setCompletionNotice] = useState<string | null>(null);

  // Persistence: Studied variations per opening (keyed by opName -> array of `${chapterId}:${color}`)
  const [studiedData, setStudiedData] = useState<Record<string, string[]>>(() => {
    try {
      const saved = localStorage.getItem('chess_trainer_openings_studied_v2');
      if (saved) return JSON.parse(saved);
      // Backwards compatibility migration
      const v1 = localStorage.getItem('chess_trainer_openings_studied');
      if (v1) {
        const parsedV1 = JSON.parse(v1);
        return parsedV1;
      }
    } catch {
      // ignore
    }
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem('chess_trainer_openings_studied_v2', JSON.stringify(studiedData));
    } catch {
      // ignore
    }
  }, [studiedData]);

  // Persistence: Unlocked stages per chapter + color (keyed by `${opName}:${chapterId}:${color}` -> max unlocked stage 1, 2, or 3)
  const [unlockedStages, setUnlockedStages] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('chess_trainer_unlocked_stages_v2');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {};
  });

  useEffect(() => {
    try {
      localStorage.setItem('chess_trainer_unlocked_stages_v2', JSON.stringify(unlockedStages));
    } catch {
      // ignore
    }
  }, [unlockedStages]);

  const handleUnlockStage = useCallback((openingName: string, chapterId: string, color: PieceColor, stage: number) => {
    const key = `${openingName}:${chapterId}:${color}`;
    setUnlockedStages((prev) => {
      const current = prev[key] || 1;
      if (stage > current) {
        return { ...prev, [key]: stage };
      }
      return prev;
    });
  }, []);

  const handleMarkMastered = useCallback((openingName: string, chapterId: string, color: PieceColor) => {
    const trackId = `${chapterId}:${color}`;
    setStudiedData((prev) => {
      const list = prev[openingName] || [];
      if (!list.includes(trackId)) {
        return { ...prev, [openingName]: [...list, trackId] };
      }
      return prev;
    });
    // Ensure all 3 stages are marked unlocked
    handleUnlockStage(openingName, chapterId, color, 3);
  }, [handleUnlockStage]);

  // Catalog select handler
  const handleSelectOpening = (op: OpeningVariation) => {
    setSelectedOpening(op);
    setSelectedChapterIndex(0);
    setViewLevel('variation_select');
  };

  // Variation stage jump handler
  const handleSelectStage = (chapterIndex: number, color: PieceColor, tab: TabMode) => {
    setSelectedChapterIndex(chapterIndex);
    setTrainColor(color);
    setActiveTab(tab);
    setViewLevel('study_workbench');
  };

  return (
    <div className="w-full flex-1 flex flex-col bg-stone-50 dark:bg-stone-950 min-h-0 overflow-y-auto">
      {viewLevel === 'catalog' && (
        <OpeningCatalog
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          categoryFilter={categoryFilter}
          setCategoryFilter={setCategoryFilter}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          studiedData={studiedData}
          unlockedStages={unlockedStages}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          uiTheme={uiTheme}
          onSelectOpening={handleSelectOpening}
        />
      )}

      {viewLevel === 'variation_select' && (
        <VariationList
          opening={selectedOpening}
          studiedData={studiedData}
          unlockedStages={unlockedStages}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          completionNotice={completionNotice}
          setCompletionNotice={setCompletionNotice}
          uiTheme={uiTheme}
          onBackToCatalog={() => setViewLevel('catalog')}
          onSelectStage={handleSelectStage}
        />
      )}

      {viewLevel === 'study_workbench' && (
        <StudyWorkbench
          selectedOpening={selectedOpening}
          selectedChapterIndex={selectedChapterIndex}
          trainColor={trainColor}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          boardTheme={boardTheme}
          pieceTheme={pieceTheme}
          pieceStyle={pieceStyle}
          soundEnabled={soundEnabled}
          animationEnabled={animationEnabled}
          animationSpeed={animationSpeed}
          unlockedStages={unlockedStages}
          studiedData={studiedData}
          uiTheme={uiTheme}
          onBackToVariations={() => setViewLevel('variation_select')}
          onAnalyzeOpening={onAnalyzeOpening}
          onUnlockStage={handleUnlockStage}
          onMarkMastered={handleMarkMastered}
          setCompletionNotice={setCompletionNotice}
        />
      )}
    </div>
  );
};
