import React, { useState, useEffect, useMemo } from 'react';
import {
  Archive,
  Play,
  Activity,
  Trash2,
  Download,
  Upload,
  Sparkles,
  Calendar,
  User,
  Heart,
  Search,
  Copy,
  Check,
  PlusCircle,
  FileText,
  History,
  Filter,
  ArrowUpDown,
  BookmarkPlus,
} from 'lucide-react';
import { GameTree } from '../engine/gameTree';
import { SavedGame, UIThemeColor } from '../types/chess';
import { getThemeConfig } from '../utils/themeColors';

interface GamesViewProps {
  onLoadGameToAnalysis: (tree: GameTree) => void;
  uiTheme?: UIThemeColor;
}

const SAMPLE_HISTORICAL_GAMES: SavedGame[] = [
  {
    id: 'game-immortal',
    title: 'The Immortal Game (Anderssen vs Kieseritzky, 1851)',
    date: '1851-06-21',
    white: 'Adolf Anderssen',
    black: 'Lionel Kieseritzky',
    result: '1-0',
    eco: 'C33',
    category: 'historical',
    favorite: true,
    pgn: `[Event "London"]
[Site "London"]
[Date "1851.06.21"]
[White "Adolf Anderssen"]
[Black "Lionel Kieseritzky"]
[Result "1-0"]
[ECO "C33"]

1. e4 e5 2. f4 exf4 3. Bc4 Qh4+ 4. Kf1 b5 5. Bxb5 Nf6 6. Nf3 Qh6 7. d3 Nh5 8. Nh4 Qg5 9. Nf5 c6 10. g4 Nf6 11. Rg1 cxb5 12. h4 Qg6 13. h5 Qg5 14. Qf3 Ng8 15. Bxf4 Qf6 16. Nc3 Bc5 17. Nd5 Qxb2 18. Bd6 Bxg1 19. e5 Qxa1+ 20. Ke2 Na6 21. Nxg7+ Kd8 22. Qf6+ Nxf6 23. Be7# 1-0`,
  },
  {
    id: 'game-century',
    title: 'Game of the Century (Byrne vs Fischer, 1956)',
    date: '1956-10-17',
    white: 'Donald Byrne',
    black: 'Bobby Fischer',
    result: '0-1',
    eco: 'D92',
    category: 'historical',
    favorite: true,
    pgn: `[Event "Third Rosenwald Trophy"]
[Site "New York, NY USA"]
[Date "1956.10.17"]
[White "Donald Byrne"]
[Black "Bobby Fischer"]
[Result "0-1"]
[ECO "D92"]

1. Nf3 Nf6 2. c4 g6 3. Nc3 Bg7 4. d4 O-O 5. Bf4 d5 6. Qb3 dxc4 7. Qxc4 c6 8. e4 Nbd7 9. Rd1 Nb6 10. Qc5 Bg4 11. Bg5 Na4 12. Qa3 Nxc3 13. bxc3 Nxe4 14. Bxe7 Qb6 15. Bc4 Nxc3 16. Bc5 Rfe8+ 17. Kf1 Be6 18. Bxb6 Bxc4+ 19. Kg1 Ne2+ 20. Kf1 Nxd4+ 21. Kg1 Ne2+ 22. Kf1 Nc3+ 23. Kg1 axb6 24. Qb4 Ra4 25. Qxb6 Nxd1 26. h3 Rxa2 27. Kh2 Nxf2 28. Re1 Rxe1 29. Qd8+ Bf8 30. Nxe1 Bd5 31. Nf3 Ne4 32. Qb8 b5 33. h4 h5 34. Ne5 Kg7 35. Kg1 Bc5+ 36. Kf1 Ng3+ 37. Ke1 Bb4+ 38. Kd1 Bb3+ 39. Kc1 Ne2+ 40. Kb1 Nc3+ 41. Kc1 Rc2# 0-1`,
  },
  {
    id: 'game-kasparov-topalov',
    title: "Kasparov's Immortal (Kasparov vs Topalov, 1999)",
    date: '1999-01-20',
    white: 'Garry Kasparov',
    black: 'Veselin Topalov',
    result: '1-0',
    eco: 'B07',
    category: 'historical',
    favorite: false,
    pgn: `[Event "Hoogovens Group A"]
[Site "Wijk aan Zee NED"]
[Date "1999.01.20"]
[White "Garry Kasparov"]
[Black "Veselin Topalov"]
[Result "1-0"]
[ECO "B07"]

1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Be3 Bg7 5. Qd2 c6 6. f3 b5 7. Nge2 Nbd7 8. Bh6 Bxh6 9. Qxh6 Bb7 10. a3 e5 11. O-O-O Qe7 12. Kb1 a6 13. Nc1 O-O-O 14. Nb3 exd4 15. Rxd4 c5 16. Rd1 Nb6 17. g3 Kb8 18. Na5 Ba8 19. Bh3 d5 20. Qf4+ Ka7 21. Rhe1 d4 22. Nd5 Nbxd5 23. exd5 Qd6 24. Rxd4 cxd4 25. Re7+ Kb6 26. Qxd4+ Kxa5 27. b4+ Ka4 28. Qc3 Qxd5 29. Ra7 Bb7 30. Rxb7 Qc4 31. Qxf6 Kxa3 32. Qxa6+ Kxb4 33. c3+ Kxc3 34. Qa1+ Kd2 35. Qb2+ Kd1 36. Bf1 Rd2 37. Rd7 Rxd7 38. Bxc4 bxc4 39. Qxh8 Rd3 40. Qa8 c3 41. Qa4+ Ke1 42. f4 f5 43. Kc1 Rd2 44. Qa7 1-0`,
  },
];

export const GamesView: React.FC<GamesViewProps> = ({ onLoadGameToAnalysis, uiTheme = 'orange' }) => {
  const themeCfg = getThemeConfig(uiTheme);
  const [activeTab, setActiveTab] = useState<'saved' | 'history'>('saved');

  // Saved Games
  const [games, setGames] = useState<SavedGame[]>(() => {
    try {
      const saved = localStorage.getItem('aperture_saved_games');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return SAMPLE_HISTORICAL_GAMES;
  });

  // Match History (Played games)
  const [historyGames, setHistoryGames] = useState<SavedGame[]>(() => {
    try {
      const hist = localStorage.getItem('aperture_match_history');
      if (hist) {
        const parsed = JSON.parse(hist);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  });

  // History filters
  const [historyResultFilter, setHistoryResultFilter] = useState<'all' | 'win' | 'loss' | 'draw'>('all');
  const [historyColorFilter, setHistoryColorFilter] = useState<'all' | 'white' | 'black'>('all');
  const [historyModeFilter, setHistoryModeFilter] = useState<'all' | 'bot' | 'human' | 'bot-bot'>('all');
  const [historySortOrder, setHistorySortOrder] = useState<'newest' | 'oldest'>('newest');

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGame, setSelectedGame] = useState<SavedGame | null>(games[0] || null);
  const [copiedPgn, setCopiedPgn] = useState<boolean>(false);
  const [savedToArchiveSuccess, setSavedToArchiveSuccess] = useState<boolean>(false);
  const [importModalOpen, setImportModalOpen] = useState<boolean>(false);
  const [confirmClearOpen, setConfirmClearOpen] = useState<boolean>(false);
  const [customPgnInput, setCustomPgnInput] = useState<string>('');

  // Reload match history when tab switched
  useEffect(() => {
    if (activeTab === 'history') {
      try {
        const hist = localStorage.getItem('aperture_match_history');
        if (hist) {
          const parsed = JSON.parse(hist);
          if (Array.isArray(parsed)) {
            setHistoryGames(parsed);
            if (parsed.length > 0 && (!selectedGame || !parsed.some((g) => g.id === selectedGame.id))) {
              setSelectedGame(parsed[0]);
            }
          }
        }
      } catch {}
    } else {
      if (games.length > 0 && (!selectedGame || !games.some((g) => g.id === selectedGame.id))) {
        setSelectedGame(games[0]);
      }
    }
  }, [activeTab]);

  const saveToStorage = (updated: SavedGame[]) => {
    setGames(updated);
    try {
      localStorage.setItem('aperture_saved_games', JSON.stringify(updated));
    } catch {}
  };

  const saveHistoryToStorage = (updated: SavedGame[]) => {
    setHistoryGames(updated);
    try {
      localStorage.setItem('aperture_match_history', JSON.stringify(updated));
    } catch {}
  };

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = games.map((g) => (g.id === id ? { ...g, favorite: !g.favorite } : g));
    saveToStorage(next);
    if (selectedGame?.id === id) {
      setSelectedGame({ ...selectedGame, favorite: !selectedGame.favorite });
    }
  };

  const handleDelete = (id: string) => {
    if (activeTab === 'saved') {
      const next = games.filter((g) => g.id !== id);
      saveToStorage(next);
      if (selectedGame?.id === id) {
        setSelectedGame(next[0] || null);
      }
    } else {
      const next = historyGames.filter((g) => g.id !== id);
      saveHistoryToStorage(next);
      if (selectedGame?.id === id) {
        setSelectedGame(next[0] || null);
      }
    }
  };

  const handleClearAllHistory = () => {
    setConfirmClearOpen(true);
  };

  const confirmClearAll = () => {
    saveHistoryToStorage([]);
    setSelectedGame(null);
    setConfirmClearOpen(false);
  };

  const handleSaveHistoryToArchive = (game: SavedGame) => {
    const newSavedGame: SavedGame = {
      ...game,
      id: `saved-${Date.now()}`,
      title: game.title || `Match: ${game.white} vs ${game.black}`,
      category: game.mode === 'bot-bot' ? 'bot' : game.mode === 'human-bot' ? 'bot' : 'human',
      favorite: false,
    };
    const updated = [newSavedGame, ...games];
    saveToStorage(updated);
    setSavedToArchiveSuccess(true);
    setTimeout(() => setSavedToArchiveSuccess(false), 2000);
  };

  const handleLoad = (game: SavedGame) => {
    try {
      const t = new GameTree();
      t.loadPGN(game.pgn);
      onLoadGameToAnalysis(t);
    } catch (err: any) {
      alert('Error loading game: ' + err.message);
    }
  };

  const handleImportPgn = () => {
    if (!customPgnInput.trim()) return;
    try {
      const t = new GameTree();
      t.loadPGN(customPgnInput);
      const newGame: SavedGame = {
        id: `custom-${Date.now()}`,
        title: `Imported Game (${new Date().toLocaleDateString()})`,
        pgn: customPgnInput,
        date: new Date().toISOString().slice(0, 10),
        result: '*',
        category: 'other',
        favorite: false,
      };
      const updated = [newGame, ...games];
      saveToStorage(updated);
      setSelectedGame(newGame);
      setImportModalOpen(false);
      setCustomPgnInput('');
    } catch (err: any) {
      alert('Invalid PGN format: ' + err.message);
    }
  };

  const filteredGames = useMemo(() => {
    if (activeTab === 'saved') {
      return games.filter((g) => {
        // Category filter
        if (selectedCategory === 'favorites' && !g.favorite) return false;
        if (selectedCategory === 'bot' && g.mode !== 'human-bot' && g.mode !== 'bot-bot') return false;
        if (selectedCategory === 'human' && g.mode !== 'human-human') return false;
        if (selectedCategory === 'historical' && g.category !== 'historical') return false;

        // Query filter
        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          const matchesTitle = g.title?.toLowerCase().includes(q);
          const matchesWhite = g.white?.toLowerCase().includes(q);
          const matchesBlack = g.black?.toLowerCase().includes(q);
          const matchesEco = g.eco?.toLowerCase().includes(q);
          return matchesTitle || matchesWhite || matchesBlack || matchesEco;
        }
        return true;
      });
    } else {
      // Match History tab filtering
      let result = [...historyGames];

      // Result filter
      if (historyResultFilter === 'win') {
        result = result.filter((g) => g.result === '1-0');
      } else if (historyResultFilter === 'loss') {
        result = result.filter((g) => g.result === '0-1');
      } else if (historyResultFilter === 'draw') {
        result = result.filter((g) => g.result === '1/2-1/2');
      }

      // Color filter
      if (historyColorFilter === 'white') {
        result = result.filter((g) => g.white?.toLowerCase().includes('you') || g.white?.toLowerCase().includes('human') || g.mode === 'human-human');
      } else if (historyColorFilter === 'black') {
        result = result.filter((g) => g.black?.toLowerCase().includes('you') || g.black?.toLowerCase().includes('human'));
      }

      // Mode filter
      if (historyModeFilter === 'bot') {
        result = result.filter((g) => g.mode === 'human-bot');
      } else if (historyModeFilter === 'bot-bot') {
        result = result.filter((g) => g.mode === 'bot-bot');
      } else if (historyModeFilter === 'human') {
        result = result.filter((g) => g.mode === 'human-human');
      }

      // Search Query
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        result = result.filter(
          (g) =>
            g.title?.toLowerCase().includes(q) ||
            g.white?.toLowerCase().includes(q) ||
            g.black?.toLowerCase().includes(q)
        );
      }

      // Sort Order
      if (historySortOrder === 'oldest') {
        result.reverse();
      }

      return result;
    }
  }, [
    games,
    historyGames,
    activeTab,
    selectedCategory,
    historyResultFilter,
    historyColorFilter,
    historyModeFilter,
    historySortOrder,
    searchQuery,
  ]);

  return (
    <div className="w-full flex-1 flex flex-col lg:grid lg:grid-cols-[400px_1fr] gap-4 p-3 sm:p-5 max-w-7xl mx-auto">
      {/* Left Column: Games Archive List & Category Filter */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 flex flex-col h-80 lg:h-[620px] gap-3 shadow-xs">
        {/* Top Header & Tab Toggle */}
        <div className="flex items-center justify-between pb-2 border-b border-stone-200 dark:border-stone-800">
          <div className="flex gap-1 bg-stone-100 dark:bg-stone-800 p-0.5 rounded-lg">
            <button
              onClick={() => setActiveTab('saved')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'saved'
                  ? `${themeCfg.activeTabClass} font-bold shadow-xs`
                  : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100'
              }`}
            >
              <Archive className="w-3.5 h-3.5" />
              <span>Saved Games ({games.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'history'
                  ? `${themeCfg.activeTabClass} font-bold shadow-xs`
                  : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Match History ({historyGames.length})</span>
            </button>
          </div>

          {activeTab === 'saved' ? (
            <button
              onClick={() => setImportModalOpen(true)}
              className="px-2 py-1 rounded bg-stone-100 dark:bg-stone-800 hover:bg-amber-400 hover:text-stone-950 text-stone-700 dark:text-stone-300 text-[11px] font-semibold flex items-center gap-1 transition-colors border border-stone-200 dark:border-stone-700 cursor-pointer"
            >
              <PlusCircle className="w-3 h-3" />
              <span>Import</span>
            </button>
          ) : (
            <button
              onClick={handleClearAllHistory}
              disabled={historyGames.length === 0}
              className="px-2 py-1 rounded bg-red-50 dark:bg-red-950/40 hover:bg-red-500 hover:text-white text-red-600 dark:text-red-400 text-[11px] font-semibold flex items-center gap-1 transition-colors border border-red-200 dark:border-red-800 disabled:opacity-40 cursor-pointer"
              title="Delete all match records in history"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear All</span>
            </button>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            placeholder={
              activeTab === 'saved'
                ? 'Search saved games, players, ECO...'
                : 'Search match history records...'
            }
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-stone-800 dark:text-stone-200 placeholder-stone-400 focus:outline-hidden focus:border-amber-500"
          />
        </div>

        {/* Category / Filter Bar */}
        {activeTab === 'saved' ? (
          <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar">
            {[
              { id: 'all', label: 'All Games' },
              { id: 'favorites', label: '❤️ Favorites' },
              { id: 'bot', label: '🤖 Bot Matches' },
              { id: 'human', label: '👥 Two Player' },
              { id: 'historical', label: '🏛️ Classics' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-amber-400 text-stone-950 font-bold'
                    : 'bg-stone-100 dark:bg-stone-800/80 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        ) : (
          <div className="space-y-2 pb-1 border-b border-stone-200 dark:border-stone-800">
            {/* Sorting & Result / Side Filters */}
            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
              {/* Result Filter */}
              <select
                value={historyResultFilter}
                onChange={(e) => setHistoryResultFilter(e.target.value as any)}
                className="bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg px-2 py-1 text-xs text-stone-700 dark:text-stone-300 focus:outline-hidden focus:border-amber-500"
              >
                <option value="all">Result: All</option>
                <option value="win">🏆 Wins (1-0)</option>
                <option value="loss">❌ Losses (0-1)</option>
                <option value="draw">🤝 Draws (1/2-1/2)</option>
              </select>

              {/* Side Color Filter */}
              <select
                value={historyColorFilter}
                onChange={(e) => setHistoryColorFilter(e.target.value as any)}
                className="bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg px-2 py-1 text-xs text-stone-700 dark:text-stone-300 focus:outline-hidden focus:border-amber-500"
              >
                <option value="all">Color: All</option>
                <option value="white">⚪ Played White</option>
                <option value="black">⚫ Played Black</option>
              </select>

              {/* Match Mode Filter */}
              <select
                value={historyModeFilter}
                onChange={(e) => setHistoryModeFilter(e.target.value as any)}
                className="bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg px-2 py-1 text-xs text-stone-700 dark:text-stone-300 focus:outline-hidden focus:border-amber-500"
              >
                <option value="all">Type: All</option>
                <option value="bot">🤖 vs Engine Bot</option>
                <option value="bot-bot">⚡ Bot vs Bot</option>
                <option value="human">👥 Pass & Play</option>
              </select>

              {/* Sort Order */}
              <button
                onClick={() =>
                  setHistorySortOrder(historySortOrder === 'newest' ? 'oldest' : 'newest')
                }
                className="ml-auto px-2 py-1 rounded bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-[11px] font-semibold flex items-center gap-1 border border-stone-200 dark:border-stone-700 cursor-pointer"
                title="Toggle Sort Order"
              >
                <ArrowUpDown className="w-3 h-3" />
                <span>{historySortOrder === 'newest' ? 'Newest' : 'Oldest'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Games / Records List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filteredGames.length === 0 ? (
            <div className="h-full flex items-center justify-center text-stone-400 text-xs italic text-center p-4">
              {activeTab === 'saved'
                ? 'No saved matches match your current filter.'
                : 'No played match records found. Play games in Play or Bot Duel mode to see records here!'}
            </div>
          ) : (
            filteredGames.map((g) => {
              const isSelected = selectedGame?.id === g.id;
              return (
                <div
                  key={g.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => setSelectedGame(g)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelectedGame(g);
                    }
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex flex-col gap-1.5 relative group cursor-pointer ${
                    isSelected
                      ? `${themeCfg.subtleBgClass} ${themeCfg.borderClass} shadow-xs`
                      : 'bg-stone-50 dark:bg-stone-950/60 border-stone-200 dark:border-stone-800 hover:bg-stone-100 dark:hover:bg-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-stone-800 dark:text-stone-200 truncate max-w-[230px]">
                      {g.title || 'Game Record'}
                    </span>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          g.result === '1-0'
                            ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                            : g.result === '0-1'
                            ? 'bg-red-500/15 text-red-600 dark:text-red-400'
                            : 'bg-stone-500/15 text-stone-600 dark:text-stone-400'
                        }`}
                      >
                        {g.result}
                      </span>
                      {activeTab === 'saved' ? (
                        <button
                          type="button"
                          onClick={(e) => toggleFavorite(g.id, e)}
                          className={`p-1 rounded-full hover:scale-110 transition-transform cursor-pointer ${
                            g.favorite ? 'text-rose-500' : 'text-stone-400 hover:text-rose-400'
                          }`}
                          title={g.favorite ? 'Remove Favorite' : 'Add to Favorites'}
                        >
                          <Heart className={`w-3.5 h-3.5 ${g.favorite ? 'fill-current' : ''}`} />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSaveHistoryToArchive(g);
                          }}
                          className="p-1 rounded text-stone-400 hover:text-amber-500 hover:scale-110 transition-transform cursor-pointer"
                          title="Save this record into Saved Games"
                        >
                          <BookmarkPlus className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400 font-mono">
                    <span className="truncate max-w-[220px]">
                      {g.white || 'White'} vs {g.black || 'Black'}
                    </span>
                    <span>{g.eco || g.date || 'Record'}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Right Column: Game Details & Analysis Loader */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 flex flex-col gap-4 shadow-xs">
        {selectedGame ? (
          <>
            <div className="flex flex-col sm:flex-row sm:items-start justify-between pb-3 border-b border-stone-200 dark:border-stone-800 gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-stone-900 dark:text-stone-100 font-serif">
                    {selectedGame.title}
                  </h2>
                  {activeTab === 'saved' && (
                    <button
                      onClick={(e) => toggleFavorite(selectedGame.id, e)}
                      className={`p-1 rounded-full transition-transform cursor-pointer ${
                        selectedGame.favorite ? 'text-rose-500' : 'text-stone-400 hover:text-rose-400'
                      }`}
                    >
                      <Heart
                        className={`w-4 h-4 ${selectedGame.favorite ? 'fill-current' : ''}`}
                      />
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 dark:text-stone-400 font-mono mt-1">
                  <span className="flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-stone-700 dark:text-stone-300" />
                    <span>
                      {selectedGame.white || 'White'} vs {selectedGame.black || 'Black'}
                    </span>
                  </span>
                  {selectedGame.date && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{selectedGame.date}</span>
                    </span>
                  )}
                  <span className="font-bold text-amber-600 dark:text-amber-400">
                    Result: {selectedGame.result}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {activeTab === 'history' && (
                  <button
                    onClick={() => handleSaveHistoryToArchive(selectedGame)}
                    className="px-3 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold text-xs shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
                    title="Save this game into the permanent Saved Games tab"
                  >
                    <BookmarkPlus className="w-3.5 h-3.5" />
                    <span>{savedToArchiveSuccess ? 'Saved!' : 'Save to Archive'}</span>
                  </button>
                )}
                <button
                  onClick={() => handleLoad(selectedGame)}
                  className={`px-4 py-2 rounded-lg font-bold text-xs shadow-md transition-colors flex items-center gap-1.5 cursor-pointer ${themeCfg.primaryClass}`}
                >
                  <Activity className="w-4 h-4" />
                  <span>Analyze & Review</span>
                </button>
                <button
                  onClick={() => handleDelete(selectedGame.id)}
                  className="p-2 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-red-950 hover:text-red-300 text-stone-600 dark:text-stone-400 border border-stone-200 dark:border-stone-700 transition-colors cursor-pointer"
                  title="Delete Record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* PGN Text Viewer */}
            <div className="flex-1 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase text-stone-500 dark:text-stone-400 tracking-wider font-bold">
                  Full PGN Notation
                </span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(selectedGame.pgn);
                    setCopiedPgn(true);
                    setTimeout(() => setCopiedPgn(false), 1500);
                  }}
                  className="px-2.5 py-1 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-semibold border border-stone-200 dark:border-stone-700 flex items-center gap-1 cursor-pointer"
                >
                  {copiedPgn ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-amber-500" />
                  )}
                  <span>{copiedPgn ? 'Copied' : 'Copy PGN'}</span>
                </button>
              </div>

              <pre className="w-full h-80 lg:h-[420px] bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-4 font-mono text-xs text-stone-800 dark:text-stone-300 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                {selectedGame.pgn}
              </pre>
            </div>
          </>
        ) : (
          <div className="h-full flex items-center justify-center text-stone-400 text-sm">
            Select a game to view details
          </div>
        )}
      </div>

      {/* Import Modal */}
      {importModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-lg w-full p-5 flex flex-col gap-4">
            <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
              Import PGN into Archive
            </h3>
            <textarea
              value={customPgnInput}
              onChange={(e) => setCustomPgnInput(e.target.value)}
              placeholder="Paste PGN text here..."
              className="w-full h-40 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl p-3 font-mono text-xs text-stone-800 dark:text-stone-200 focus:outline-hidden focus:border-amber-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setImportModalOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleImportPgn}
                className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-bold cursor-pointer"
              >
                Save to Archive
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear Match History Confirmation Modal */}
      {confirmClearOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-2xl shadow-2xl max-w-md w-full p-5 flex flex-col gap-3">
            <div className="flex items-center gap-2.5 text-red-500">
              <Trash2 className="w-5 h-5" />
              <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-mono uppercase tracking-wider">
                Clear Match History
              </h3>
            </div>
            <p className="text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
              Are you sure you want to delete all <strong className="text-stone-800 dark:text-stone-200 font-mono">{historyGames.length}</strong> recorded match games? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2 border-t border-stone-200 dark:border-stone-800">
              <button
                onClick={() => setConfirmClearOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmClearAll}
                className="px-4 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
              >
                Yes, Clear All History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
